
let count = 0;

if(sessionStorage.getItem('123') === null){
    window.location.href = "../../register/login.html"
}

let key = getToken(sessionStorage.getItem('123'));
let acc = JSON.parse(decrypt(sessionStorage.getItem('acc'), key));if (acc === null) {
    window.location.href = "../../register/login.html"
}
else if (acc.PICorStaff == 0) {
    window.location.href = "../../home/home.html"
} else if (acc.PICorStaff == 1) {
    $('.sidebar-menu').append(`<li><a href="../../home/tranferRequest.html" class="sidebar-link" id="tranferRequest"><i class="fas fa-exchange-alt"></i>Yêu cầu bàn giao</a></li>`);
    if (acc.accountantPIC == 1) {
        $('.sidebar-menu').append(`<li><a href="../registerDevice.html" class="sidebar-link" id="newItem"><i class="fas fa-plus-circle"></i> Đăng kí thiết bị mới</a></li>`);
        $('.sidebar-menu').append(`<li><a href="../../home/newItem.html" class="sidebar-link" id="unknowItem"><i class="fas fa-question-circle"></i> Thiết bị mới </br>  chưa bàn giao</a></li>`);

    }
} else if (acc.PICorStaff == 2) {
    $('.sidebar-menu').append(`<li><a href="../../home/tranferRequestManager.html" class="sidebar-link" id="tranferRequest"><i class="fas fa-exchange-alt"></i>Yêu cầu bàn giao</a></li>`);
    $('.sidebar-menu').append(`<li><a href="../../home/answerRegisterDeviceManager.html" class="sidebar-link" id="newItem"><i class="fas fa-plus-circle"></i>Đăng kí thiết bị mới</a></li>`);
    $('.sidebar-menu').append(`<li><a href="../../home/newItem.html" class="sidebar-link" id="unknowItem"><i class="fas fa-question-circle"></i> Thiết bị mới </br>  chưa bàn giao</a></li>`);

    if(acc.admin == 1){
        $('.sidebar-menu').append(`<li><a href="../../home/accManaAdmin/accManaStaffAdmin.html" class="sidebar-link" id="unkn"><i
                            class="fas fa-user-shield"></i> Quản lí tài khoản</a></li>`)
                            $(".sidebar-menu").append(`  <li><a href="../managerItemAdmin.html" class="sidebar-link" id="manaItem"><i class="fas fa-boxes"></i> Quản lí thông tin trang thiết bị</a>
                                </li>`)
    }
}


// lấy ra idTranferRequest
const currentUrl = window.location.href;
const url = new URL(currentUrl);
const params = new URLSearchParams(url.search);
const idTranferRequest = params.get('idTranferRequest');
const infor = getInforByTranferId(idTranferRequest);
let data = getItemByIdTranferRequest(idTranferRequest);


// đồng ý chuyển giao
function accept() {
    const confirmation = confirm("Bạn có muốn đồng ý bàn giao?");
    if (confirmation) {
        postAcceptTranferRequest(idTranferRequest);
        sendMailResultTranferRequestForPIC(idTranferRequest, data);
        location.reload();
    }
}
//từ chối chuyển giao
function ddeos() {
    const confirmation = confirm("Bạn có muốn từ chối bàn giao");
    if (confirmation) {
        postRejectTranferRequest(idTranferRequest);
        sendMailResultTranferRequestForPIC(idTranferRequest, data);
        location.reload();
    }
}

window.onload = function () {
    
    document.getElementById("title").textContent = `Chuyển từ ${infor.fromWarehouseName} (${infor.fromAreaName}) sang ${infor.toWarehouseName} (${infor.toAreaName}) (${infor.status})`;

    if ((acc.PICorStaff == 2 || infor.toArea_idPIC === acc.id) && infor.status == "Đang chờ") {
        $("#group-btn").append(`<button class="accept-btn active" id="accept" onclick="accept()" value="accept">Đồng ý chuyển giao</button> `);
        $("#group-btn").append(`<button class="accept-btn active" id="ddeos" onclick="ddeos()" value="accept">Từ chối chuyển giao</button>`);
    }
    document.getElementById('profile').innerHTML =
    `<a href="../profile.html" class="nav-link" id="profile">
            <i class="fas fa-user-circle"></i> 
            ${acc.name}</a>`;
}