
let acc = JSON.parse(sessionStorage.getItem("acc"));

if (acc === null) {
    window.location.href = "../../register/login.html"
}
else if (acc.PICorStaff !== 2 || acc.admin !== 1) {
    window.location.href = "../home.html"
}

window.onload = function () {
    getAllPICAcc();
    document.getElementById('profile').innerHTML =
    `<a href="../profile.html" class="nav-link" id="profile">
            <i class="fas fa-user-circle"></i> 
            ${acc.name}</a>`;
}


function staffClick(){
    location.href = "../accManaAdmin/accManaStaffAdmin.html"
}

function managerClick(){
    location.href = "../accManaAdmin/accManaManagerAdmin.html"

}





$(document).ready(function () {
    // Lắng nghe sự kiện khi bấm nút "Cập nhật"
    $('#table-body').on('click', '.update', function () {
        let $row = $(this).closest('tr');
        let idStaff = $row.find('td:eq(0)').text();
        let name = $row.find('input:eq(0)').val();
        let username = $row.find('input:eq(1)').val();
        let password = $row.find('input:eq(2)').val();
        let email = $row.find('input:eq(3)').val();

        if (confirm(`Bạn có chắc chắn muốn cập nhật id: ${idStaff} ?`)) {
            if (name === "" || username === "" || password === "" || email === "") {
                alert("Vui lòng điền đầy đủ thông tin trước khi cập nhật.");
            }  else {
                updatePICAcc(idStaff, username, password, name, email);
                location.reload();
            }
        }

    });

    // Lắng nghe sự kiện khi bấm nút "Xóa tài khoản"
    $('#table-body').on('click', '.delete', function () {
        let accountId = $(this).data('id');

        if (confirm(`Bạn có chắc chắn muốn xóa id: ${accountId} ?`)) {
            deletePICAcc(accountId);
            location.reload();
        }

        console.log("Xóa tài khoản có ID:", accountId);
    });


    // Lắng nghe sự kiện khi bấm nút "tạo tài khoản mới"
    $('#table-body').on('click', '.add', function () {

        if (confirm(`Xác nhận tạo tài khoản Staff mới ?`)) {
            let $row = $(this).closest('tr');
            let name = $row.find('input:eq(0)').val();
            let username = $row.find('input:eq(1)').val();
            let password = $row.find('input:eq(2)').val();
            let email = $row.find('input:eq(3)').val();

            if (name === "" || username === "" || password === "" || email === "") {
                alert("Vui lòng điền đầy đủ thông tin trước khi tạo tài khoản.");
            } else if (checkStaffAccExist(username) || checkPICAccExist(username) || checkManagerAccExist(username)) {
                alert("Tên tài khoản đã tồn tại, vui lòng chọn tên khác.");
            } else {
                createNewPICAcc(username, password, name, email);
                location.reload();
            }
        }

        console.log("Xóa tài khoản có ID:", accountId);
    });
});






//hàm xử lí khi chọn nút radio
$('#table-body').on('change', 'input[type="radio"][name="accountant"]', function() {
    let id = $(this).val();
    if(confirm(`Xác trao quyền quản lí thiết bị mới cho tài khoản PIC có ID: ${id} ?`)){
        updateAccountantPIC(id);
    }
});
