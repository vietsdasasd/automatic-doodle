let count = 0;

if(sessionStorage.getItem('123') === null){
    window.location.href = "../../register/login.html"

}

let key = getToken(sessionStorage.getItem('123'));
let acc = JSON.parse(decrypt(sessionStorage.getItem('acc'), key));
if (acc === null) {
    window.location.href = "../../register/login.html"
}
else if (acc.PICorStaff !== 2 || acc.admin !== 1) {
    window.location.href = "../home.html"
}

window.onload = function () {
    getAllManagerAcc();
    document.getElementById('profile').innerHTML =
        `<a href="../profile.html" class="nav-link" id="profile">
                <i class="fas fa-user-circle"></i> 
                ${acc.name}</a>`;
}

function staffClick() {
    location.href = "../accManaAdmin/accManaStaffAdmin.html"
}

function picClick() {
    location.href = "../accManaAdmin/accManaPICAdmin.html"

}
function managerClick() {
    location.href = "../accManaAdmin/accManaManagerAdmin.html"

}

window.onload = function () {
    getWarehouseAndPICName()
}





$(document).ready(function () {
    // nút thêm mới kho
    $('#table-body').on('click', '.add', function () {

        if (confirm(`Xác nhận tạo kho mới ?`)) {
            let $row = $(this).closest('tr');
            let nameWarehouse = $row.find('input:eq(0)').val();
            let idPIC = $row.find('select:eq(0)').val();

            if (nameWarehouse === "") {
                alert("Vui lòng điền đầy đủ thông tin trước khi tạo kho.");
            } else {
                createNewWarehouse(nameWarehouse, idPIC);
                location.reload();
            }
        }

    });



    // nút thêm mới khu
    $('#table-body').on('click', '.add-area', function () {

        if (confirm(`Xác nhận tạo khu mới ?`)) {
            let $row = $(this).closest('tr');
            let nameArea = $row.find('input:eq(0)').val();
            let idWarehouse = $row.find('select:eq(0)').val();

            if (nameArea === "") {
                alert("Vui lòng điền đầy đủ thông tin trước khi tạo Khu.");
            } else {
                createNewArea(nameArea, idWarehouse);
                location.reload();
            }
        }

    });






    //nút cập nhật

    $('#table-body').on('click', '.update', function () {

        const warehouseId = $(this).data('id');
        let warehouseName = $(this).closest('tr').find('input').val();
        const selectedPIC = $(this).closest('tr').find('select').val();



        const nextRow = $(this).closest('tr').next('tr');

        // Lấy tất cả các thẻ input trong hàng dưới
        const inputsInNextRow = nextRow.find('input');

        // Tạo một mảng chứa giá trị của tất cả các thẻ input trong hàng dưới
        let dataArea = [];
        inputsInNextRow.each(function () {
            dataArea.push({
                idArea: $(this).attr('id'),
                name: $(this).val()
            });

        });
        

        if (confirm(`Xác nhận cập nhật`)) {
            updateArea(dataArea);
            assignPICtoWarehouse(warehouseId, selectedPIC, warehouseName);
            location.reload();
        }

    });
});