
let count = 0;

if(sessionStorage.getItem('123') === null){
    window.location.href = "../register/login.html"
}
let key = getToken(sessionStorage.getItem('123'));
let acc = JSON.parse(decrypt(sessionStorage.getItem('acc'), key));if (acc === null) {
    window.location.href = "../register/login.html"
} else if (acc.PICorStaff == 0) {
    window.location.href = "../home/home.html"
} else if (acc.PICorStaff == 1) {
    if (acc.accountantPIC == 1) {
        $('.sidebar-menu').append(`<li><a href="../home/tranferRequest.html" class="sidebar-link" id="tranferRequest"><i class="fas fa-exchange-alt"></i>Yêu cầu bàn giao</a></li>`);
        $('.sidebar-menu').append(`<li><a href="../home/needMaintanceItem.html" class="sidebar-link" id="maintenanceDue"><i class="fas fa-tools"></i> Thiết bị đến hạn</a></li>`);
        $('.sidebar-menu').append(`<li><a href="../home/registerDevice.html" class="sidebar-link" id="newItem"><i class="fas fa-plus-circle"></i> Đăng kí thiết bị mới</a></li>`);
        $('.sidebar-menu').append(`<li><a href="#" class="sidebar-link" id="unknowItem"><i class="fas fa-question-circle"></i> Thiết bị mới </br>  chưa bàn giao</a></li>`);
    } else {
        window.location.href = "../home/home.html"
    }
} else if (acc.PICorStaff == 2) {
    $('.sidebar-menu').append(`<li><a href="../home/tranferRequestManager.html" class="sidebar-link" id="transferRequest"><i class="fas fa-exchange-alt"></i>Yêu cầu bàn giao</a></li>`);
    $('.sidebar-menu').append(`<li><a href="../home/answerRegisterDeviceManager.html" class="sidebar-link" id="newItem"><i class="fas fa-plus-circle"></i>Đăng kí thiết bị mới</a></li>`);
    $('.sidebar-menu').append(`<li><a href="#" class="sidebar-link" id="unknowItem"><i class="fas fa-question-circle"></i> Thiết bị mới </br>  chưa bàn giao</a></li>`);
    if (acc.admin == 1) {
        $('.sidebar-menu').append(` <li><a href="../home/accManaAdmin/accManaStaffAdmin.html" class="sidebar-link" id="unkn"><i class="fas fa-user-shield"></i> Quản lí tài khoản</a></li>`)
        $(".sidebar-menu").append(`  <li><a href="../home/managerItemAdmin.html" class="sidebar-link" id="manaItem"><i class="fas fa-boxes"></i> Quản lí thông tin trang thiết bị</a>`)
    }
}

window.onload = function () {
    getNewItem();

    getAllWarehouse();
    const selectElement = document.getElementById('Warehouse');
    const selectedOption = selectElement.value;
    getAllRegionByWarehouse(selectedOption)
    document.getElementById('profile').innerHTML =
        `<a href="./profile.html" class="nav-link" id="profile">
                <i class="fas fa-user-circle"></i> 
                ${acc.name}</a>`;
}


// xóa đi các option của region khi warehouse thay đổi
function handleSelectChange() {
    // Lấy thẻ select từ DOM
    const selectElement = document.getElementById('region');

    // Lấy danh sách các option
    const options = selectElement.querySelectorAll('option');

    // Lặp qua từng option (bắt đầu từ index 1 để bỏ qua option đầu tiên)
    for (let i = 1; i < options.length; i++) {
        // Xóa option khỏi select
        selectElement.removeChild(options[i]);
    }
}

//đổ dữ liệu khu vào filter combobox theo idWarehouse
document.addEventListener("DOMContentLoaded", function () {
    const selectElement = document.getElementById('Warehouse');

    selectElement.addEventListener('change', function () {
        const selectedOption = selectElement.value;
        getAllRegionByWarehouse(selectedOption)
    });
});


// Đăng ký sự kiện change cho tất cả các input có class là 'quantity-input'
$(document).on('change', '.quantity-input', function () {
    let input = $(this);
    let value = parseInt(input.val());
    let max = parseInt(input.attr('max'));
    let min = parseInt(input.attr('min'));

    // Kiểm tra nếu giá trị nhập vào lớn hơn giới hạn max
    if (value > max || value < min) {
        input.val(''); // Xóa giá trị nếu không hợp lệ
        input.siblings('.error-msg').text(`Vui lòng nhập số lượng từ 1 đến ${max}`);
        input.val('1');
    } else {
        input.siblings('.error-msg').text(''); // Xóa thông báo lỗi nếu hợp lệ
    }
});




// xử lí khi bấm vào nút bàn giao
$('#submit-button').on('click', function () {
    let checkedCheckboxes = [];

    // Lặp qua từng checkbox có class là 'choose' và kiểm tra xem có được chọn không
    $('.choose').each(function () {
        if ($(this).is(':checked')) {
            let categoryId = $(this).data('id'); // Lấy giá trị của data-id từ checkbox
            let quantityInput = $(this).closest('tr').find('.quantity-input'); // Tìm quantity-input tương ứng
            let quantityValue = parseInt(quantityInput.val()); // Lấy giá trị của quantity-input

            checkedCheckboxes.push({
                categoryId: categoryId,
                categoryName: getCategoryByIdCategory(categoryId),
                quantity: quantityValue
            });
        }
    });

    if (checkedCheckboxes.length === 0) {
        alert('Vui lòng chọn ít nhất 1 thiết bị');
        return;
    } else {
        let idArea = document.getElementById('region').value;
        let infor = getPICEmailbyIdArea(idArea);

        let dataSendMail = {
            data: checkedCheckboxes,
            inforPIC: infor
        }
        postUpdateItemPosition({ da: checkedCheckboxes, idArea: idArea }, dataSendMail);
        window.location.reload();
    }
});