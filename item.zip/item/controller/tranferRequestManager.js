

let acc = JSON.parse(sessionStorage.getItem("acc"));
if (acc === null) {
    window.location.href = "../register/login.html"
}
else if (acc.PICorStaff !== 2) {
    window.location.href = "../home/home.html"
} else {
    $('.sidebar-menu').append(`<li><a href="#" class="sidebar-link" id="tranferRequest"><i class="fas fa-exchange-alt"></i>Yêu cầu bàn giao</a></li>`);
    $('.sidebar-menu').append(`<li><a href="../home/answerRegisterDeviceManager.html" class="sidebar-link" id="newItem"><i class="fas fa-plus-circle"></i>Đăng kí thiết bị mới</a></li>`);
    $('.sidebar-menu').append(`<li><a href="../home/newItem.html" class="sidebar-link" id="unknowItem"><i class="fas fa-question-circle"></i> Thiết bị mới </br>  chưa bàn giao</a></li>`);
    if (acc.admin == 1) {
        $('.sidebar-menu').append(` <li><a href="../home/accManaAdmin/accManaStaffAdmin.html" class="sidebar-link" id="unkn"><i class="fas fa-user-shield"></i> Quản lí tài khoản</a>
                </li>`)
    }
}

window.onload = function () {
    getAllWarehouseforRequest();
    getAllWarehouse();

    const selectElement = document.getElementById('Warehouse');
    const selectedOption = selectElement.value;
    getAllRegionByWarehouse(selectedOption)
    document.getElementById('profile').innerHTML =
        `<a href="./profile.html" class="nav-link" id="profile">
            <i class="fas fa-user-circle"></i> 
            ${acc.name}</a>`;

}


// xử lí khi bấm chọn warehouse
function warehouseClick(button) {
    document.querySelectorAll('.warehouse-btn').forEach(btn => btn.classList.remove('active'));
    $('#table-body').empty();
    button.classList.add('active');
    removeAllAreaButtons()
    getAllAreaByIdWarehouse(button.value);
}

//xử lí khi bấm chọn area
function areaClick(button) {
    document.querySelectorAll(".area-btn").forEach(btn => btn.classList.remove("active"));
    getItemByAreaId(button.value);
    button.classList.add("active");
}

// hàm xóa tất cả các nút khu
function removeAllAreaButtons() {
    const areaGroup = document.querySelector('.area-group');
    areaGroup.innerHTML = ''; // Clear all HTML content inside area-group
}
// xóa đi các option của region khi warehouse thay đổi
function handleSelectChange() {
    // Lấy thẻ select từ DOM
    const selectElement = document.getElementById('region');

    // Lấy danh sách các option
    const options = selectElement.querySelectorAll('option');

    // Lặp qua từng option (bắt đầu từ index 1 để bỏ qua option đầu tiên)
    for (let i = 1; i < options.length; i++) {
        // Xóa option khỏi select
        selectElement.removeChild(options[i]);
    }
}

//đổ dữ liệu khu vào filter combobox theo idWarehouse
document.addEventListener("DOMContentLoaded", function () {
    const selectElement = document.getElementById('Warehouse');

    selectElement.addEventListener('change', function () {
        const selectedOption = selectElement.value;
        getAllRegionByWarehouse(selectedOption)
    });
});


// xử lí khi ấn nút chuyển giao
document.getElementById('submit-button').addEventListener('click', function () {
    const warehouse = document.getElementById('Warehouse');
    const region = document.getElementById('region');

    if (!warehouse || !region) {
        alert('Vui lòng chọn cả kho và khu.');
    } else {
        // kiểm tra xem có checkbox nào được chọn không
        const checkboxes = document.querySelectorAll('#table-body .item-checkbox');
        let selectedCount = 0;
        checkboxes.forEach(function (checkbox) {
            if (checkbox.checked) {
                selectedCount++;
            }
        });
        if (selectedCount == 0) {
            alert("Bạn chưa chọn thiết bị nào !")
        } else {
            const confirmation = confirm(`Bạn đã chọn kho: ${warehouse.options[warehouse.selectedIndex].text} và khu: ${region.options[region.selectedIndex].text}. Bạn có muốn tiếp tục không?`);
            if (confirmation) {
                let acc = JSON.parse(sessionStorage.getItem("acc"));

                let checkedItems = getCheckedItem();
                let fromArea = getActiveAreaValue();
                let toArea = region.options[region.selectedIndex].value;
                let toWarehouse = warehouse.options[warehouse.selectedIndex].value
                let reason = document.getElementById("reason").value;


                let insertedId = postTranferRequestManager("Chấp nhận", reason, fromArea, toArea);
                postTranferRequestDetail(checkedItems, insertedId);
                postAcceptTranferRequest(insertedId);
                postHistoryTranfer(insertedId);


                location.reload()
            } else {


            }
        }
    }
});


function getCheckedItem() {
    let checkedItems = [];
    $('.item-checkbox:checked').each(function () {
        checkedItems.push({ id: $(this).data('id'), PIC: getActiveWarehouseValue() });
    });
    return checkedItems;
}

// lấy ra value của nút warehouse đang được active
function getActiveWarehouseValue() {
    const activeButton = document.querySelector('.warehouse-btn.active');
    if (activeButton) {
        return parseInt(activeButton.value);  // Giả sử giá trị của nút được lưu trong thuộc tính value
    } else {
        return null;  // Không có nút nào đang active
    }
}

// chuyển sang danh sách item
document.addEventListener('DOMContentLoaded', function () {
    document.getElementById("staticItem").onclick = function () {
        window.location.href = "../home/staticItem.html";
    }
});


document.addEventListener('DOMContentLoaded', function () {
    document.getElementById("listRequest").onclick = function () {
        window.location.href = `../home/listRequest/maintance.html`;
    }
});


// hàm lấy value của thẻ khu đang được bấm
function getActiveAreaValue() {
    const activeButton = document.querySelector(".area-btn.active");
    if (activeButton) {
        return parseInt(activeButton.value);
    } else {
        return null;
    }
}

