
let count = 0;

if(sessionStorage.getItem('123') === null){
    window.location.href = "../register/login.html"

}


let key = getToken(sessionStorage.getItem('123'));
let acc = JSON.parse(decrypt(sessionStorage.getItem('acc'), key));
if (acc === null) {
    window.location.href = "../register/login.html"
}
else if (acc.PICorStaff !== 2 || acc.admin !== 1) {
    window.location.href = "./home.html"
}

window.onload = function () {
    getAllCategoryToManage();
    document.getElementById('profile').innerHTML =
        `<a href="./profile.html" class="nav-link" id="profile">
         <i class="fas fa-user-circle"></i> 
         ${acc.name}</a>`;
}

$(document).on('click', '.more-info', handleUpdateButtonClick);
function handleUpdateButtonClick(event) {
    if (confirm("Bạn có chắc chắn muốn cập nhật thông tin?")) {
        const button = $(event.currentTarget);
        const idCategory = button.data('id');
        let $row = $(this).closest('tr');
        let maintaneceCycle = $row.find('input:eq(0)').val();
        let duration = $row.find('input:eq(1)').val();
        let alertMaintance = $row.find('input:eq(2)').val();
        let alertRenew = $row.find('input:eq(3)').val();
        if(maintaneceCycle === "" || duration === "" || alertMaintance === "" || alertRenew === "") {
            alert("Vui lòng điền đầy đủ thông tin trước khi cập nhật.");
        }else{
            updateItemInfor(idCategory, maintaneceCycle, duration, alertMaintance, alertRenew);
            location.reload();
        }
    } else {

    }
}

//để chỉ cho phép nhập số nguyên dương vào
function validateIntegerInput(event) {
    let value = $(this).val();
    
    if (!/^[0-9]+$/.test(value)) {
        $(this).val(value.replace(/[^0-9]/g, ''));
    }
}
$(document).on('input', 'input[type="text"]', validateIntegerInput)