//check xem đã đăng nhập chưa
let count = 0;
if(sessionStorage.getItem('123') === null){
    window.location.href = "../register/login.html";
}

let key = getToken(sessionStorage.getItem('123'));
let acc = JSON.parse(decrypt(sessionStorage.getItem('acc'), key));

if (acc === null) {
    window.location.href = "../register/login.html";
} else if (acc.PICorStaff == 1) {

    $('.sidebar-menu').append(`<li><a href="./tranferRequest.html" class="sidebar-link" id="tranferRequest"><i class="fas fa-exchange-alt"></i>Yêu cầu bàn giao</a></li>`);
    $('.sidebar-menu').append(`<li><a href="./needMaintanceItem.html" class="sidebar-link" id="maintenanceDue"><i class="fas fa-tools"></i> Thiết bị đến hạn</a></li>`);
    if (acc.accountantPIC == 1) {
        $('.sidebar-menu').append(`<li><a href="./registerDevice.html" class="sidebar-link" id="newItem"><i class="fas fa-plus-circle"></i> Đăng kí thiết bị mới</a></li>`);
        $('.sidebar-menu').append(`<li><a href="../home/newItem.html" class="sidebar-link" id="unknowItem"><i class="fas fa-question-circle"></i> Thiết bị mới </br>  chưa bàn giao</a></li>`);

    }
} else if (acc.PICorStaff == 2) {

    $('.sidebar-menu').append(`<li><a href="../home/tranferRequestManager.html" class="sidebar-link" id="tranferRequest"><i class="fas fa-exchange-alt"></i>Yêu cầu bàn giao</a></li>`);
    $('.sidebar-menu').append(`<li><a href="./answerRegisterDeviceManager.html" class="sidebar-link" id="newItem"><i class="fas fa-plus-circle"></i>Đăng kí thiết bị mới</a></li>`);
    $('.sidebar-menu').append(`<li><a href="../home/newItem.html" class="sidebar-link" id="unknowItem"><i class="fas fa-question-circle"></i> Thiết bị mới </br>  chưa bàn giao</a></li>`);
    if (acc.admin == 1) {
        $('.sidebar-menu').append(` <li><a href="../home/accManaAdmin/accManaStaffAdmin.html" class="sidebar-link" id="unkn"><i class="fas fa-user-shield"></i> Quản lí tài khoản</a>
                </li>`)
                $(".sidebar-menu").append(`  <li><a href="../home/managerItemAdmin.html" class="sidebar-link" id="manaItem"><i class="fas fa-boxes"></i> Quản lí thông tin trang thiết bị</a>
                    `)

    }
}


window.onload = function () {
    document.getElementById('profile').innerHTML =
        `<a href="./profile.html" class="nav-link" id="profile">
                <i class="fas fa-user-circle"></i> 
                ${acc.name}</a>`;
}

document.addEventListener('DOMContentLoaded', function () {
    document.getElementById("staticItem").onclick = function () {
        window.location.href = "../home/staticItem.html";
    }
});
;

// chuyển hướng sang danh sách yêu cầu maintance
document.addEventListener('DOMContentLoaded', function () {
    document.getElementById("listRequest").onclick = function () {
        window.location.href = "../home/listRequest/maintance.html";
    }
});


