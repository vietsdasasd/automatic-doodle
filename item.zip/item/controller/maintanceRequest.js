

let count = 0;

if(sessionStorage.getItem('123') === null){
    window.location.href = "../../register/login.html"

}

var itemId;
let key = getToken(sessionStorage.getItem('123'));
let acc = JSON.parse(decrypt(sessionStorage.getItem('acc'), key));var hexcode;

// check account

if (acc === null) {
    window.location.href = "../../register/login.html";
}else if (acc.PICorStaff === 1) {
    $('.sidebar-menu').append(`<li><a href="../tranferRequest.html" class="sidebar-link" id="transferRequest"><i class="fas fa-exchange-alt"></i>Yêu cầu bàn giao</a></li>`);
    $('.sidebar-menu').append(`<li><a href="../needMaintanceItem.html" class="sidebar-link" id="maintenanceDue"><i class="fas fa-tools"></i> Thiết bị đến hạn</a></li>`);
    if (acc.accountantPIC == 1) {
        $('.sidebar-menu').append(`<li><a href="../registerDevice.html" class="sidebar-link" id="newItem"><i class="fas fa-plus-circle"></i> Đăng kí thiết bị mới</a></li>`);
        $('.sidebar-menu').append(`<li><a href="../../home/newItem.html" class="sidebar-link" id="unknowItem"><i class="fas fa-question-circle"></i> Thiết bị mới </br>  chưa bàn giao</a></li>`);

    }
}else if(acc.PICorStaff === 2){
    $('.sidebar-menu').append(`<li><a href="../tranferRequestManager.html" class="sidebar-link" id="transferRequest"><i class="fas fa-exchange-alt"></i>Yêu cầu bàn giao</a></li>`);
    $('.sidebar-menu').append(`<li><a href="../answerRegisterDeviceManager.html" class="sidebar-link" id="newItem"><i class="fas fa-plus-circle"></i>Đăng kí thiết bị mới</a></li>`);
    $('.sidebar-menu').append(`<li><a href="../../home/newItem.html" class="sidebar-link" id="unknowItem"><i class="fas fa-question-circle"></i> Thiết bị mới </br>  chưa bàn giao</a></li>`);
    if(acc.admin == 1){
        $('.sidebar-menu').append(`<li><a href="../../home/accManaAdmin/accManaStaffAdmin.html" class="sidebar-link" id="unkn"><i
                            class="fas fa-user-shield"></i> Quản lí tài khoản</a></li>`)
                            $(".sidebar-menu").append(`  <li><a href="../managerItemAdmin.html" class="sidebar-link" id="manaItem"><i class="fas fa-boxes"></i> Quản lí thông tin trang thiết bị</a>
                                </li>`)
    }
}


window.onload = function () {
    const currentUrl = window.location.href;
    const url = new URL(currentUrl);
    const urlParams = new URLSearchParams(url.search);
    itemId = urlParams.get('id');

    const staffCodeInput = document.getElementById('staffCode');
    const itemName = document.getElementById("name");
    itemName.value = `${getCategoryByItemId(itemId)} (Mã: ${itemId})`;
    staffCodeInput.value = acc.id;
    document.getElementById('profile').innerHTML =
    `<a href="../profile.html" class="nav-link" id="profile">
            <i class="fas fa-user-circle"></i> 
            ${acc.name}</a>`;

};

const submitButton = document.getElementById('submit-form');

// Bắt sự kiện click vào button Gửi Đơn Đăng Ký
submitButton.addEventListener('click', function() {
    let name = document.getElementById('name').value;
    //thật ra đây là PIC code :)
    let staffCode = document.getElementById('staffCode').value;
    let typeRequest = document.getElementById('typeRequest').value;
    let budgetEstimate = document.getElementById('budgetEstimate').value;
    let reason = document.getElementById('reason').value;
    let extend = document.getElementById('extend').value;

    const input = document.getElementById('image');
    const file = input.files[0];

    if (!name || !staffCode || !typeRequest || !file || !(budgetEstimate || extend) || !reason) {
        alert('Vui lòng điền đầy đủ tất cả thông tin.');
    } else {
        convertToHex().then(hexString => {
            postMaintanceRequest(itemId, staffCode, typeRequest, hexString, budgetEstimate, reason, extend);
        })
        location.reload();
    }
});
// mã hóa ảnh
function convertToHex() {
    return new Promise((resolve, reject) => {
        const input = document.getElementById('image');
        const file = input.files[0];

        if (!file) {
            reject(new Error('Vui lòng chọn một file ảnh.'));
            return;
        }

        const reader = new FileReader();
        reader.onload = function(event) {
            const arrayBuffer = event.target.result;
            const bytes = new Uint8Array(arrayBuffer);
            let hexString = '';

            for (let i = 0; i < bytes.byteLength; i++) {
                let byte = bytes[i].toString(16);
                if (byte.length === 1) {
                    byte = '0' + byte;
                }
                hexString += byte;
            }

            resolve(hexString);
        };

        reader.onerror = function(event) {
            reject(new Error('Failed to read file.'));
        };

        reader.readAsArrayBuffer(file);
    });
}





// chuyển hướng sang danh sách các thiết bị
document.addEventListener('DOMContentLoaded', function () {
    document.getElementById("staticItem").onclick = function () {
        window.location.href = "../staticItem.html";
    }
});

// chuyển hướng sang danh sách yêu cầu
document.addEventListener('DOMContentLoaded', function () {
    document.getElementById("listRequest").onclick = function () {
        window.location.href = "../listRequest/maintance.html";
    }
});


// chuyển hướng sang lịch sử bảo trì
document.addEventListener('DOMContentLoaded', function () {
    document.getElementById("maintanceHistory").onclick = function () {
        window.location.href = `../staticItemDetail/maintanceHistory.html?id=${itemId}`;
    }
});

// chuyển hướng sang lịch sử bàn giao
document.addEventListener('DOMContentLoaded', function () {
    document.getElementById("tranferHistory").onclick = function () {
        window.location.href = `../staticItemDetail/tranferHistory.html?id=${itemId}`;
    }
});

// chuyển hướng sang yêu cầu bảo dưỡng, sửa chữa, thay mới
document.addEventListener('DOMContentLoaded', function () {
    document.getElementById("maintainRequest").onclick = function () {
        window.location.href = `../staticItemDetail/maintanceRequest.html?id=${itemId}`;
    }
});

