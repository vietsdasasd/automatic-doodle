
let count = 0;

if (sessionStorage.getItem('123') === null) {
    window.location.href = "../register/login.html";
}

let key = getToken(sessionStorage.getItem('123'));
let acc = JSON.parse(decrypt(sessionStorage.getItem('acc'), key));console.log(acc)

if (acc === null) {
    window.location.href = "../register/login.html";
} else if (acc.PICorStaff == 1) {

    $('.sidebar-menu').append(`<li><a href="./tranferRequest.html" class="sidebar-link" id="tranferRequest"><i class="fas fa-exchange-alt"></i>Yêu cầu bàn giao</a></li>`);
    $('.sidebar-menu').append(`<li><a href="./needMaintanceItem.html" class="sidebar-link" id="maintenanceDue"><i class="fas fa-tools"></i> Thiết bị đến hạn</a></li>`);
    if (acc.accountantPIC == 1) {
        $('.sidebar-menu').append(`<li><a href="./registerDevice.html" class="sidebar-link" id="newItem"><i class="fas fa-plus-circle"></i> Đăng kí thiết bị mới</a></li>`);
        $('.sidebar-menu').append(`<li><a href="../home/newItem.html" class="sidebar-link" id="unknowItem"><i class="fas fa-question-circle"></i> Thiết bị mới </br>  chưa bàn giao</a></li>`);

    }
} else if (acc.PICorStaff == 2) {

    $('.sidebar-menu').append(`<li><a href="../home/tranferRequestManager.html" class="sidebar-link" id="tranferRequest"><i class="fas fa-exchange-alt"></i>Yêu cầu bàn giao</a></li>`);
    $('.sidebar-menu').append(`<li><a href="./answerRegisterDeviceManager.html" class="sidebar-link" id="newItem"><i class="fas fa-plus-circle"></i>Đăng kí thiết bị mới</a></li>`);
    $('.sidebar-menu').append(`<li><a href="../home/newItem.html" class="sidebar-link" id="unknowItem"><i class="fas fa-question-circle"></i> Thiết bị mới </br>  chưa bàn giao</a></li>`);
    if (acc.admin == 1) {
        $('.sidebar-menu').append(` <li><a href="../home/accManaAdmin/accManaStaffAdmin.html" class="sidebar-link" id="unkn"><i class="fas fa-user-shield"></i> Quản lí tài khoản</a>
                </li>`)
                $(".sidebar-menu").append(`  <li><a href="../home/managerItemAdmin.html" class="sidebar-link" id="manaItem"><i class="fas fa-boxes"></i> Quản lí thông tin trang thiết bị</a>
                    `)

    }
}

window.onload = function () {
    document.getElementById('profile').innerHTML =
        `<a href="#" class="nav-link" id="profile">
                <i class="fas fa-user-circle"></i> 
                ${acc.name}</a>`;
    profileHeader()

}

function profileHeader() {
    let role;
    let password;
    if (acc.PICorStaff == 0) {
        role = "Staff";
        password = getStaffPassword(acc.id);
    } else if (acc.PICorStaff == 1) {
        role = "PIC";
        password = getPICPassword(acc.id);
        if (acc.accountantPIC == 1) {
            role += "+";
        }
    } else {
        password = getManagerPassword(acc.id);
        if (acc.admin == 1) {
            role = "Admin";
        }
        else {
            role = "Manager";
        }
    }


    document.getElementById('email').textContent = acc.email;
    document.getElementById('name').textContent = acc.name;
    document.getElementById('role').textContent = role;
    document.getElementById('name-form').value = acc.name;
    document.getElementById('email-form').value = acc.email;
    document.getElementById('password-form').value = password;
}

function submit() {
    if (confirm("Bạn chắc chắn muốn cập nhật chứ?")) {
        let name = document.getElementById('name-form').value;
        let email = document.getElementById('email-form').value;
        let password = document.getElementById('password-form').value;

        if (name === "" || email === "" || password === "") {
            alert("Không được để trống");
            return;
        }else{
            if (acc.PICorStaff == 0) {
                updateStaffAcc(acc.id, acc.code, password, name, email);
                getStaff(acc.id).then(function (rs) {
                    sessionStorage.setItem('acc', JSON.stringify(rs));
                })
            } else if (acc.PICorStaff == 1) {
                updatePICAcc(acc.id, acc.code, password, name, email);
                getPIC(acc.id).then(function (rs) {
                    sessionStorage.setItem('acc', JSON.stringify(rs));
                })
            } else {
                updateManagerAcc(acc.id, acc.code, password, name, email);
                getManager(acc.id).then(function (rs) {
                    sessionStorage.setItem('acc', JSON.stringify(rs));
                })
            }
            location.reload();
        }
    }
}
