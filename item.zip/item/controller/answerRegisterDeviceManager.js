let acc = JSON.parse(sessionStorage.getItem("acc"));
if (acc === null) {
    window.location.href = "../register/login.html";
}else if(acc.PICorStaff != 2){
    window.location.href = "../home/home.html";
}else if(acc.admin == 1){
    $('.sidebar-menu').append(`<li><a href="../../home/accManaAdmin/accManaStaffAdmin.html" class="sidebar-link" id="unkn"><i>`);
}


var currentPage = 1;
var pageSize = 15; // Số lượng item mỗi trang


// hàm lấy value của nút filter đang được bấm
function getActiveFilterValue() {
    const buttons = document.querySelectorAll('.filter-btn');
    for (let i = 0; i < buttons.length; i++) {
        if (buttons[i].classList.contains('active')) {
            console.log(buttons[i].value)
            return buttons[i].value;
        }
    }
    return "all";
}

function filterItems() {
    const filterBtns = document.querySelectorAll('.filter-btn');

    // Xóa lớp active khỏi tất cả các nút filter
    filterBtns.forEach(btn => {

        btn.classList.remove('active');
        currentPage = 1;
    });

    // Thêm lớp active vào nút được bấm
    event.target.classList.add('active');
    getAllRegisterRequests(1, pageSize, getActiveFilterValue());
}

function renderPagination(totalPages) {
    const paginationElement = document.getElementById('pagination');
    paginationElement.innerHTML = ''; // Xóa nội dung cũ trước khi render lại

    for (let i = 1; i <= totalPages; i++) {
        let pageButton = document.createElement('button');
        pageButton.classList.add('page-link');
        pageButton.textContent = i;
        pageButton.id = i;

        if (i === currentPage) {
            pageButton.classList.add('active');
        }

        pageButton.onclick = function () {
            currentPage = i;
            getAllRegisterRequests(i, pageSize, getActiveFilterValue())
        };

        paginationElement.appendChild(pageButton);
    }
}

// chuyển hướng khi ấn vào thông tin chi tiết
$(document).ready(function () {
    $(document).on('click', '.more-info', function () {
        const itemId = $(this).data('id');
        window.location.href = `./answerRegisterDeviceManagerDetail.html?id=${itemId}`;
    });
});


window.onload = function () {
    getAllRegisterRequests(currentPage, pageSize, getActiveFilterValue());
    document.getElementById('profile').innerHTML =
    `<a href="./profile.html" class="nav-link" id="profile">
            <i class="fas fa-user-circle"></i> 
            ${acc.name}</a>`;
}