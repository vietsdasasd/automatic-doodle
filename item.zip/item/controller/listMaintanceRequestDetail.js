
let count = 0;

if(sessionStorage.getItem('123') === null){
    window.location.href = "../../register/login.html"

}
// check account
let key = getToken(sessionStorage.getItem('123'));
let acc = JSON.parse(decrypt(sessionStorage.getItem('acc'), key));if (acc === null) {
    window.location.href = "../../register/login.html";
} else if (acc.PICorStaff === 1) {
    $('.sidebar-menu').append(`<li><a href="../tranferRequest.html" class="sidebar-link" id="transferRequest"><i class="fas fa-exchange-alt"></i>Yêu cầu bàn giao</a></li>`);
    $('.sidebar-menu').append(`<li><a href="../needMaintanceItem.html" class="sidebar-link" id="maintenanceDue"><i class="fas fa-tools"></i> Thiết bị đến hạn</a></li>`);
    if (acc.accountantPIC == 1) {
        $('.sidebar-menu').append(`<li><a href="../registerDevice.html" class="sidebar-link" id="newItem"><i class="fas fa-plus-circle"></i> Đăng kí thiết bị mới</a></li>`);
        $('.sidebar-menu').append(`<li><a href="../../home/newItem.html" class="sidebar-link" id="unknowItem"><i class="fas fa-question-circle"></i> Thiết bị mới </br>  chưa bàn giao</a></li>`);

    }
} else if (acc.PICorStaff === 2) {
    $('.sidebar-menu').append(`<li><a href="../tranferRequestManager.html" class="sidebar-link" id="transferRequest"><i class="fas fa-exchange-alt"></i>Yêu cầu bàn giao</a></li>`);
    $('.sidebar-menu').append(`<li><a href="../answerRegisterDeviceManager.html" class="sidebar-link" id="newItem"><i class="fas fa-plus-circle"></i>Đăng kí thiết bị mới</a></li>`);
    $('.sidebar-menu').append(`<li><a href="../../home/newItem.html" class="sidebar-link" id="unknowItem"><i class="fas fa-question-circle"></i> Thiết bị mới </br>  chưa bàn giao</a></li>`);
    if (acc.admin == 1) {
        $('.sidebar-menu').append(`<li><a href="../../home/accManaAdmin/accManaStaffAdmin.html" class="sidebar-link" id="unkn"><i
                            class="fas fa-user-shield"></i> Quản lí tài khoản</a></li>`)
        $(".sidebar-menu").append(`  <li><a href="../managerItemAdmin.html" class="sidebar-link" id="manaItem"><i class="fas fa-boxes"></i> Quản lí thông tin trang thiết bị</a>
                                </li>`)
    }
}

let infor
const currentUrl = window.location.href;
const url = new URL(currentUrl);
const urlParams = new URLSearchParams(url.search);
idMaintanceRequest = urlParams.get('idMaintanceRequest');
console.log(idMaintanceRequest);

infor = getMaintanceRequestById(idMaintanceRequest);

document.getElementById("title").textContent += `(${infor.status}): yêu cầu ${infor.type} ${getCategoryByIdItem(infor.idItem)} (mã: ${infor.idItem})`
getAllMaintanceHistory(infor.idItem);

window.onload = function () {
    document.getElementById('profile').innerHTML =
        `<a href="../profile.html" class="nav-link" id="profile">
            <i class="fas fa-user-circle"></i> 
            ${acc.name}</a>`;
    // nếu là manager và request chưa được trả lời thì hiện ra nút chấp nhận và từ chối
    if (acc.PICorStaff == 2 && infor.status == "Đang chờ") {
        $("#submit").append(`<div class="reason-section" style="margin-top: 20px;">
                    <label for="reason" style="display: block; margin-bottom: 10px;">Lí do từ chối:</label>
                    <textarea id="reason" rows="4" cols="50"
                        style="padding: 10px; border: 1px solid #ccc; border-radius: 5px; font-size: 14px; width: 100%; max-width: 500px; box-sizing: border-box;"></textarea>
                </div>

                <!-- Nút Submit -->
                <div style="display: flex; align-items: center; justify-content: start; gap: 10px; margin-top: 30px;">
                    <button id="accept"
                        style="padding: 10px 20px; border: none; border-radius: 5px; background-color: #4CAF50; color: white; cursor: pointer;">Chấp
                        nhận</button>
                    <button id="reject"
                        style="padding: 10px 20px; border: none; border-radius: 5px; background-color: #f44336; color: white; cursor: pointer;">Từ
                        chối</button>
                </div>`)
    } else if (infor.status != "Đang chờ") {
        $("#submit").append(`Lí do ${infor.status}: ${infor.reasonManager}`);
    }

}

console.log(infor);
$(document).ready(function () {
    // Event delegation for the accept button
    $(document).on('click', '#accept', function () {
        // Show confirmation dialog
        if (confirm('Bạn có chắc chắn muốn chấp nhận yêu cầu này?')) {
            // khi bảo trì xong phải cập nhật maintanceRequested thành 0
            if (infor.type != "Gia hạn") {
                let type;
                if (infor.type == "Bảo dưỡng") {
                    type = "Đang bảo dưỡng";
                } else if (infor.type == "Sửa chữa") {
                    type = "Đang sửa";
                } else {
                    type = "Bỏ";
                    postUpdateBorItem(infor.idItem)
                }
                postUpdateMaintanceItem(type, infor.idItem);
            } else {
                postUpdateExtendItem(infor.idItem, infor.extend);
            }
            postUpdateStatusMaintanceRequest("Chấp nhận", "", infor.idMaintanceRequest);
        } else {

        }

        location.reload();
    });

    // Event delegation for the reject button
    $(document).on('click', '#reject', function () {
        // Show confirmation dialog
        if (confirm('Bạn có chắc chắn muốn từ chối yêu cầu này?')) {
            // User clicked "OK"
            var rejectionReason = $('#reason').val();
            console.log('Rejected with reason:', rejectionReason);
            postUpdateStatusMaintanceRequest("Từ chối", rejectionReason, infor.idMaintanceRequest)
            postUpdateRequestedItem(0, infor.idItem);
            location.reload();
        } else {

        }
    });
});

