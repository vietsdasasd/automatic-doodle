
let count = 0;

if(sessionStorage.getItem('123') === null){
    window.location.href = "../register/login.html"


}

let key = getToken(sessionStorage.getItem('123'));
let acc = JSON.parse(decrypt(sessionStorage.getItem('acc'), key));if (acc === null) {
    window.location.href = "../register/login.html"
}
else if (acc.PICorStaff !== 1) {
    window.location.href = "../home/home.html"
} else {
    $('.sidebar-menu').append(`<li><a href="../home/tranferRequest.html" class="sidebar-link" id="tranferRequest"><i class="fas fa-exchange-alt"></i> Yêu cầu bàn giao</a></li>`);
    $('.sidebar-menu').append(`<li><a href="#" class="sidebar-link" id="maintenanceDue"><i class="fas fa-tools"></i> Thiết bị đến hạn</a></li>`);
    if (acc.accountantPIC == 1) {
        $('.sidebar-menu').append(`<li><a href="./registerDevice.html" class="sidebar-link" id="newItem"><i class="fas fa-plus-circle"></i> Đăng kí thiết bị mới</a></li>`);
        $('.sidebar-menu').append(`<li><a href="../home/newItem.html" class="sidebar-link" id="unknowItem"><i class="fas fa-question-circle"></i> Thiết bị mới </br>  chưa bàn giao</a></li>`);
    }
}

window.onload = function () {
    getNeedToMaintanceItem(acc.id);
    document.getElementById('profile').innerHTML =
        `<a href="./profile.html" class="nav-link" id="profile">
                <i class="fas fa-user-circle"></i> 
                ${acc.name}</a>`;
}
// chuyển hướng sang tạo đơn bảo trì
$(document).ready(function () {
    $(document).on('click', '.more-info', function () {
        const itemId = $(this).data('id');
        window.location.href = `../home/staticItemDetail/maintanceRequest.html?id=${itemId}`;
    });
});


// chuyển sang danh sách item
document.addEventListener('DOMContentLoaded', function () {
    document.getElementById("staticItem").onclick = function () {
        window.location.href = "../home/staticItem.html";
    }
});


document.addEventListener('DOMContentLoaded', function () {
    document.getElementById("listRequest").onclick = function () {
        window.location.href = `../home/listRequest/maintance.html`;
    }
});