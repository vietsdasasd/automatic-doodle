
sessionStorage.removeItem('acc');

var usernameField = document.getElementById("username");
var passwordField = document.getElementById("password");
var loginForm = document.getElementById("submit");
const currentUrl = window.location.href;
const url = new URL(currentUrl);
const urlParams = new URLSearchParams(url.search);
locationCheck = urlParams.get('location');



loginForm.onclick = function (event) {
    event.preventDefault();
    if (usernameField.value.trim() === "" || passwordField.value.trim() === "") {
        alert("Vui lòng điền đầy đủ thông tin đăng nhập.");
    } else {
        checkStaffAccount(usernameField.value.trim(), passwordField.value.trim())
            .then(function (result) {
                if (result) {
                    alert("Đăng nhập thành công với tài khoản staff");
                    sessionStorage.setItem('acc', JSON.stringify(result));
                    if (locationCheck == "itemDetail") {
                        window.location.href = `../home/staticItemDetail/maintanceHistory.html?id=${urlParams.get('id')}`;
                    } else {
                        window.location.href = "../home/home.html";
                    }

                } else {
                    checkPICAccount(usernameField.value.trim(), passwordField.value.trim())
                        .then(function (rs) {
                            if (rs) {
                                alert("Đăng nhập thành công với tài khoản PIC");
                                sessionStorage.setItem("acc", JSON.stringify(rs));
                                if (locationCheck == 'needMaintanceItem') {
                                    window.location.href = "../home/needMaintanceItem.html";
                                } else if (locationCheck == "itemDetail") {
                                    window.location.href = `../home/staticItemDetail/maintanceHistory.html?id=${urlParams.get('id')}`;
                                } else {
                                    window.location.href = "../home/home.html";
                                }


                            } else {
                                checkManagerAccount(usernameField.value.trim(), passwordField.value.trim())
                                    .then(function (rs) {
                                        if (rs) {
                                            sessionStorage.setItem("acc", JSON.stringify(rs));
                                            if (rs.admin == 0) {
                                                alert("Đăng nhập thành công với tài khoản Manager");
                                               
                                                if (locationCheck == "listMaintanceRequest") {
                                                    window.location.href = "../home/listRequest/maintance.html";
                                                } else if (location == "answerNewDeviceRequest") {
                                                    window.location.href = "../home/listRequest/newDeviceRequest.html";
                                                } else if (locationCheck == "itemDetail") {
                                                    window.location.href = `../home/staticItemDetail/maintanceHistory.html?id=${urlParams.get('id')}`;
                                                }
                                                else {
                                                    window.location.href = "../home/home.html";
                                                }
                                            } else {
                                                alert("Đăng nhập thành công với tài khoản Admin");
                                                window.location.href = "../home/accManaAdmin/accManaStaffAdmin.html";
                                            }
                                        } else {
                                            alert("Tài khoản không tồn tại.");
                                        }
                                    })
                            }
                        })
                }
            })
            .catch(function (error) {
                console.error('Lỗi khi kiểm tra tài khoản:', error);
            });

    }
};


