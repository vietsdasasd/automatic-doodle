
sessionStorage.removeItem('acc');
sessionStorage.removeItem('123')
var usernameField = document.getElementById("username");
var passwordField = document.getElementById("password");
var loginForm = document.getElementById("submit");
const currentUrl = window.location.href;
const url = new URL(currentUrl);
const urlParams = new URLSearchParams(url.search);
locationCheck = urlParams.get('location');

document.addEventListener('keydown', function (event) {
    if (event.key === 'Enter') {

        loginForm.click();
    }
});

loginForm.onclick = function (event) {
    event.preventDefault();
    if (usernameField.value.trim() === "" || passwordField.value.trim() === "") {
        alert("Vui lòng điền đầy đủ thông tin đăng nhập.");
    } else {
        checkStaffAccount(usernameField.value.trim(), passwordField.value.trim())
            .then(function (result) {
                if (result) {
                    alert("Đăng nhập thành công với tài khoản staff");
                    let key = generateRandomString(98);
                    sessionStorage.setItem('123', postToken(key));
                    sessionStorage.setItem('acc', encrypt(JSON.stringify(result), key));
                    if (locationCheck == "itemDetail") {
                        window.location.href = `../home/staticItemDetail/maintanceHistory.html?id=${urlParams.get('id')}`;
                    } else {
                        window.location.href = "../home/home.html";
                    }
                } else {
                    checkPICAccount(usernameField.value.trim(), passwordField.value.trim())
                        .then(function (rs) {
                            if (rs) {
                                alert("Đăng nhập thành công với tài khoản PIC");
                                let key = generateRandomString(98);
                                sessionStorage.setItem('123', postToken(key));
                                sessionStorage.setItem('acc', encrypt(JSON.stringify(rs), key));

                                if (locationCheck == 'needMaintanceItem') {
                                    window.location.href = "../home/needMaintanceItem.html";
                                } else if (locationCheck == "itemDetail") {
                                    window.location.href = `../home/staticItemDetail/maintanceHistory.html?id=${urlParams.get('id')}`;
                                } else {
                                    window.location.href = "../home/home.html";
                                }
                            } else {
                                checkManagerAccount(usernameField.value.trim(), passwordField.value.trim())
                                    .then(function (rs) {
                                        if (rs) {
                                            let key = generateRandomString(98);
                                            sessionStorage.setItem('123', postToken(key));
                                            sessionStorage.setItem('acc', encrypt(JSON.stringify(rs), key));
                                            if (rs.admin == 0) {
                                                alert("Đăng nhập thành công với tài khoản Manager");
                                                if (locationCheck == "listMaintanceRequest") {
                                                    window.location.href = "../home/listRequest/maintance.html";
                                                } else if (location == "answerNewDeviceRequest") {
                                                    window.location.href = "../home/listRequest/newDeviceRequest.html";
                                                } else if (locationCheck == "itemDetail") {
                                                    window.location.href = `../home/staticItemDetail/maintanceHistory.html?id=${urlParams.get('id')}`;
                                                } else if (locationCheck == "addNewItemRequest") {
                                                    window.location.href = "../home/answerRegisterDeviceManager.html";
                                                }
                                                else {
                                                    window.location.href = "../home/home.html";
                                                }
                                            } else {
                                                alert("Đăng nhập thành công với tài khoản Admin");
                                                window.location.href = "../home/accManaAdmin/accManaStaffAdmin.html";
                                            }
                                        } else {
                                            alert("Tài khoản không tồn tại.");
                                        }
                                    })
                            }
                        })
                }
            })
            .catch(function (error) {
                console.error('Lỗi khi kiểm tra tài khoản:', error);
            });

    }
};





function generateRandomString(length) {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    const charactersLength = characters.length;
    for (let i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
}


