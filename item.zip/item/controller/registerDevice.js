let acc = JSON.parse(sessionStorage.getItem("acc"));
if (acc === null) {
    window.location.href = "../register/login.html"
}
else if (acc.PICorStaff !== 1 || acc.accountantPIC !== 1) {
    window.location.href = "../home/home.html"
}

let listOrder = [];
let count = 0;


// Function để kiểm tra xem các trường đã được điền đầy đủ hay chưa
function validateFields() {
    var category = document.getElementById('category').value;
    var quantity = document.getElementById('quantity').value;
    var image = document.getElementById('image').value;
    var maintenanceCycle = document.getElementById('maintenanceCycle').value;
    var renewCycle = document.getElementById('renewCycle').value;
    var PO = document.getElementById('PO').value;
    var other = document.getElementById('textInput').value;

    // Kiểm tra điều kiện, ví dụ: tên thiết bị (category) đã được chọn chưa
    if ((category == 'Other' && other === "") || quantity === '' || image === '' || maintenanceCycle === '' || renewCycle === '' || PO === '') {
        return false;
    }
    return true;
}

// Function để thêm mục vào danh sách
function addToList() {
    if (!validateFields()) {
        alert('Vui lòng điền đầy đủ thông tin trước khi thêm vào danh sách.');
        return;
    }
    let name = '';
    var categoryName = document.getElementById('category').options[document.getElementById('category').selectedIndex].textContent;
    var category = document.getElementById('category').value;
    if (category === 'Other') {
        category = null
        name = document.getElementById('textInput').value;
        categoryName = name;
    }
    var quantity = document.getElementById('quantity').value;
    var image = document.getElementById('image').value;
    var maintenanceCycle = document.getElementById('maintenanceCycle').value;
    var renewCycle = document.getElementById('renewCycle').value;
    var PO = document.getElementById('PO').value;
    
    var listContainer = document.getElementById('list-container');
    var newItem = document.createElement('div');


    convertToHex().then(hexString => {
        listOrder.push({
            category: category,
            name: name,
            quantity: quantity,
            image: hexString,
            maintenanceCycle: maintenanceCycle,
            renewCycle: renewCycle,
            id: count.toString(),
            PO: PO
        });
    })
    console.log(listOrder);
    newItem.classList.add('item');
    newItem.innerHTML = `
        <p><strong>Tên thiết bị:</strong> ${categoryName}</p>
        <p><strong>Số lượng:</strong> ${quantity}</p>
        <p><strong>Mã PO:</strong> ${PO}</p>
        <p><strong>Chu kì bảo dưỡng:</strong> ${maintenanceCycle} tháng</p>
        <p><strong>Chu kì thay mới:</strong> ${renewCycle} tháng</p>
        <button class="remove-item" data-item-id="${count++}" onclick="removeItem(this)">Xóa danh mục</button>
        <hr>
    `;
    listContainer.appendChild(newItem);

    // Reset các trường nhập liệu sau khi thêm vào danh sách
    clearFields();
    // Hiển thị ảnh đã chọn

}

// Function để xóa mục trong danh sách
function removeItem(element) {
    
    var item = element.parentElement;
    var idList = element.getAttribute('data-item-id');
    for (let i = 0; i < listOrder.length; i++) {
        if (listOrder[i].id == idList) {
            listOrder.splice(i, 1);
            break;
        }
    }
    item.remove();

}

// Function để xóa dữ liệu trên các trường nhập liệu
function clearFields() {
    document.getElementById('category').value = '';
    document.getElementById('textInput').value = '';
    document.getElementById('quantity').value = '';
    document.getElementById('image').value = '';
    document.getElementById('maintenanceCycle').value = '';
    document.getElementById('renewCycle').value = '';
}



// Function để kiểm tra phím nhập vào có phải là số không
function isNumberKey(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}

// Function để xử lý khi người dùng thay đổi lựa chọn danh mục
function handleInputChange() {
    var category = document.getElementById('category').value;
    var textInput = document.getElementById('textInput');

    // Hiển thị hoặc ẩn trường nhập liệu khi chọn Other
    if (category === 'Other') {
        textInput.style.display = 'block';
    } else {
        textInput.style.display = 'none';
    }

    // Reset trường nhập liệu ảnh khi thay đổi danh mục
    clearImageInput();
}

// Function để xóa dữ liệu trên trường nhập liệu ảnh
function clearImageInput() {
    var fileInput = document.getElementById('image');
    fileInput.value = ''; // Xóa dữ liệu trường nhập liệu ảnh
    var previewImage = document.getElementById('preview-image');
    previewImage.style.display = 'none'; // Ẩn ảnh đã chọn
}






window.onload = function () {
    getAllCategory();
    const option = document.createElement('option')
    option.value = "Other";
    option.textContent = "Other";
    document.getElementById('category').appendChild(option);
    document.getElementById('profile').innerHTML =
        `<a href="./profile.html" class="nav-link" id="profile">
                <i class="fas fa-user-circle"></i> 
                ${acc.name}</a>`;
}

// hàm nộp yêu cầu
async function submit() {
    const isConfirmed = confirm("Bạn có chắc chắn muốn gửi yêu cầu này không?");
    if (isConfirmed) {
        if (listOrder.length === 0) {
            alert("Vui lòng thêm thiết bị vào danh sách trước khi gửi yêu cầu.")
            return;
        }
        await postRegisterDevice(listOrder);
        console.log("Thông tin đã được gửi.");
    } else {
        console.log("Hành động đã bị hủy.");
    }
}


// mã hóa ảnh
function convertToHex() {
    return new Promise((resolve, reject) => {
        const input = document.getElementById('image');
        const file = input.files[0];

        if (!file) {
            reject(new Error('Vui lòng chọn một file ảnh.'));
            return;
        }

        const reader = new FileReader();
        reader.onload = function(event) {
            const arrayBuffer = event.target.result;
            const bytes = new Uint8Array(arrayBuffer);
            let hexString = '';

            for (let i = 0; i < bytes.byteLength; i++) {
                let byte = bytes[i].toString(16);
                if (byte.length === 1) {
                    byte = '0' + byte;
                }
                hexString += byte;
            }

            resolve(hexString);
        };

        reader.onerror = function(event) {
            reject(new Error('Failed to read file.'));
        };

        reader.readAsArrayBuffer(file);
    });
}
