
let count = 0;

if (sessionStorage.getItem('123') === null){
    window.location.href = "../register/login.html";
}
let key = getToken(sessionStorage.getItem('123'));
let acc = JSON.parse(decrypt(sessionStorage.getItem('acc'), key));if (acc === null) {
    window.location.href = "../register/login.html";
}else if (acc.PICorStaff === 1) {
    $('.sidebar-menu').append(`<li><a href="./tranferRequest.html" class="sidebar-link" id="transferRequest"><i class="fas fa-exchange-alt"></i>Yêu cầu bàn giao</a></li>`);
    $('.sidebar-menu').append(`<li><a href="./needMaintanceItem.html" class="sidebar-link" id="maintenanceDue"><i class="fas fa-tools"></i> Thiết bị đến hạn</a></li>`);
    if (acc.accountantPIC == 1) {
        $('.sidebar-menu').append(`<li><a href="./registerDevice.html" class="sidebar-link" id="newItem"><i class="fas fa-plus-circle"></i> Đăng kí thiết bị mới</a></li>`);
        $('.sidebar-menu').append(`<li><a href="../home/newItem.html" class="sidebar-link" id="unknowItem"><i class="fas fa-question-circle"></i> Thiết bị mới </br>  chưa bàn giao</a></li>`);
    }
}else if(acc.PICorStaff === 2){
    $('.sidebar-menu').append(`<li><a href="./tranferRequestManager.html" class="sidebar-link" id="transferRequest"><i class="fas fa-exchange-alt"></i>Yêu cầu bàn giao</a></li>`);
    $('.sidebar-menu').append(`<li><a href="./answerRegisterDeviceManager.html" class="sidebar-link" id="newItem"><i class="fas fa-plus-circle"></i>Đăng kí thiết bị mới</a></li>`);
    $('.sidebar-menu').append(`<li><a href="../home/newItem.html" class="sidebar-link" id="unknowItem"><i class="fas fa-question-circle"></i> Thiết bị mới </br>  chưa bàn giao</a></li>`);
    if(acc.admin == 1){
        $('.sidebar-menu').append(` <li><a href="../home/accManaAdmin/accManaStaffAdmin.html" class="sidebar-link" id="unkn"><i class="fas fa-user-shield"></i> Quản lí tài khoản</a>
                </li>`)
                $(".sidebar-menu").append(`  <li><a href="../home/managerItemAdmin.html" class="sidebar-link" id="manaItem"><i class="fas fa-boxes"></i> Quản lí thông tin trang thiết bị</a>
                    `)
    
    }
}


const currentUrl = window.location.href;
const url = new URL(currentUrl);
const urlParams = new URLSearchParams(url.search);
// idMaintanceRequest = urlParams.get('idMaintanceRequest');

var currentPage = urlParams.get('page') != null ? parseInt(urlParams.get('page')) : 1; // Trang hiện tại
var pageSize = 15; // Số lượng item mỗi trang
var filter = urlParams.get('filter') != null ? urlParams.get('filter') : "all"; // Lọc theo category
var advanFilter = urlParams.get('advanFilter') != null ? urlParams.get('advanFilter') : ""; // Lọc theo category

 

// hàm tạo ra các nút phân trang
function renderPagination(totalPages) {
    const paginationElement = document.getElementById('pagination');
    paginationElement.innerHTML = ''; // Xóa nội dung cũ trước khi render lại

    for (let i = 1; i <= totalPages; i++) {
        let pageButton = document.createElement('button');
        pageButton.classList.add('page-link');
        pageButton.textContent = i;
        pageButton.id = i;

        if (i === currentPage) {
            pageButton.classList.add('active');
        }

        pageButton.onclick = function () {
            currentPage = i;
            window.location.href = `../home/staticItem.html?advanFilter=${advanFilter}&page=${currentPage}&filter=${filter}`;
        };

        paginationElement.appendChild(pageButton);
    }
}

// xử lý sự kiện filter

// hàm lấy value của nút filter đang được bấm
function getActiveFilterValue() {
    const buttons = document.querySelectorAll('.filter-btn');
    for (let i = 0; i < buttons.length; i++) {
        if (buttons[i].classList.contains('active')) {
            console.log(buttons[i].value)
            return buttons[i].value;
        }
    }
    return "all";
}

function filterItems() {

    window.location.href = `../home/staticItem.html?advanFilter=${advanFilter}&page=1&filter=${event.target.value}`;

}


function activeFilter() {
    const filterBtns = document.querySelectorAll('.filter-btn');
    filterBtns.forEach(btn => {

        btn.classList.remove('active');
       
    });

    filterBtns.forEach(btn => {
        if (btn.value === filter) {
            btn.classList.add('active');
        }
    });
}


//đổ dữ liệu khu vào filter combobox theo idWarehouse
document.addEventListener("DOMContentLoaded", function () {
    const selectElement = document.getElementById('Warehouse');

    selectElement.addEventListener('change', function () {
        const selectedOption = selectElement.value;
        getAllRegionByWarehouse(selectedOption)
    });
});



// xử lí phần cửa sổ popup
const filterBtn = document.getElementById('filterBtn');
const filterPopup = document.getElementById('filterPopup');
const overlay = document.querySelector('.overlay');

filterBtn.addEventListener('click', function () {
    filterPopup.classList.toggle('active');
    overlay.classList.toggle('active');

});

function closePopup() {
    filterPopup.classList.remove('active');
    overlay.classList.remove('active');
}

function applyFilters() {
    const startDate = document.getElementById("startTime").value;
    const endDate = document.getElementById("endTime").value; 
    const category = document.getElementById("category").value;
    const status = document.getElementById("status").value;
    const Warehouse = document.getElementById("Warehouse").value;
    const region = document.getElementById("region").value;

    advanFilter = `${startDate},${endDate},${category},${status},${Warehouse},${region}`;

    window.location.href = `../home/staticItem.html?advanFilter=${advanFilter}&page=1&filter=filter`;
    closePopup();
}
// xóa đi các option của region khi warehouse thay đổi
function handleSelectChange() {
    // Lấy thẻ select từ DOM
    const selectElement = document.getElementById('region');

    const options = selectElement.querySelectorAll('option');

    // Lặp qua từng option (bắt đầu từ index 1 để bỏ qua option đầu tiên)
    for (let i = 1; i < options.length; i++) {
        // Xóa option khỏi select
        selectElement.removeChild(options[i]);
    }
}

// chuyển hướng khi ấn vào thông tin chi tiết
$(document).ready(function () {
    $(document).on('click', '.more-info', function () {
        const itemId = $(this).data('id');
        window.location.href = `../home/staticItemDetail/maintanceHistory.html?id=${itemId}`;
    });
});

// xử lí khi bấm vào nút kích hoạt
$(document).ready(function () {
    $(document).on('click', '.activeI', function () {
        //trong infor lưu 1 chuỗi gồm id và biến biểu thị thiết bị đã từng được hoạt động lần nào chưa(0, 1)
        const infor = $(this).data('id');
        const itemId = parseInt(splitStringBySpace(infor)[0]);
        // đây để check xem thiết bị đã từng được hoạt động chưa
        const activedOrNot = parseInt(infor.split(",")[1]);
        if (confirm(`Bạn muốn kích hoạt thiết bị id: ${itemId}?`)) {
            postUpdateItemStatus(itemId, "Hoạt động", activedOrNot);
            window.location.reload();
        }else{
          
        }
    });
});

// xử lí khi bấm vào nút dự phòng
$(document).ready(function () {
    $(document).on('click', '.deactive', function () {
        const itemId = $(this).data('id');
        if (confirm(`Bạn muốn cho thiết bị id: ${itemId} thành dự phòng?`)) {
            postUpdateItemStatus(itemId, "Dự phòng", 0);
            window.location.reload();   
        }else{
          
        }
    });
});

document.addEventListener('DOMContentLoaded', function () {
    document.getElementById("listRequest").onclick = function () {
        window.location.href = `../home/listRequest/maintance.html`;
    }
});

//hàm tách chuoix theo dấu cách
function splitStringBySpace(inputString) {
    return inputString.split(/\s+/);
}

window.onload = function () {
    getAllItem(currentPage, pageSize, filter, advanFilter);
    getAllCategory();
    getAllStatus();
    getAllWarehouse(); 
    activeFilter()
    document.getElementById('profile').innerHTML =
        `<a href="./profile.html" class="nav-link" id="profile">
                <i class="fas fa-user-circle"></i> 
                ${acc.name}</a>`;

                if(acc.PICorStaff != 0){
                    addColumnToEnd("Chuyển trạng thái",[]);
                }
}


function addColumnToEnd(headerContent, cellContents) {
    var thead = document.querySelector('thead');
    if (!thead) return; 
    var headerRow = thead.querySelector('tr');

    var newTh = document.createElement('th');
    newTh.textContent = headerContent;

    headerRow.appendChild(newTh);

    var rows = document.querySelectorAll('tbody tr');

    rows.forEach(function(row, index) {
        var newTd = document.createElement('td');
        newTd.textContent = cellContents[index] || ''; 
        row.appendChild(newTd);
    });
}