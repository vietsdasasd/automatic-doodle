
let count = 0;

if(sessionStorage.getItem('123') === null){
    window.location.href = "../../register/login.html"

}

let key = getToken(sessionStorage.getItem('123'));
let acc = JSON.parse(decrypt(sessionStorage.getItem('acc'), key));if (acc === null) {
    window.location.href = "../../register/login.html"
}
else if (acc.PICorStaff == 0) {
    window.location.href = "../../home/home.html"
} else if (acc.PICorStaff == 1) {
    $('.sidebar-menu').append(`<li><a href="../tranferRequest.html" class="sidebar-link" id="tranferRequest"><i class="fas fa-exchange-alt"></i> Yêu cầu bàn giao</a></li>`);
    $('.sidebar-menu').append(`<li><a href="../needMaintanceItem.html" class="sidebar-link" id="maintenanceDue"><i class="fas fa-tools"></i> Thiết bị đến hạn</a></li>`);
    if (acc.accountantPIC == 1) {
        $('.sidebar-menu').append(`<li><a href="../registerDevice.html" class="sidebar-link" id="newItem"><i class="fas fa-plus-circle"></i> Đăng kí thiết bị mới</a></li>`);
        $('.sidebar-menu').append(`<li><a href="../../home/newItem.html" class="sidebar-link" id="unknowItem"><i class="fas fa-question-circle"></i> Thiết bị mới </br>  chưa bàn giao</a></li>`);

    }
} else if (acc.PICorStaff == 2) {
    $('.sidebar-menu').append(`<li><a href="../tranferRequestManager.html" class="sidebar-link" id="tranferRequest"><i class="fas fa-exchange-alt"></i> Yêu cầu bàn giao</a></li>`);
    $('.sidebar-menu').append(`<li><a href="../answerRegisterDeviceManager.html" class="sidebar-link" id="newItem"><i class="fas fa-plus-circle"></i>Đăng kí thiết bị mới</a></li>`);
    $('.sidebar-menu').append(`<li><a href="../../home/newItem.html" class="sidebar-link" id="unknowItem"><i class="fas fa-question-circle"></i> Thiết bị mới </br>  chưa bàn giao</a></li>`);
    if (acc.admin == 1) {
        $('.sidebar-menu').append(`<li><a href="../../home/accManaAdmin/accManaStaffAdmin.html" class="sidebar-link" id="unkn"><i
                            class="fas fa-user-shield"></i> Quản lí tài khoản</a></li>`)
        $(".sidebar-menu").append(`  <li><a href="../managerItemAdmin.html" class="sidebar-link" id="manaItem"><i class="fas fa-boxes"></i> Quản lí thông tin trang thiết bị</a>
                                </li>`)
    }
}


var currentPage = 1;
var pageSize = 15; // Số lượng item mỗi trang
var advanFilter = "";
// Lấy danh sách các nút filter
const filterButtons = document.querySelectorAll('.filter-btn');

// Hàm tạo phân trang
function renderPagination(totalPages) {
    const paginationElement = document.getElementById('pagination');
    paginationElement.innerHTML = ''; // Xóa nội dung cũ trước khi render lại

    for (let i = 1; i <= totalPages; i++) {
        let pageButton = document.createElement('button');
        pageButton.classList.add('page-link');
        pageButton.textContent = i;
        pageButton.id = i;

        if (i === currentPage) {
            pageButton.classList.add('active');
        }

        pageButton.onclick = function () {
            currentPage = i;
            getAllTranferRequest(i, pageSize, getActiveFilterValue(), acc.id);
        };

        paginationElement.appendChild(pageButton);
    }
}

// Hàm lấy value của nút filter đang được bấm
function getActiveFilterValue() {
    const activeButton = document.querySelector('.filter-btn.active');
    return activeButton ? activeButton.value : "all";
}

// Đặt sự kiện click cho từng nút filter
filterButtons.forEach(button => {
    button.addEventListener('click', function (event) {
        // Loại bỏ lớp active khỏi tất cả các nút filter
        filterButtons.forEach(btn => btn.classList.remove('active'));

        // Thêm lớp active cho nút được click
        this.classList.add('active');
        currentPage = 1;

        getAllTranferRequest(currentPage, pageSize, getActiveFilterValue(), acc.id);
    });
});

// Hàm filter nhanh
function filterItems(event) {
    const filterBtns = document.querySelectorAll('.filter-btn');

    // Xóa lớp active khỏi tất cả các nút filter
    filterBtns.forEach(btn => btn.classList.remove('active'));


    currentPage = 1;

    getAllTranferRequest(1, pageSize, getActiveFilterValue(), acc.id);
}




// xóa đi các option của region khi warehouse thay đổi
function handleSelectChange() {
    // Lấy thẻ select từ DOM
    const selectElement = document.getElementById('region');

    // Lấy danh sách các option
    const options = selectElement.querySelectorAll('option');

    // Lặp qua từng option (bắt đầu từ index 1 để bỏ qua option đầu tiên)
    for (let i = 1; i < options.length; i++) {
        // Xóa option khỏi select
        selectElement.removeChild(options[i]);
    }
}




// Bắt sự kiện click cho nút "Chi tiết"
$(document).on('click', '.more-info', function () {

    var idTranferRequest = $(this).data('id');

    window.location.href = `../listRequest/tranferDetail.html?idTranferRequest=${idTranferRequest}`
});


window.onload = function () {
    getAllTranferRequest(currentPage, pageSize, getActiveFilterValue(), acc.id);
    document.getElementById('profile').innerHTML =
        `<a href="../profile.html" class="nav-link" id="profile">
            <i class="fas fa-user-circle"></i> 
            ${acc.name}</a>`;
}

// Chuyển hướng sang danh sách các thiết bị
document.addEventListener('DOMContentLoaded', function () {
    document.getElementById("staticItem").onclick = function () {
        window.location.href = "../staticItem.html";
    }
});

document.addEventListener('DOMContentLoaded', function () {
    document.getElementById("maintanceHistory").onclick = function () {
        window.location.href = "../listRequest/maintance.html";
    }
});


