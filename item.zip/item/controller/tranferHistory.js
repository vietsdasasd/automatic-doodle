
let count = 0;

if(sessionStorage.getItem('123') === null){
    window.location.href = "../../register/login.html"

}
var itemId;
let key = getToken(sessionStorage.getItem('123'));
let acc = JSON.parse(decrypt(sessionStorage.getItem('acc'), key));
if (acc === null) {
    window.location.href = "../../register/login.html";
} else if (acc.PICorStaff === 1) {
    $('.sidebar-menu').append(`<li><a href="../tranferRequest.html" class="sidebar-link" id="transferRequest"><i class="fas fa-exchange-alt"></i>Yêu cầu bàn giao</a></li>`);
    $('.btn').append(`<button class="detail-btn" id="maintainRequest" onclick="" value="maintain">Yêu cầu bảo dưỡng, sửa chữa, thay mới</button>`)
    $('.sidebar-menu').append(`<li><a href="../needMaintanceItem.html" class="sidebar-link" id="maintenanceDue"><i class="fas fa-tools"></i> Thiết bị đến hạn</a></li>`);
    if (acc.accountantPIC == 1) {
        $('.sidebar-menu').append(`<li><a href="../registerDevice.html" class="sidebar-link" id="newItem"><i class="fas fa-plus-circle"></i> Đăng kí thiết bị mới</a></li>`);
        $('.sidebar-menu').append(`<li><a href="../../home/newItem.html" class="sidebar-link" id="unknowItem"><i class="fas fa-question-circle"></i> Thiết bị mới </br>  chưa bàn giao</a></li>`);

    }
} else if (acc.PICorStaff === 2) {
    $('.sidebar-menu').append(`<li><a href="../tranferRequestManager.html" class="sidebar-link" id="transferRequest"><i class="fas fa-exchange-alt"></i>Yêu cầu bàn giao</a></li>`);
    $('.sidebar-menu').append(`<li><a href="../answerRegisterDeviceManager.html" class="sidebar-link" id="newItem"><i class="fas fa-plus-circle"></i>Đăng kí thiết bị mới</a></li>`);
    $('.sidebar-menu').append(`<li><a href="../../home/newItem.html" class="sidebar-link" id="unknowItem"><i class="fas fa-question-circle"></i> Thiết bị mới </br>  chưa bàn giao</a></li>`);
    if(acc.admin == 1){
        $('.sidebar-menu').append(`<li><a href="../../home/accManaAdmin/accManaStaffAdmin.html" class="sidebar-link" id="unkn"><i
                            class="fas fa-user-shield"></i> Quản lí tài khoản</a></li>`)
                            $(".sidebar-menu").append(`  <li><a href="../managerItemAdmin.html" class="sidebar-link" id="manaItem"><i class="fas fa-boxes"></i> Quản lí thông tin trang thiết bị</a>
                                </li>`)
    }
}
window.onload = function () {

    const currentUrl = window.location.href
    const url = new URL(currentUrl);
    const urlParams = new URLSearchParams(url.search);
    itemId = (urlParams.get('id')).split('-')[0];
    
    getImageIdItem(itemId);
    getItemHistoryTranfer(itemId);
    let categoryName = getCategoryByIdItem(itemId);
    document.getElementById("title").textContent += ` ${categoryName} (id: ${itemId})`;
    // tạo qa code
        // Tạo QR code
        const qrUrl = `${itemId}-${removeVietnameseAccents(categoryName)}`;
        const qrText = "Logistic"; // Replace with your desired text
        
        function generateQRCodeWithText(qrUrl, text) {
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            const qrCode = new QRCode(canvas, {
                text: qrUrl,
                width: 128,
                height: 128,
            });
        
            qrCode.makeCode(qrUrl);
        
            qrCode._oDrawing._elImage.onload = function() {
                // Set canvas dimensions
                canvas.width = 128;
                canvas.height = 148; // Extra space for text
        
                // Draw the QR code onto the canvas
                ctx.drawImage(qrCode._oDrawing._elImage, 0, 0);
        
                // Set text properties
                ctx.font = '14px Arial';
                ctx.textAlign = 'center';
                ctx.fillStyle = 'black';
        
                // Draw the text below the QR code
                ctx.fillText(text, canvas.width / 2, 140);
        
                // Append the canvas to the container
                const qrContainer = document.getElementById('imgQr');
                qrContainer.innerHTML = ''; // Clear previous content
                qrContainer.appendChild(canvas);
            };
        }
        
        generateQRCodeWithText(qrUrl, qrText);
        document.getElementById('profile').innerHTML =
        `<a href="../profile.html" class="nav-link" id="profile">
        <i class="fas fa-user-circle"></i> 
        ${acc.name}</a>`;
}





// chuyển hướng sang danh sách các thiết bị
document.addEventListener('DOMContentLoaded', function () {
    document.getElementById("staticItem").onclick = function () {
        window.location.href = "../staticItem.html";
    }
});

// chuyển hướng sang danh sách yêu cầu
document.addEventListener('DOMContentLoaded', function () {
    document.getElementById("listRequest").onclick = function () {
        window.location.href = "../listRequest/maintance.html";
    }
});

// chuyển hướng sang lịch sử bảo trì
document.addEventListener('DOMContentLoaded', function () {
    document.getElementById("maintanceHistory").onclick = function () {
        window.location.href = `../staticItemDetail/maintanceHistory.html?id=${itemId}`;
    }
});

// chuyển hướng sang lịch sử bàn giao
document.addEventListener('DOMContentLoaded', function () {
    document.getElementById("tranferHistory").onclick = function () {
        window.location.href = `../staticItemDetail/tranferHistory.html?id=${itemId}`;
    }
});

// chuyển hướng sang yêu cầu bảo dưỡng, sửa chữa, thay mới
document.addEventListener('DOMContentLoaded', function () {
    document.getElementById("maintainRequest").onclick = function () {
        window.location.href = `../staticItemDetail/maintanceRequest.html?id=${itemId}`;
    }
});



function removeVietnameseAccents(str) {
    const diacriticsMap = {
        'à': 'a', 'á': 'a', 'ả': 'a', 'ã': 'a', 'ạ': 'a',
        'ă': 'a', 'ắ': 'a', 'ằ': 'a', 'ẳ': 'a', 'ẵ': 'a', 'ặ': 'a',
        'â': 'a', 'ấ': 'a', 'ầ': 'a', 'ẩ': 'a', 'ẫ': 'a', 'ậ': 'a',
        'đ': 'd',
        'è': 'e', 'é': 'e', 'ẻ': 'e', 'ẽ': 'e', 'ẹ': 'e',
        'ê': 'e', 'ế': 'e', 'ề': 'e', 'ể': 'e', 'ễ': 'e', 'ệ': 'e',
        'ì': 'i', 'í': 'i', 'ỉ': 'i', 'ĩ': 'i', 'ị': 'i',
        'ò': 'o', 'ó': 'o', 'ỏ': 'o', 'õ': 'o', 'ọ': 'o',
        'ô': 'o', 'ố': 'o', 'ồ': 'o', 'ổ': 'o', 'ỗ': 'o', 'ộ': 'o',
        'ơ': 'o', 'ớ': 'o', 'ờ': 'o', 'ở': 'o', 'ỡ': 'o', 'ợ': 'o',
        'ù': 'u', 'ú': 'u', 'ủ': 'u', 'ũ': 'u', 'ụ': 'u',
        'ư': 'u', 'ứ': 'u', 'ừ': 'u', 'ử': 'u', 'ữ': 'u', 'ự': 'u',
        'ỳ': 'y', 'ý': 'y', 'ỷ': 'y', 'ỹ': 'y', 'ỵ': 'y'
    };

    // Lặp qua từng ký tự trong chuỗi và thay thế các ký tự có dấu
    return str.replace(/[^\u0000-\u007E]/g, function(a) {
        return diacriticsMap[a] || a;
    });
}


document.getElementById('downloadQR').addEventListener('click', function() {
    // Assuming QRCode library creates an img element inside the container with id 'imgQr'
    const imgElement = document.getElementById('imgQr').querySelector('img');
    if (imgElement) {
        const imageUrl = imgElement.src; // Directly use the src attribute of the img element

        // Create an anchor tag and trigger download
        let downloadLink = document.createElement('a');
        downloadLink.href = imageUrl;
        downloadLink.download = `${getCategoryByIdItem(itemId)} (id: ${itemId})`; // Set the download filename
        document.body.appendChild(downloadLink);
        downloadLink.click();
        document.body.removeChild(downloadLink); // Clean up
    } else {
        console.error('QR code image not found.');
    }
});