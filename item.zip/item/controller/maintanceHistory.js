
// check account
let acc = JSON.parse(sessionStorage.getItem("acc"));
if (acc === null) {
    window.location.href = "../../register/login.html";
} else if (acc.PICorStaff === 1) {
    $('.sidebar-menu').append(`<li><a href="../tranferRequest.html" class="sidebar-link" id="transferRequest"><i class="fas fa-exchange-alt"></i>Yêu cầu bàn giao</a></li>`);
    $('.btn').append(`<button class="detail-btn" id="maintainRequest" onclick="" value="maintain">Yêu cầu bảo dưỡng, sửa chữa, thay mới</button>`)
    $('.sidebar-menu').append(`<li><a href="../needMaintanceItem.html" class="sidebar-link" id="maintenanceDue"><i class="fas fa-tools"></i> Thiết bị đến hạn</a></li>`);
    if (acc.accountantPIC == 1) {
        $('.sidebar-menu').append(`<li><a href="../registerDevice.html" class="sidebar-link" id="newItem"><i class="fas fa-plus-circle"></i> Đăng kí thiết bị mới</a></li>`);
        $('.sidebar-menu').append(`<li><a href="../../home/newItem.html" class="sidebar-link" id="unknowItem"><i class="fas fa-question-circle"></i> Thiết bị mới </br>  chưa bàn giao</a></li>`);

    }
} else if (acc.PICorStaff === 2) {
    $('.sidebar-menu').append(`<li><a href="../tranferRequestManager.html" class="sidebar-link" id="transferRequest"><i class="fas fa-exchange-alt"></i>Yêu cầu bàn giao</a></li>`);
    $('.sidebar-menu').append(`<li><a href="../answerRegisterDeviceManager.html" class="sidebar-link" id="newItem"><i class="fas fa-plus-circle"></i>Đăng kí thiết bị mới</a></li>`);
    $('.sidebar-menu').append(`<li><a href="../../home/newItem.html" class="sidebar-link" id="unknowItem"><i class="fas fa-question-circle"></i> Thiết bị mới </br>  chưa bàn giao</a></li>`);
    if (acc.admin == 1) {
        $('.sidebar-menu').append(`<li><a href="../../home/accManaAdmin/accManaStaffAdmin.html" class="sidebar-link" id="unkn"><i
                            class="fas fa-user-shield"></i> Quản lí tài khoản</a></li>`)
    }
}



var itemId;
let status

window.onload = function () {
    const currentUrl = window.location.href;
    const url = new URL(currentUrl);
    const urlParams = new URLSearchParams(url.search);
    itemId = (urlParams.get('id')).split('-')[0];
    let categoryName = getCategoryByIdItem(itemId); // Đảm bảo categoryName được lấy đúng và hỗ trợ UTF-8
    document.getElementById("title").textContent += ` ${categoryName} (id: ${itemId})`;
    status = getStatusByIdItem(itemId);

    getAllMaintanceHistory(itemId);
    getImageIdItem(itemId);

    if (status != "Hoạt động" && status != "Dự phòng") {
        $('.maintanceResponse').append(`
            <h4>Thiết bị ${status}</h4>
            <button class="detail-btn active" id="maintanceHistory" onclick="response()" value="maintanceResponse">Xác nhận đã xong</button>
            `);
    }

    // Tạo QR code
    const qrUrl = `${itemId}-${removeVietnameseAccents(categoryName)}`;
    const qrcode = document.getElementById("imgQr");
    new QRCode(qrcode, {
        text: qrUrl,
        width: 128,
        height: 128,
    });
    document.getElementById('profile').innerHTML =
        `<a href="../profile.html" class="nav-link" id="profile">
            <i class="fas fa-user-circle"></i> 
            ${acc.name}</a>`;
}


// chuyển hướng sang danh sách yêu cầu
document.addEventListener('DOMContentLoaded', function () {
    document.getElementById("listRequest").onclick = function () {
        window.location.href = "../listRequest/maintance.html";
    }
});

// chuyển hướng sang lịch sử bảo trì
document.addEventListener('DOMContentLoaded', function () {
    document.getElementById("maintanceHistory").onclick = function () {
        window.location.href = `../staticItemDetail/maintanceHistory.html?id=${itemId}`;
    }
});

// chuyển hướng sang lịch sử bàn giao
document.addEventListener('DOMContentLoaded', function () {
    document.getElementById("tranferHistory").onclick = function () {
        window.location.href = `../staticItemDetail/tranferHistory.html?id=${itemId}`;
    }
});

// chuyển hướng sang yêu cầu bảo dưỡng, sửa chữa, thay mới
document.addEventListener('DOMContentLoaded', function () {
    document.getElementById("maintainRequest").onclick = function () {
        window.location.href = `../staticItemDetail/maintanceRequest.html?id=${itemId}`;
    }
});





function removeVietnameseAccents(str) {
    const diacriticsMap = {
        'à': 'a', 'á': 'a', 'ả': 'a', 'ã': 'a', 'ạ': 'a',
        'ă': 'a', 'ắ': 'a', 'ằ': 'a', 'ẳ': 'a', 'ẵ': 'a', 'ặ': 'a',
        'â': 'a', 'ấ': 'a', 'ầ': 'a', 'ẩ': 'a', 'ẫ': 'a', 'ậ': 'a',
        'đ': 'd',
        'è': 'e', 'é': 'e', 'ẻ': 'e', 'ẽ': 'e', 'ẹ': 'e',
        'ê': 'e', 'ế': 'e', 'ề': 'e', 'ể': 'e', 'ễ': 'e', 'ệ': 'e',
        'ì': 'i', 'í': 'i', 'ỉ': 'i', 'ĩ': 'i', 'ị': 'i',
        'ò': 'o', 'ó': 'o', 'ỏ': 'o', 'õ': 'o', 'ọ': 'o',
        'ô': 'o', 'ố': 'o', 'ồ': 'o', 'ổ': 'o', 'ỗ': 'o', 'ộ': 'o',
        'ơ': 'o', 'ớ': 'o', 'ờ': 'o', 'ở': 'o', 'ỡ': 'o', 'ợ': 'o',
        'ù': 'u', 'ú': 'u', 'ủ': 'u', 'ũ': 'u', 'ụ': 'u',
        'ư': 'u', 'ứ': 'u', 'ừ': 'u', 'ử': 'u', 'ữ': 'u', 'ự': 'u',
        'ỳ': 'y', 'ý': 'y', 'ỷ': 'y', 'ỹ': 'y', 'ỵ': 'y'
    };

    // Lặp qua từng ký tự trong chuỗi và thay thế các ký tự có dấu
    return str.replace(/[^\u0000-\u007E]/g, function (a) {
        return diacriticsMap[a] || a;
    });
}


document.getElementById('downloadQR').addEventListener('click', function () {
    // Assuming QRCode library creates an img element inside the container with id 'imgQr'
    const imgElement = document.getElementById('imgQr').querySelector('img');
    if (imgElement) {
        const imageUrl = imgElement.src; // Directly use the src attribute of the img element

        // Create an anchor tag and trigger download
        let downloadLink = document.createElement('a');
        downloadLink.href = imageUrl;
        downloadLink.download = `${getCategoryByIdItem(itemId)} (id: ${itemId})`; // Set the download filename
        document.body.appendChild(downloadLink);
        downloadLink.click();
        document.body.removeChild(downloadLink); // Clean up
    } else {
        console.error('QR code image not found.');
    }
});

function response() {

    const userConfirmed = confirm("Hệ thống sẽ lưu lại bạn là người đã xác nhận. Bạn có chắc chắn muốn xác nhận?");

    if (userConfirmed) {
        if (status == "Đang bảo dưỡng") {
            postUpdateMaintanceDate(itemId)
        }
        postMaintanceHistory(itemId, acc.PICorStaff, acc.id);
        postUpdateItemStatus(itemId, "Hoạt động", 0);
        location.reload();
    } else {
    }
}