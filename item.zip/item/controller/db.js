function abc(){
    console.log("abc");
}
function def(){
    console.log("def");
    var usernameField = document.getElementById("username");
}
var a = "cdb";
exports.abc = abc;