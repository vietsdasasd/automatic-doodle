let acc = JSON.parse(sessionStorage.getItem("acc"));
if (acc === null) {
    window.location.href = "../register/login.html";
} else if (acc.PICorStaff != 2) {
    window.location.href = "../home/home.html";
}

// lấy ra id
const currentUrl = window.location.href;
const url = new URL(currentUrl);
const params = new URLSearchParams(url.search);
const id = params.get('id');
const infor = getRegisterDeviceRequestById(id);
let data = getAllRegisterDeviceByRegisterDeviceRequestId(id);
console.log("data", data);
console.log("infor", infor);

function accept() {
    const confirmation = confirm("Bạn có muốn đồng ý thêm thiết bị?");
    if (confirmation) {

        postUpdateStatusRegisterDeviceRequest("Chấp nhận", infor.idRegisterDeviceRequest);
        postNewItem(data);
        alert("Đồng ý thành công");
        location.reload();
    }
}

//từ chối chuyển giao
function ddeos() {
    const confirmation = confirm("Bạn có muốn từ chối thêm thiết bị");
    if (confirmation) {
        postUpdateStatusRegisterDeviceRequest("Từ chối", infor.idRegisterDeviceRequest);
        alert("Từ chối thành công");
        location.reload();
    }
}




window.onload = function () {
    if (infor.status == "Đang chờ") {
        $("#group-btn").append(`<button class="accept-btn active" id="accept" onclick="accept()" value="accept">Đồng ý chuyển giao</button> `)
        $("#group-btn").append(`<button class="accept-btn active" id="ddeos" onclick="ddeos()" value="accept">Từ chối chuyển giao</button>`)
    }
    document.getElementById('profile').innerHTML =
        `<a href="./profile.html" class="nav-link" id="profile">
                <i class="fas fa-user-circle"></i> 
                ${acc.name}</a>`;
}