
let count = 0;

if(sessionStorage.getItem('123') === null){
    window.location.href = "../register/login.html";

}


let key = getToken(sessionStorage.getItem('123'));
let acc = JSON.parse(decrypt(sessionStorage.getItem('acc'), key));if (acc === null) {
    window.location.href = "../register/login.html";
} else if (acc.PICorStaff != 2) {
    window.location.href = "../home/home.html";
}else{
    if(acc.admin == 1){
        $("sidebar-menu").append(` <li><a href="../home/accManaAdmin/accManaStaffAdmin.html" class="sidebar-link" id="unkn"><i class="fas fa-user-shield"></i> Quản lí tài khoản</a></li>`);
        $(".sidebar-menu").append(`  <li><a href="../home/managerItemAdmin.html" class="sidebar-link" id="manaItem"><i class="fas fa-boxes"></i> Quản lí thông tin trang thiết bị</a>
            `)
    }
}

// lấy ra id
const currentUrl = window.location.href;
const url = new URL(currentUrl);
const params = new URLSearchParams(url.search);
const id = params.get('id');
const infor = getRegisterDeviceRequestById(id);
let data = getAllRegisterDeviceByRegisterDeviceRequestId(id);
console.log("data", data);
console.log("infor", infor);

function accept() {
    const confirmation = confirm("Bạn có muốn đồng ý thêm thiết bị?");
    if (confirmation) {

        postUpdateStatusRegisterDeviceRequest("Chấp nhận", id);
        postNewItem(data);
        alert("Đồng ý thành công");
        location.reload();
    }
}

//từ chối chuyển giao
function ddeos() {
    const confirmation = confirm("Bạn có muốn từ chối thêm thiết bị");
    if (confirmation) {
        postUpdateStatusRegisterDeviceRequest("Từ chối", infor.idRegisterDeviceRequest);
        alert("Từ chối thành công");
        location.reload();
    }
}




window.onload = function () {
    if (infor.status == "Đang chờ") {
        $("#group-btn").append(`<button class="accept-btn active" id="accept" onclick="accept()" value="accept">Đồng ý</button> `)
        $("#group-btn").append(`<button class="accept-btn active" id="ddeos" onclick="ddeos()" value="accept">Từ chối</button>`)
    }
    document.getElementById('profile').innerHTML =
        `<a href="./profile.html" class="nav-link" id="profile">
                <i class="fas fa-user-circle"></i> 
                ${acc.name}</a>`;
}