function encrypt(text, passphrase) {
    return CryptoJS.AES.encrypt(text, passphrase).toString();
}

// Define the decryption function
function decrypt(ciphertext, passphrase) {
    const bytes = CryptoJS.AES.decrypt(ciphertext, passphrase);
    return bytes.toString(CryptoJS.enc.Utf8);
}