// backend.js

const mysql = require('mysql2');
const express = require('express');
const cors = require('cors');
const fs = require('fs');
const axios = require('axios');
const { authenSendMail, sendEmails, sendMailResultTranferRequestForPIC, sendRegisterNewDeviceForManager, sendEmailForPICAboutNewItem } = require('./SendMail.js');

// const aAPI = require("./DAO/SendMail.js");



//const multer = require('multer')
const bodyParser = require('body-parser');
const path = require('path');
const { data } = require('jquery');
const app = express();
app.use(bodyParser.json({ limit: '50mb' }));
//app.use(express.json());
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb' }));
//app.use(multer())
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'Pbei7955',
  database: 'Factory_equipment_management',
  //dateStrings: true
  timezone: '+00:00'
});

//region region chia code không đúng nữa
//region

connection.connect((err) => {
  if (err) throw err;
  console.log('Connected to the MySQL server.');
});


///////////////////////////////





// #region login


//hàm check staff account
app.post("/checkStaffAccount", (req, res) => {
  let query = "SELECT * FROM Staff WHERE username = ? AND password = ? LIMIT 1";
  connection.query(query, [req.body.username, req.body.password], (err, result) => {
    if (err) throw err;
    res.json(result);
  })
})

//hàm check PIC account
app.post("/checkPICAccount", (req, res) => {
  let query = "SELECT * FROM PIC WHERE username = ? AND password = ? LIMIT 1";
  connection.query(query, [req.body.username, req.body.password], (err, result) => {
    if (err) throw err;
    res.json(result);
  })
})


// hàm check Manager account
app.post("/checkManagerAccount", (req, res) => {
  let query = "SELECT * FROM Manager WHERE username = ? AND password = ? LIMIT 1";
  connection.query(query, [req.body.username, req.body.password], (err, result) => {
    if (err) throw err;
    res.json(result);
  })
})
// #endregion



app.post("/getStaffPassword", (req, res) => {
  let query = "SELECT password FROM Staff WHERE idStaff = ? LIMIT 1";
  connection.query(query, [req.query.id], (err, result) => {
    if (err) throw err;
    res.json(result[0].password);
  })
});

app.post("/getPICPassword", (req, res) => {
  let query = "SELECT password FROM PIC WHERE idPIC = ? LIMIT 1";
  connection.query(query, [req.query.id], (err, result) => {
    if (err) throw err;
    res.json(result[0].password);
  })
})

app.post("/getManagerPassword", (req, res) => {
  let query = "SELECT password FROM Manager WHERE idManager = ? LIMIT 1";
  connection.query(query, [req.query.id], (err, result) => {
    if (err) throw err;
    res.json(result[0].password);
  })
})

// #region home static all item

//hàm lấy tất cả các item + filter + order
app.get('/getAllItem', (req, res) => {
  const page = parseInt(req.query.page) || 1;
  const pageSize = parseInt(req.query.pageSize) || 10;
  const offset = (page - 1) * pageSize;

  let querryFilter = "Where (status != 'Bỏ' AND i.idArea  is not null) ";
  switch (req.query.filter) {
    case "active":
      querryFilter += "AND status = 'Hoạt động'";
      break;
    case "repair":
      querryFilter += "AND status = 'Đang sửa'";
      break;
    case "maintain":
      querryFilter += "AND status = 'Đang bảo dưỡng'";
      break;
    case "duPhong":
      querryFilter += "AND status = 'Dự phòng'";
      break;
    case "filter":
      //let advanFilter = JSON.parse(decodeURIComponent(req.query.advanFilter));
      let advanFilter = req.query.advanFilter.split(",");
      let startDateFilter = "1990-01-01";
      let endDateFilter = "2100-01-01";
      if (advanFilter[0] !== "") {
        startDateFilter = advanFilter[0];
      }
      if (advanFilter[1] !== "") {
        endDateFilter = advanFilter[1];
      }
      querryFilter += ` AND activedDate >= '${startDateFilter}' AND activedDate  <= '${endDateFilter}' `;
      if (advanFilter[2] !== "all") {
        querryFilter += ` AND i.idCategory = ${advanFilter[2]} `;
      }
      if (advanFilter[3] !== "all") {
        querryFilter += ` AND status = '${advanFilter[3]}' `;
      }
      if (advanFilter[4] !== "all") {
        querryFilter += ` AND w.idWarehouse = ${advanFilter[4]} `;
      }
      if (advanFilter[5] !== "all") {
        querryFilter += ` AND i.idArea = ${advanFilter[5]} `;
      }
      break;
  }

  let query = `
   SELECT 
    i.idItem,
    c.name AS category,
    c.idCategory AS idCategory,
    a.name AS area,
    a.idArea,
    w.name AS warehouse,
    w.idWarehouse AS idWarehouse,
    w.idPIC AS idPICWarehouse,
    i.maintanceDate AS maintanceDate,
    i.renewDate AS renewDate,
    i.image AS image,
    i.duration,
    i.maintaneceCycle,
    i.active, 
    i.status AS status,
    i.receivedDate,
    i.activedDate,
    i.PO,
    DATEDIFF(i.maintanceDate, NOW()) AS maintanceDays,
    DATEDIFF(i.renewDate, NOW()) AS renewDays
FROM 
    Item i
    LEFT JOIN Category c ON i.idCategory = c.idCategory
    LEFT JOIN Area a ON i.idArea = a.idArea
    LEFT JOIN Warehouse w ON a.idWarehouse = w.idWarehouse
${querryFilter}
ORDER BY 
    CASE WHEN i.status = 'Dự phòng' THEN 1 ELSE 0 END,
    i.maintanceDate ASC ,  
    i.renewDate ASC
LIMIT ?, ?;
`; // Sử dụng LIMIT để giới hạn số lượng kết quả trả về

  connection.query(query, [offset, pageSize], (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    res.json(results);
  });
});

// lấy ra số lượng item
app.get('/getNumItem', (req, res) => {

  let queryFilter = "WHERE (status != 'Bỏ' AND i.idArea  is not null) "; // Chỉnh sửa từ 'querryFilter' thành 'queryFilter'
  switch (req.query.filter) {
    case "active":
      queryFilter += "AND i.status = 'Hoạt động'";
      break;
    case "repair":
      queryFilter += "AND i.status = 'Đang sửa'";
      break;
    case "maintain":
      queryFilter += "AND i.status = 'Đang bảo dưỡng'";
      break;
    case "duPhong":
      queryFilter += "AND i.status = 'Dự phòng'";
      break;
    case "filter":
      let advanFilter = req.query.advanFilter.split(",");
      let startDateFilter = "1990-01-01";
      let endDateFilter = "2100-01-01";
      if (advanFilter[0] !== "") {
        startDateFilter = advanFilter[0];
      }
      if (advanFilter[1] !== "") {
        endDateFilter = advanFilter[1];
      }
      queryFilter += ` AND i.activedDate >= '${startDateFilter}' AND i.activedDate <= '${endDateFilter}' `;
      if (advanFilter[2] !== "all") {
        queryFilter += ` AND i.idCategory = ${advanFilter[2]} `;
      }
      if (advanFilter[3] !== "all") {
        queryFilter += ` AND i.status = '${advanFilter[3]}' `;
      }
      if (advanFilter[4] !== "all") {
        queryFilter += ` AND w.idWarehouse = ${advanFilter[4]} `;
      }
      if (advanFilter[5] !== "all") {
        queryFilter += ` AND i.idArea = ${advanFilter[5]} `;
      }
      break;
  }

  let query =
    `SELECT 
      COUNT(*) AS count
    FROM 
      Item i
      LEFT JOIN Category c ON i.idCategory = c.idCategory
      LEFT JOIN Area a ON i.idArea = a.idArea
      LEFT JOIN Warehouse w ON a.idWarehouse = w.idWarehouse
      
    ${queryFilter};`;

  connection.query(query, (err, result) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }
    res.json(result[0]);

  });
});


// hàm lấy ra tất cả các loại item
app.get('/getAllCategory', (req, res) => {

  let query =
    `SELECT
          *
     FROM Category
      `;

  connection.query(query, (err, result) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }
    res.json(result);

  });
});

// hàm lấy ra tất cả các trạng thái 
app.get('/getAllStatus', (req, res) => {

  let query =
    `SELECT DISTINCT 
        status
     FROM Item
     Where status <> 'Bỏ';
      `;

  connection.query(query, (err, result) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }
    res.json(result);

  });
});

//hàm lấy ra tất cả các kho
app.get('/getAllWarehouse', (req, res) => {

  let query =
    `SELECT 
        *
     FROM Warehouse;
      `;

  connection.query(query, (err, result) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }
    res.json(result);

  });
});

//hàm lấy ra tất cả các khu theo kho
app.get('/getAllRegionByWarehouse', (req, res) => {

  let query =
    `SELECT 
        *
     FROM Area
     WHERE idWarehouse = ?;
      `;

  connection.query(query, [req.query.idWarehouse], (err, result) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }
    res.json(result);

  });
});
// #endgion

// #region chi tiết thiết bị
//lấy ra lịch sử bảo dưỡng
app.get('/getAllMaintanceHistory', (req, res) => {

  let query =
    ` SELECT  
   mh.dateStart AS dateStart, 
   mh.dateEnd AS dateEnd, 
   mh.budget AS budget, 
   mh.type AS maintenance_type, 
   mr.reason AS reason, 
   mh.idItem,
   CASE
     WHEN mh.roleAccept = 0 THEN s.name 
     WHEN mh.roleAccept = 2 THEN m.name 
     WHEN mh.roleAccept = 1 THEN p.name
     ELSE NULL
   END AS roleAcceptName
FROM maintancehistory mh
INNER JOIN maintancerequest mr ON mh.idMaintanceRequest = mr.idMaintanceRequest
LEFT JOIN staff s ON mh.idStaff = s.idStaff AND mh.roleAccept = 0
LEFT JOIN manager m ON mh.idStaff = m.idManager AND mh.roleAccept = 2
LEFT JOIN pic p ON mh.idStaff = p.idPIC AND mh.roleAccept = 1
    WHERE mh.idItem = ? 
    ORDER BY
       mh.dateStart DESC; 

      `;

  connection.query(query, [req.query.idItem], (err, result) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }
    res.json(result);

  });
});


// lấy ra lịch sử bàn giao
app.get('/getAllTranferHistory', (req, res) => {

  let query =
    `
  SELECT 
    th.date, 
    th.image, 
    sender.name AS sender_name, 
    receiver.name AS receiver_name, 
    warehouse.name AS oldWarehouse_name, 
    area.name AS oldArea_name, 
    pic.name AS oldPIC_name 
FROM  
    tranferhistory th 
LEFT JOIN  
    staff sender ON th.sender = sender.idStaff 
LEFT JOIN  
    staff receiver ON th.receiver = receiver.idStaff 
LEFT JOIN  
    area ON th.idArea = area.idArea 
LEFT JOIN  
    warehouse ON area.idWarehouse = warehouse.idWarehouse 
LEFT JOIN  
    pic ON th.oldPIC = pic.idPIC 
Where th.idItem = ? 
ORDER BY th.date DESC;
      `;

  connection.query(query, [req.query.idItem], (err, result) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }
    res.json(result);
  });
});




// lấy ra category theo itemid
app.get('/getCategoryByItemId', (req, res) => {

  let query =
    `
  SELECT
     c.name AS categoryName
  FROM
     item i
  LEFT JOIN category c ON i.idCategory = c.idCategory
  WHERE
     i.idItem = ?;
      `;

  connection.query(query, [req.query.idItem], (err, result) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }
    res.json(result);
  });
});


// lấy ra idTranferRequest max
app.get('/getMaxIdTranferRequest', (req, res) => {

  let query =
    `
SELECT MAX(idTranferRequest) AS max_id FROM tranferrequest;

      `;

  connection.query(query, (err, result) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }
    res.json(result);
  });
});

//Gửi tranfer request lên db
app.post('/postTranferRequest', (req, res) => {

  let query =
    `
insert into TranferRequest(PIC_request, status, reason, date, fromArea, toArea)
values (?, ?, ?, CURRENT_DATE(), ?, ?)
      `;

  connection.query(query, [req.query.PIC_request, req.query.status, req.query.reason, req.query.fromArea, req.query.toArea], (err, result) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }
    let insertedId = result.insertId;
    res.json({ id: insertedId });
  });
});


// gửi tranfer Request với role của Manager
app.post('/postTranferRequestManager', (req, res) => {

  let query =
    `
insert into TranferRequest( status, reason, date, fromArea, toArea)
values ( ?, ?, CURRENT_DATE(), ?, ?)
      `;

  connection.query(query, [req.query.status, req.query.reason, req.query.fromArea, req.query.toArea], (err, result) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }
    let insertedId = result.insertId;
    res.json({ id: insertedId });
  });
});

// gửi chi tiết tranfer request
app.post('/postTranferRequestDetail', (req, res) => {

  let checkeditemList = req.body;
  let query =
    `
insert into TranferRequestDetail(idTranferRequest, idItem, PIC)
values (${req.query.tranferRequestId}, ${checkeditemList[0].id}, ${checkeditemList[0].PIC})
      `;

  for (let i = 1; i < checkeditemList.length; i++) {
    query += `, (${req.query.tranferRequestId}, ${checkeditemList[i].id}, ${checkeditemList[i].PIC})`;
  }
  connection.query(query, (err, result) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }
    res.json(result);
  });
});



// chấp nhận chuyển vị trí
app.post('/postAcceptTranferRequest', (req, res) => {

  let query =
    `
  UPDATE item i
  JOIN tranferrequestdetail trd ON i.idItem = trd.idItem
  JOIN tranferrequest tr ON trd.idTranferRequest = tr.idTranferRequest
  SET
    i.idArea = tr.toArea,
    tr.status = 'Chấp nhận',
    tr.date_answer = CURRENT_DATE()
  WHERE
    tr.idTranferRequest = ?;
      `;


  connection.query(query, [req.query.tranferRequestId], (err, result) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }
    res.json(result);
  });
});

// từ chối chuyển giao
app.post('/postRejectTranferRequest', (req, res) => {

  let query =
    `
    UPDATE 
      item i
    JOIN tranferrequestdetail trd ON i.idItem = trd.idItem
    JOIN tranferrequest tr ON trd.idTranferRequest = tr.idTranferRequest
    SET 
      i.idArea = tr.toArea,
      tr.status = 'Từ chối',
      tr.date_answer = CURRENT_DATE()
    WHERE
      tr.idTranferRequest = ?;
      `;


  connection.query(query, [req.query.tranferRequestId], (err, result) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }
    res.json(result);
  });
});

// cập nhật lịch sử bàn giao
app.post('/postHistoryTranfer', (req, res) => {

  let query =
    `
    INSERT INTO 
      tranferHistory(date, idTranferRequest)
    VALUES (CURRENT_DATE(), ?)
      `;


  connection.query(query, [req.query.tranferRequestId], (err, result) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }
    res.json(result);
  });
});



//gửi maintanceRequest lên db + cập nhật item
app.post('/postMaintanceRequest', (req, res) => {
  const receivedData = req.body;
  connection.beginTransaction(err => {
    if (err) {
      console.error('Lỗi bắt đầu giao dịch:', err);
      res.status(500).json({ error: 'Lỗi bắt đầu giao dịch' });
      return;
    }

    let insertQuery = `INSERT INTO maintanceRequest(idItem, idPIC, status, reason, budgetEstimate, date, type, image, extend)
                        VALUES(?, ?, 'Đang chờ', ?, ?, CURRENT_DATE(), ?, ?, ?);`;

    connection.query(insertQuery, [req.body.idItem, req.body.idStaff, req.body.reason, req.body.budgetEstimate, req.body.typeRequest, req.body.imageDecode, req.body.extend], (err, result) => {
      if (err) {
        return connection.rollback(() => {
          console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
          res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
        });
      }

      let updateQuery = `UPDATE item SET maintanceRequested = 1 WHERE idItem = ?;`;
      connection.query(updateQuery, [req.body.idItem], (err, result) => {
        if (err) {
          return connection.rollback(() => {
            console.error('Lỗi cập nhật item:', err);
            res.status(500).json({ error: 'Lỗi cập nhật item' });
          });
        }

        connection.commit(err => {
          if (err) {
            return connection.rollback(() => {
              console.error('Lỗi commit giao dịch:', err);
              res.status(500).json({ error: 'Lỗi commit giao dịch' });
            });
          }
          res.json(result);
        });
      });
    });
  });
});
// #endgion

//#region xem list yêu cầu
// hàm lấy ra danh sách các yêu cầu tranfer theo PIC
app.get('/getAllTranferRequest', (req, res) => {
  const page = parseInt(req.query.page) || 1;
  const pageSize = parseInt(req.query.pageSize) || 10;
  const offset = (page - 1) * pageSize;
  const idPIC = req.query.idPIC;

  if (!idPIC) {
    return res.status(400).json({ error: 'idPIC is required' });
  }

  let queryFilter = `WHERE (from_warehouse.idPIC = ? OR to_warehouse.idPIC = ?) AND PIC_request is not null`;
  switch (req.query.filter) {
    case "accept":
      queryFilter += " AND tr.status = 'Chấp nhận'";
      break;
    case "pending":
      queryFilter += " AND tr.status = 'Đang chờ'";
      break;
    case "reject":
      queryFilter += " AND tr.status = 'Từ chối'";
      break;
  }

  const query = `
   SELECT
       tr.idTranferRequest AS idTranferRequest,
       p_request.name AS PIC_request_name,
       tr.status,
       tr.reason,
       tr.date AS date,
       tr.date_answer AS date_answer,
       from_area.name AS from_area_name,
       from_pic.idPIC AS fromArea_idPIC,
       from_pic.name AS fromArea_PIC_name,
       from_warehouse.idPIC AS fromWarehouse_idPIC,
       from_warehouse.name AS fromWarehouse_name,
       to_area.name AS to_area_name,
       to_pic.idPIC AS toArea_idPIC,
       to_pic.name AS toArea_PIC_name,
       to_warehouse.idPIC AS toWarehouse_idPIC,
       to_warehouse.name AS toWarehouse_name
   FROM
       tranferrequest tr
   LEFT JOIN 
       pic p_request ON tr.PIC_request = p_request.idPIC
   LEFT JOIN
       area from_area ON tr.fromArea = from_area.idArea
   LEFT JOIN
       warehouse from_warehouse ON from_area.idWarehouse = from_warehouse.idWarehouse
   LEFT JOIN
       pic from_pic ON from_warehouse.idPIC = from_pic.idPIC 
   LEFT JOIN
       area to_area ON tr.toArea = to_area.idArea 
   LEFT JOIN
       warehouse to_warehouse ON to_area.idWarehouse = to_warehouse.idWarehouse 
LEFT JOIN
    pic to_pic ON to_warehouse.idPIC = to_pic.idPIC

    ${queryFilter}
    ORDER BY tr.date DESC
    LIMIT ? OFFSET ?
  `;

  connection.query(query, [idPIC, idPIC, pageSize, offset], (err, result) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }
    res.json(result);
  });
});



// hàm lấy ra số lượng yêu cầu tranfer theo PIC
app.get('/getNumAllTranferRequest', (req, res) => {


  let queryFilter = `WHERE (from_warehouse.idPIC = ? OR to_warehouse.idPIC = ?) AND PIC_request is not null`;
  switch (req.query.filter) {
    case "accept":
      queryFilter += " AND tr.status = 'Chấp nhận'";
      break;
    case "pending":
      queryFilter += " AND tr.status = 'Đang chờ'";
      break;
    case "reject":
      queryFilter += " AND tr.status = 'Từ chối'";
      break;
  }

  const query = `
    SELECT
        COUNT(*) as count
    FROM
        tranferrequest tr
    LEFT JOIN pic p_request ON tr.PIC_request = p_request.idPIC
    LEFT JOIN area from_area ON tr.fromArea = from_area.idArea
    LEFT JOIN warehouse from_warehouse ON from_area.idWarehouse = from_warehouse.idWarehouse
    LEFT JOIN pic from_pic ON from_warehouse.idPIC = from_pic.idPIC
    LEFT JOIN area to_area ON tr.toArea = to_area.idArea
    LEFT JOIN warehouse to_warehouse ON to_area.idWarehouse = to_warehouse.idWarehouse
    LEFT JOIN pic to_pic ON to_warehouse.idPIC = to_pic.idPIC
    ${queryFilter}
  
  `;

  connection.query(query, [req.query.idPIC, req.query.idPIC], (err, result) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }
    res.json(result[0]);
  });
});

// lấy ra tất cả các yêu cầu tranfer(cho manager)
app.get('/getAllTranferRequestManager', (req, res) => {
  const page = parseInt(req.query.page) || 1;
  const pageSize = parseInt(req.query.pageSize) || 10;
  const offset = (page - 1) * pageSize;
  const idPIC = req.query.idPIC;



  let queryFilter = `WHERE PIC_request is not null`;
  switch (req.query.filter) {
    case "accept":
      queryFilter += " AND tr.status = 'Chấp nhận'";
      break;
    case "pending":
      queryFilter += " AND tr.status = 'Đang chờ'";
      break;
    case "reject":
      queryFilter += " AND tr.status = 'Từ chối'";
      break;
  }

  const query = `
  SELECT
    tr.idTranferRequest AS idTranferRequest,
    p_request.name AS PIC_request_name,
    tr.status,
    tr.reason,
    tr.date AS date,
    tr.date_answer AS date_answer,
    from_area.name AS from_area_name,
    from_pic.idPIC AS fromArea_idPIC,
    from_pic.name AS fromArea_PIC_name,
    from_warehouse.idPIC AS fromWarehouse_idPIC,
    from_warehouse.name AS fromWarehouse_name,
    to_area.name AS to_area_name,
    to_pic.idPIC AS toArea_idPIC,
    to_pic.name AS toArea_PIC_name,
    to_warehouse.idPIC AS toWarehouse_idPIC,
    to_warehouse.name AS toWarehouse_name
  FROM
    tranferrequest tr
  LEFT JOIN 
    pic p_request ON tr.PIC_request = p_request.idPIC
  LEFT JOIN
    area from_area ON tr.fromArea = from_area.idArea
  LEFT JOIN
    warehouse from_warehouse ON from_area.idWarehouse = from_warehouse.idWarehouse
  LEFT JOIN
    pic from_pic ON from_warehouse.idPIC = from_pic.idPIC 
  LEFT JOIN
    area to_area ON tr.toArea = to_area.idArea 
  LEFT JOIN
    warehouse to_warehouse ON to_area.idWarehouse = to_warehouse.idWarehouse 
  LEFT JOIN
    pic to_pic ON to_warehouse.idPIC = to_pic.idPIC

    ${queryFilter}
  ORDER BY tr.date DESC
  LIMIT ? OFFSET ?
  `;

  connection.query(query, [pageSize, offset], (err, result) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }
    res.json(result);
  });
});

// hàm lấy ra số lượng yêu cầu tranfer (cho manager)
app.get('/getNumAllTranferRequestManager', (req, res) => {


  let queryFilter = `WHERE PIC_request is not null`;
  switch (req.query.filter) {
    case "accept":
      queryFilter += " AND tr.status = 'Chấp nhận'";
      break;
    case "pending":
      queryFilter += " AND tr.status = 'Đang chờ'";
      break;
    case "reject":
      queryFilter += " AND tr.status = 'Từ chối'";
      break;
  }

  const query = `
    SELECT
        COUNT(*) as count
    FROM
         tranferrequest tr
    LEFT JOIN pic p_request ON tr.PIC_request = p_request.idPIC
    LEFT JOIN area from_area ON tr.fromArea = from_area.idArea
    LEFT JOIN warehouse from_warehouse ON from_area.idWarehouse = from_warehouse.idWarehouse
    LEFT JOIN pic from_pic ON from_warehouse.idPIC = from_pic.idPIC
    LEFT JOIN area to_area ON tr.toArea = to_area.idArea
    LEFT JOIN warehouse to_warehouse ON to_area.idWarehouse = to_warehouse.idWarehouse
    LEFT JOIN pic to_pic ON to_warehouse.idPIC = to_pic.idPIC
    ${queryFilter}
  
  `;

  connection.query(query, (err, result) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }
    res.json(result[0]);
  });
});

// lấy ra tất cả yêu cầu bảo trì
app.get('/getAllMaintanceRequest', (req, res) => {
  const page = parseInt(req.query.page) || 1;
  const pageSize = parseInt(req.query.pageSize) || 10;
  const offset = (page - 1) * pageSize;

  let queryFilter = "";
  switch (req.query.filter) {
    case "accept":
      queryFilter = "WHERE mr.status = 'Chấp nhận'";
      break;
    case "pending":
      queryFilter = "WHERE mr.status = 'Đang chờ'";
      break;
    case "reject":
      queryFilter = "WHERE mr.status = 'Từ chối'";
      break;
    case "maintance":
      queryFilter = "WHERE mr.type = 'Bảo dưỡng'";
      break;
    case "repair":
      queryFilter = "WHERE mr.type = 'Sửa chữa'";
      break;
    case "vutws":
      queryFilter = "WHERE mr.type = 'Thay mới'";
      break;
    case "extend":
      queryFilter = "WHERE mr.type = 'Gia hạn'";
      break;
    case "filter":
      let advanFilter = req.query.advanFilter.split(",");
      let startDateFilter = "1990-01-01";
      let endDateFilter = "2100-01-01";
      if (advanFilter[0] !== "") {
        startDateFilter = advanFilter[0];
      }
      if (advanFilter[1] !== "") {
        endDateFilter = advanFilter[1];
      }
      queryFilter = ` WHERE mr.date >= '${startDateFilter}' AND mr.date <= '${endDateFilter}' `;
      if (advanFilter[2] !== "all") {
        queryFilter += ` AND c.idCategory = ${advanFilter[2]} `;
      }
      if (advanFilter[3] !== "all") {
        queryFilter += ` AND mr.status = '${advanFilter[3]}' `;
      }
      if (advanFilter[4] !== "all") {
        queryFilter += ` AND w.idWarehouse = ${advanFilter[4]} `;
      }
      if (advanFilter[5] !== "all") {
        queryFilter += ` AND a.idArea = ${advanFilter[5]} `;
      }
      if (advanFilter[6] !== "all") {
        queryFilter += ` AND mr.type = '${advanFilter[6]}'`;
      }
      break;
  }

  let query = `
   SELECT
      mr.idMaintanceRequest,
      mr.date AS date,
      c.name AS categoryName,
      i.idCategory,
      i.idItem AS idItem,
      p.name AS staffName,
      mr.status,
      mr.reason AS reason,
      mr.budgetEstimate,
      mr.type AS type,
      mr.image,
      a.name AS areaName,
      w.name AS warehouseName,
      a.idArea,
      w.idWarehouse,
      mr.extend AS extend,
      p.email AS email
   FROM
      maintancerequest mr
   LEFT JOIN
      item i ON mr.idItem = i.idItem
   LEFT JOIN
      category c ON i.idCategory = c.idCategory
   LEFT JOIN
      PIC p ON mr.idPIC = p.idPIC
   LEFT JOIN
      area a ON i.idArea = a.idArea
   LEFT JOIN
      warehouse w ON a.idWarehouse = w.idWarehouse
   ${queryFilter} 
   ORDER BY
      mr.date DESC
   LIMIT ?, ?;

  `;

  connection.query(query, [offset, pageSize], (err, result) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }
    res.json(result);
  });
});



// lấy ra maintance request theo id
app.get('/getMaintanceRequestById', (req, res) => {


  let query = `
  SELECT
      mr.idMaintanceRequest,
      mr.date AS date,
      c.name AS categoryName,
      i.idCategory,
      i.idItem AS idItem,
      p.name AS staffName,
      mr.status AS status,
      mr.reason AS reason,
      mr.budgetEstimate,
      mr.type AS type,
      mr.image AS image,
      a.name AS areaName,
      w.name AS warehouseName,
      a.idArea,
      w.idWarehouse,
      mr.extend AS extend,
      p.email AS email,
      mr.reasonManager AS reasonManager
  FROM
      maintancerequest mr
  LEFT JOIN
      item i ON mr.idItem = i.idItem
  LEFT JOIN
      category c ON i.idCategory = c.idCategory
  LEFT JOIN
      PIC p ON mr.idPIC = p.idPIC
  LEFT JOIN
      area a ON i.idArea = a.idArea
  LEFT JOIN
      warehouse w ON a.idWarehouse = w.idWarehouse
  Where
      idMaintanceRequest = ?

  `;

  connection.query(query, [req.query.idMaintanceRequest], (err, result) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }
    res.json(result[0]);
  });
});





// lấy ra số lượng maintance request
app.get('/getNumAllMaintanceRequest', (req, res) => {
  let queryFilter = "";
  switch (req.query.filter) {
    case "accept":
      queryFilter = "WHERE mr.status = 'Chấp nhận'";
      break;
    case "pending":
      queryFilter = "WHERE mr.status = 'Đang chờ'";
      break;
    case "reject":
      queryFilter = "WHERE mr.status = 'Từ chối'";
      break;
    case "maintance":
      queryFilter = "WHERE mr.type = 'Bảo dưỡng'";
      break;
    case "repair":
      queryFilter = "WHERE mr.type = 'Sửa chữa'";
      break;
    case "vutws":
      queryFilter = "WHERE mr.type = 'Thay mới'";
      break;
    case "filter":
      let advanFilter = req.query.advanFilter.split(",");
      let startDateFilter = "1990-01-01";
      let endDateFilter = "2100-01-01";
      if (advanFilter[0] !== "") {
        startDateFilter = advanFilter[0];
      }
      if (advanFilter[1] !== "") {
        endDateFilter = advanFilter[1];
      }
      queryFilter = ` WHERE mr.date >= '${startDateFilter}' AND mr.date <= '${endDateFilter}' `;
      if (advanFilter[2] !== "all") {
        queryFilter += ` AND c.idCategory = ${advanFilter[2]} `;
      }
      if (advanFilter[3] !== "all") {
        queryFilter += ` AND mr.status = '${advanFilter[3]}' `;
      }
      if (advanFilter[4] !== "all") {
        queryFilter += ` AND w.idWarehouse = ${advanFilter[4]} `;
      }
      if (advanFilter[5] !== "all") {
        queryFilter += ` AND a.idArea = ${advanFilter[5]} `;
      }
      if (advanFilter[6] !== "all") {
        queryFilter += ` AND mr.type = '${advanFilter[6]}'`;
      }
      break;
  }

  let query = `
  SELECT
      COUNT(*) AS total
  FROM
      maintancerequest mr
  LEFT JOIN
      item i ON mr.idItem = i.idItem
  LEFT JOIN
      category c ON i.idCategory = c.idCategory
  LEFT JOIN
      PIC p ON mr.idPIC = p.idPIC
  LEFT JOIN
      area a ON i.idArea = a.idArea
  LEFT JOIN
      warehouse w ON a.idWarehouse = w.idWarehouse
  ${queryFilter}
    `;

  connection.query(query, (err, result) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }
    res.json(result[0]);
  });
});


//#endgion

//#region real post request(nếu có thấy cái nào post request lên khac region này thì cái đấy không dùng nữa rồi)
//lấy ra tất cả warehouse, có 2 cái /getAllWarehouse, sửa ở đây thì mới thay đổi
app.get('/getAllWarehouse', (req, res) => {


  let query = `
SELECT
    *
FROM
    Warehouse
  `;

  connection.query(query, (err, result) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }
    res.json(result);
  });
});

app.get('/getAllAreaByIdWarehouse', (req, res) => {


  let query = `
SELECT
    *
FROM
    Area
WHERE idWarehouse = ?
  `;

  connection.query(query, [req.query.idWarehouse], (err, result) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }
    res.json(result);
  });
});




//lấy ra item theo idArea
app.get('/getItemByAreaId', (req, res) => {

  let query = `
    SELECT 
      i.idItem,
      c.name AS category,
      c.idCategory AS idCategory,
      a.name AS area,
      a.idArea,
      w.name AS warehouse,
      w.idWarehouse AS idWarehouse,
      i.image AS image,
      i.duration,
      i.maintaneceCycle,
      i.active, 
      i.status AS status,
      i.receivedDate,
      i.activedDate
    FROM 
      Item i
      LEFT JOIN Category c ON i.idCategory = c.idCategory
      LEFT JOIN Area a ON i.idArea = a.idArea
      LEFT JOIN Warehouse w ON a.idWarehouse = w.idWarehouse
      
    WHERE i.idArea = ? AND i.status <> 'Bỏ'
    ORDER BY category

   `;

  connection.query(query, [req.query.idArea], (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    res.json(results);
  });
});
//#endgion

// như tên
app.get('/getIdPICByIdWarehouse', (req, res) => {

  let query = `
    select idPIC from Warehouse
    WHERE idWarehouse = ?

   `;

  connection.query(query, [req.query.idWarehouse], (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    res.json(results);
  });
});

//lấy các item được yêu cầu chuyển giao theo idTranferRequest
app.get('/getItemByIdTranferRequest', (req, res) => {

  let query = `
    SELECT 
      i.idItem AS idItem,
      i.image AS image,
      c.name AS category_name
    FROM 
      tranferrequestdetail trd
    JOIN 
      item i ON trd.idItem = i.idItem
    JOIN 
      category c ON i.idCategory = c.idCategory
    WHERE 
      trd.idTranferRequest = ?;


   `;

  connection.query(query, [req.query.idTranferRequest], (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    res.json(results);
  });
});


// 
app.get('/getInforByTranferId', (req, res) => {

  let query = `
    SELECT 
       tr.PIC_request AS PIC_request,
       tr.idTranferRequest,
       tr.status AS status,
       to_pic.idPIC AS toArea_idPIC,
       fromWarehouse.name AS fromWarehouseName,
       fromArea.name AS fromAreaName,
       toWarehouse.name AS toWarehouseName,
       toArea.name AS toAreaName
    FROM 
       tranferrequest tr
    LEFT JOIN 
        area fromArea ON tr.fromArea = fromArea.idArea
    LEFT JOIN 
        warehouse fromWarehouse ON fromArea.idWarehouse = fromWarehouse.idWarehouse
    LEFT JOIN 
        area toArea ON tr.toArea = toArea.idArea
    LEFT JOIN 
        warehouse toWarehouse ON toArea.idWarehouse = toWarehouse.idWarehouse
    LEFT JOIN 
        pic to_pic ON toWarehouse.idPIC = to_pic.idPIC
    WHERE 
        tr.idTranferRequest = ?;


   `;

  connection.query(query, [req.query.idTranferRequest], (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    res.json(results[0]);
  });
});


//lấy ra lịch sử tranfer của item
app.get('/getItemHistoryTranfer', (req, res) => {
  // khi có được sender và receiver thì dùng câu truy vấn này
  //   SELECT 
  //     i.idItem,
  //     trd.idTranferRequest,
  //     th.date AS date,
  //     sender_staff.name AS sender_name,
  //     receiver_staff.name AS receiver_name,
  //     af.name AS fromAreaName,
  //     at.name AS toAreaName,
  //     wf.name AS fromWarehouseName,
  //     wt.name AS toWarehouseName
  // FROM 
  //     item i
  // JOIN 
  //     tranferrequestdetail trd ON i.idItem = trd.idItem
  // JOIN 
  //     tranferrequest tr ON trd.idTranferRequest = tr.idTranferRequest
  // JOIN 
  //     tranferhistory th ON tr.idTranferRequest = th.idTranferRequest
  // JOIN 
  //     area af ON tr.fromArea = af.idArea
  // JOIN 
  //     area at ON tr.toArea = at.idArea
  // JOIN 
  //     warehouse wf ON af.idWarehouse = wf.idWarehouse
  // JOIN 
  //     warehouse wt ON at.idWarehouse = wt.idWarehouse
  // JOIN 
  //     staff sender_staff ON th.sender = sender_staff.idStaff
  // JOIN 
  //     staff receiver_staff ON th.receiver = receiver_staff.idStaff
  // WHERE 
  //     tr.status = 'Chấp nhận'
  // AND
  //     i.idItem = ?
  // ORDER BY 
  //     th.date DESC;

  let query = `
  SELECT 
      i.idItem,
      trd.idTranferRequest,
      tr.date_answer AS date,

      af.name AS fromAreaName,
      at.name AS toAreaName,
      wf.name AS fromWarehouseName,
      wt.name AS toWarehouseName
  FROM 
      item i
  JOIN 
      tranferrequestdetail trd ON i.idItem = trd.idItem
  JOIN 
      tranferrequest tr ON trd.idTranferRequest = tr.idTranferRequest
  JOIN 
      area af ON tr.fromArea = af.idArea
  JOIN 
      area at ON tr.toArea = at.idArea
  JOIN 
      warehouse wf ON af.idWarehouse = wf.idWarehouse
  JOIN 
      warehouse wt ON at.idWarehouse = wt.idWarehouse
  WHERE 
      tr.status = 'Chấp nhận'
  AND
      i.idItem = ?
  ORDER BY 
      tr.date_answer DESC;
  

   `;

  connection.query(query, [req.query.idItem], (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    res.json(results);
  });
});


// lấy ra loại thiết bị theo idtem
app.get('/getCategoryByIdItem', (req, res) => {

  let query = `
  SELECT 
    c.name AS category_name
  FROM 
    item i
  JOIN category c ON i.idCategory = c.idCategory
  WHERE i.idItem = ?

   `;

  connection.query(query, [req.query.idItem], (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    res.json(results[0]);
  });
});


// lấy thông báo các thiết bị sắp đến hạn rồi gửi mail đi( ở đây chỉ lấy dữ liệu thôi)
app.get('/sendMaintanceitem', (req, res) => {

  let query = `
  SELECT 
    i.idItem AS idItem,
    c.name AS category,
    c.idCategory AS idCategory,
    a.name AS area,
    a.idArea,
    w.name AS warehouse,
    w.idWarehouse AS idWarehouse,
    i.maintanceDate AS maintanceDate,
    i.renewDate AS renewDate,
    p.idPIC AS idPIC,
    p.email
FROM 
    Item i
    LEFT JOIN Category c ON i.idCategory = c.idCategory
    LEFT JOIN Area a ON i.idArea = a.idArea
    LEFT JOIN Warehouse w ON a.idWarehouse = w.idWarehouse
    LEFT JOIN PIC p ON w.idPIC = p.idPIC
WHERE 
    (DATEDIFF(i.maintanceDate, NOW()) < 150 
    OR DATEDIFF(i.renewDate, NOW())) < 300
    AND i.maintanceRequested = 0;
  
   `;

  connection.query(query, (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }
    res.json(results);
  });
});

// lấy thông tin thiết bị đến hạn bảo trì theo PIC
app.get('/getMaintanceitemByPIC', (req, res) => {

  let query = `
   SELECT 
    i.idItem AS idItem,
    c.name AS category,
    c.idCategory AS idCategory,
    a.name AS area,
    a.idArea,
    w.name AS warehouse,
    w.idWarehouse AS idWarehouse,
    i.maintanceDate AS maintanceDate,
    i.renewDate AS renewDate,
    p.idPIC AS idPIC,
    p.email,
    i.status AS status,
    i.image AS image
FROM 
    Item i
    LEFT JOIN Category c ON i.idCategory = c.idCategory
    LEFT JOIN Area a ON i.idArea = a.idArea
    LEFT JOIN Warehouse w ON a.idWarehouse = w.idWarehouse
    LEFT JOIN PIC p ON w.idPIC = p.idPIC
WHERE 
    (DATEDIFF(i.maintanceDate, NOW()) < 150 
    OR DATEDIFF(i.renewDate, NOW()) < 300)
    AND i.maintanceRequested = 0
    AND i.status != 'Bỏ'
    AND p.idPIC = ?;
    ;
   `;

  connection.query(query, [req.query.idPIC], (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }
    res.json(results);
  });
});


app.post('/postUpdateStatusMaintanceRequest', (req, res) => {

  let query =
    `
      Update maintanceRequest
        set status = ?, 
        reasonManager = ? 
      Where idMaintanceRequest = ?
      `;

  connection.query(query, [req.query.status, req.query.reasonManager, req.query.idMaintanceRequest], (err, result) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }
    res.json(result);
  });
});


app.post('/postUpdateRequestedItem', (req, res) => {

  let query =
    `
      update Item set maintanceRequested = ? where idItem = ?
      `;

  connection.query(query, [req.query.maintanceRequested, req.query.idItem], (err, result) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }
    res.json(result);
  });
});

app.post('/postUpdateExtendItem', (req, res) => {

  let query =
    `
      update Item set maintanceRequested = ? where idItem = ?
      `;

  connection.query(query, [req.query.maintanceRequested, req.query.idItem], (err, result) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }
    res.json(result);
  });
});

app.post('/postUpdateMaintanceItem', (req, res) => {

  let query =
    `
      update Item set status = ? where idItem = ?
      `;

  connection.query(query, [req.query.type, req.query.idItem], (err, result) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }
    res.json(result);
  });
});

app.post('/postUpdateBorItem', (req, res) => {

  let query =
    `
      update Item set status= 'Bỏ' where idItem = ?
      `;

  connection.query(query, [req.query.idItem], (err, result) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }
    res.json(result);
  });
});


app.post('/postUpdateExtendItem', (req, res) => {

  let query =
    `
      UPDATE Item
      SET 
          maintanceDate = DATE_ADD(maintanceDate, INTERVAL ? MONTH),
          renewDate = DATE_ADD(renewDate, INTERVAL ? MONTH)
      WHERE idItem = ?;

      `;

  connection.query(query, [req.query.extend, req.query.extend, req.query.idItem], (err, result) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }
    res.json(result);
  });
});



app.get('/getImageIdItem', (req, res) => {

  let query = `
      select image from Item WHERE idItem = ?
   `;

  connection.query(query, [req.query.idItem], (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }
    res.json(results[0].image);
  });
});



app.get('/getManagerEmailActive', (req, res) => {

  let query = `
      select email from manager WHERE active = 1
   `;

  connection.query(query, (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }
    res.json(results[0].email);
  });
});


//gửi email thông báo cho PIC khi có yêu cầu tranfer được trả lời
app.get('/sendMailResultTranferRequestForPIC', (req, res) => {
  let data = req.body;
  let query = `
      SELECT
          TR.idTranferRequest,
          TR.status AS status,
          PIC_toArea.name AS toArea_pic_name,
          PIC_toArea.email AS PIC_toArea_email,
          Warehouse_toArea.name AS toArea_warehouse_name,
          PIC_fromArea.email AS PIC_fromArea_email,
          PIC_fromArea.name AS fromArea_pic_name,
          Warehouse_fromArea.name AS fromArea_warehouse_name,
          A_toArea.name as toArea_name,
          A_fromArea.name as fromArea_name
      FROM
          tranferrequest AS TR
      LEFT JOIN
          area AS A_toArea ON TR.toArea = A_toArea.idArea
      LEFT JOIN
          warehouse AS Warehouse_toArea ON A_toArea.idWarehouse = Warehouse_toArea.idWarehouse
      LEFT JOIN
          pic AS PIC_toArea ON Warehouse_toArea.idPIC = PIC_toArea.idPIC
      LEFT JOIN
          area AS A_fromArea ON TR.fromArea = A_fromArea.idArea
      LEFT JOIN
          warehouse AS Warehouse_fromArea ON A_fromArea.idWarehouse = Warehouse_fromArea.idWarehouse
      LEFT JOIN
          pic AS PIC_fromArea ON Warehouse_fromArea.idPIC = PIC_fromArea.idPIC
      WHERE
          TR.idTranferRequest = ?;
   `;

  connection.query(query, [req.query.idTranferRequest], (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    sendMailResultTranferRequestForPIC(results[0], data);
    res.json(results);
  });
});



// hàm post yêu cầu đăng kí thiết bị
app.post('/postRegisterDevice', (req, res) => {
  let datas = req.body;
  let idRegisterDeviceRequest = req.query.idRegisterDeviceRequest;
  console.log(idRegisterDeviceRequest)
  let varData = [];
  let query = `
      insert into RegisterDevice(idCategory, name, num, image, idRegisterDeviceRequest, maintanceCycle, renewCycle, PO) 
      VALUES  
   `;

  for (let i = 0; i < datas.length; i++) {
    query += ` 
    (?, ?, ?, ?, ?, ?, ?, ?)
     `;
    if (i < datas.length - 1) {
      query += ',';
    }

    varData.push(datas[i].category, datas[i].name, datas[i].quantity, datas[i].image, idRegisterDeviceRequest, datas[i].maintenanceCycle, datas[i].renewCycle, datas[i].PO);
  }

  connection.query(query, varData, (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }


    res.json(results);
  });
});

//
app.post('/postRegisterDeviceRequest', (req, res) => {
  const query = `
      INSERT INTO registerdevicerequest (date, status)
      VALUES (CURDATE(), 'Đang chờ');
  `;

  connection.query(query, (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    const idRegisterDeviceRequest = results.insertId;
    res.json({ idRegisterDeviceRequest });
  });
});

app.get('/sendRegisterNewDeviceForManager', (req, res) => {
  const query = `
  SELECT
      rd.*,
      c.name AS category_name
  FROM
      registerdevice AS rd
  LEFT JOIN
      category AS c ON rd.idCategory = c.idCategory
  WHERE
      rd.idRegisterDeviceRequest = ?;
    `;

  connection.query(query, [req.query.idRegisterDeviceRequest], (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    sendRegisterNewDeviceForManager(results, req.query.managerEmail);
    res.json(results);
  });
});


// lấy ra email của manager
app.get('/getManagerEmail', (req, res) => {
  const query = `
  select
     email
  from 
    manager
  where active = 1

  `;

  connection.query(query, (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    res.json(results);
  });
});


// lấy ra các yêu cầu register device
app.get('/getALlRegisterRequests', (req, res) => {
  const page = parseInt(req.query.page) || 1;
  const pageSize = parseInt(req.query.pageSize) || 10;
  const offset = (page - 1) * pageSize;
  let querryFilter = "";
  switch (req.query.filter) {
    case "pending":
      querryFilter += " WHERE status = 'Đang chờ' ";
      break;
    case "reject":
      querryFilter += " WHERE status = 'Từ chối' ";
      break;
    case "accept":
      querryFilter += " WHERE status = 'Chấp nhận' ";
      break;

  }


  const query = `
  select * from registerdevicerequest
  ${querryFilter}
  order by date desc
  limit ?, ?;
  
  `;

  connection.query(query, [offset, pageSize], (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    res.json(results);
  });
});


// lấy ra các số yêu cầu register device
app.get('/getNumAllRegisterRequests', (req, res) => {
  let querryFilter = "";
  switch (req.query.filter) {
    case "pending":
      querryFilter += " WHERE status = 'Đang chờ' ";
      break;
    case "reject":
      querryFilter += " WHERE status = 'Từ chối' ";
      break;
    case "accept":
      querryFilter += " WHERE status = 'Chấp nhận' ";
      break;

  }


  const query = `
select count(*) AS count from registerdevicerequest
${querryFilter}


  `;

  connection.query(query, (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    res.json(results[0].count);
  });
});

// lấy ra dữ liệu của RegisterDeviceRequest theo id
app.get('/getRegisterDeviceRequestById', (req, res) => {

  const query = `
  select * from registerdevicerequest
  where idRegisterDeviceRequest = ?;

    `;

  connection.query(query, [req.query.id], (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    res.json(results[0]);
  });
});


// lấy ra dữ liệu của RegisterDevice theo idRegisterDeviceRequest
app.get('/getAllRegisterDeviceByRegisterDeviceRequestId', (req, res) => {

  const query = `
  SELECT
      rd.*,
      c.name AS category_name
  FROM
      registerdevice AS rd
  LEFT JOIN
      category AS c ON rd.idCategory = c.idCategory
  WHERE
      rd.idRegisterDeviceRequest = ?;


  `;

  connection.query(query, [req.query.id], (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    res.json(results);
  });
});



app.post('/postUpdateStatusRegisterDeviceRequest', (req, res) => {
  const query = `
          update registerDeviceRequest set status = ? where idRegisterDeviceRequest = ?

  `;

  connection.query(query, [req.query.status, req.query.id], (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }


    res.json(results);
  });
});

app.post('/postAddNewCategory', (req, res) => {
  const query = `
          insert into category (name) values (?)

  `;

  connection.query(query, [req.query.categoryName], (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    const idCategory = results.insertId;
    res.json({ idCategory });
  });
});
// thêm thiết bị mới
app.post('/postNewItem', (req, res) => {
  let data = req.body;
  let variables = [];
  let query = `
    INSERT INTO Item (idCategory, image, duration, maintaneceCycle, active, status, receivedDate, maintanceRequested, PO)
    VALUES 
  `;

  // Build the values part of the query
  for (let i = 0; i < data.length; i++) {
    for (let j = 0; j < data[i].num; j++) {
      query += `(?, ?, ?, ?, 0, 'Dự phòng', CURDATE(), 1, ?)`;
      if (i < data.length - 1 || j < data[i].num - 1) {
        query += ', ';
      }
      variables.push(data[i].idCategory, data[i].image, data[i].renewCycle, data[i].renewCycle, data[i].po);
    }
  }

  // Execute the query
  connection.query(query, variables, (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    res.json(results);
  });
});




app.get('/getNewItem', (req, res) => {

  const query = `
  SELECT
     i.idCategory,
     c.name AS categoryName,
     MAX(i.image) AS image,
     COUNT(*) AS itemCount
  FROM
     item i
  LEFT JOIN
     category c ON i.idCategory = c.idCategory
  WHERE
     i.idArea IS NULL
  GROUP BY
     i.idCategory, c.name;


  `;

  connection.query(query, (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    res.json(results);
  });
});


// lấy ra email, tên kho của PIC theo idArea

app.get('/getPICEmailbyIdArea', (req, res) => {
  const query = `
  SELECT DISTINCT
    p.email as email,
    w.name as warehouseName,
    a.name as areaName
  FROM
    pic p
  JOIN warehouse w ON p.idPIC = w.idPIC
  JOIN area a ON w.idWarehouse = a.idWarehouse
  WHERE a.idArea = ?;
  `;

  connection.query(query, [req.query.idArea], (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    if (results.length === 0 || !results[0].email) {
      res.status(404).json({ error: 'Không tìm thấy email cho khu vực được yêu cầu' });
      return;
    }

    res.json(results[0]);
  });
});

// hàm lấy ra các category name theo idCategories
app.get('/getCategoryByIdCategory', (req, res) => {

  let query = `
 select
    name
  from
    category
  where idCategory = ?

  `;


  connection.query(query, [req.query.idCategory], (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    res.json(results[0].name);
  });
});



//post cập nhật chuyển giao thiết bị vô chủ cho PIC
app.post('/postUpdateItemPosition', (req, res) => {
  let data = req.body;
  let variables = [data.idArea];


  let query = `UPDATE Item SET idArea = ? WHERE `;


  data.idItems.forEach((idItem, index) => {
    variables.push(idItem.idItem);
    query += ` idItem = ? `;
    if (index < data.idItems.length - 1) {
      query += ` OR `;
    }
  });

  connection.query(query, variables, (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }
    res.json(results);
  });
});

app.post('/getItemNeedToUpdatePosition', (req, res) => {
  const data = req.body;
  if (!Array.isArray(data) || data.length === 0) {
    res.status(400).json({ error: 'Invalid input data' });
    return;
  }

  const categoryIds = data.map(item => item.categoryId);
  const limit = data.reduce((acc, item) => acc + item.quantity, 0);

  let query = `
    SELECT idItem
    FROM Item
    WHERE idArea IS NULL 
    AND status != 'Bỏ'
    AND idCategory IN (?${", ?".repeat(categoryIds.length - 1)})
    LIMIT ?
  `;

  const variables = [...categoryIds, limit];

  connection.query(query, variables, (err, results) => {
    if (err) {
      console.error('Database query error:', err);
      res.status(500).json({ error: 'Database query error' });
      return;
    }

    res.json(results);
  });
});



app.post('/postUpdateItemStatus', (req, res) => {
  const data = req.body;

  let query;

  if (data.activedOrNot == 0) {
    query = `
    update
       item
    set 
      status = ? 
    where
      idItem = ?
  `;
  } else {
    query = `
    update
       item
    set 
      status = ?,
      activedDate = CURDATE(),
      maintanceDate = DATE_ADD(CURDATE(), INTERVAL maintaneceCycle Month),
      renewDate = DATE_ADD(CURDATE(), INTERVAL duration Month),
      maintanceRequested = 0
    where
      idItem = ?
  `;
  }

  connection.query(query, [data.status, data.idItem], (err, results) => {
    if (err) {
      console.error('Database query error:', err);
      res.status(500).json({ error: 'Database query error' });
      return;
    }

    res.json(results);
  });
});







//// send email thông báo cho pic đã được nhận về thiết bị;




app.get('/sendEmailForPICAboutNewItem', (req, res) => {
  //câu queery để không, nếu xóa thì web bị đứng luôn
  let data = req.body;
  let query = `
 select
    idItem
  from
    item
  limit1

  `;


  connection.query(query, (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }
    sendEmailForPICAboutNewItem(data);
    res.json(results);
  });
});

// lấy ra trạng thái thiết bị theo idItem
app.get('/getStatusByIdItem', (req, res) => {

  let query = `
 select
    status
  from
    item
  where idItem = ?

  `;


  connection.query(query, [req.query.idItem], (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    res.json(results[0]);
  });
});



app.get('/getMaintanceRequestByIdItem', (req, res) => {

  let query = `
  SELECT 
    idMaintanceRequest,
    reason,
    budgetEstimate,
    date,
    type,
    idItem
  FROM maintancerequest
  WHERE status = 'Chấp nhận' 
  AND type <> 'Gia hạn'
    AND idItem = ?
    AND date = (
        SELECT MAX(date)
        FROM maintancerequest
        WHERE status = 'Chấp nhận' 
            AND idItem = ?
            AND date <= CURDATE() 
    )
    limit 1
    ;


  `;


  connection.query(query, [req.query.idItem, req.query.idItem], (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    res.json(results[0]);
  });
});


app.post('/postMaintanceHistory', (req, res) => {
  let data = req.body;

  let query = `
  insert into 
	  maintanceHistory(idItem, idStaff, idMaintanceRequest, dateEnd, type, budget, roleAccept)
  values(?, ?, ?,CURDATE() , ?, ?, ?)


  `;


  connection.query(query, [data.idItem, req.query.idAcc, data.idMaintanceRequest, data.type, data.budgetEstimate, req.query.roleAccept], (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    res.json(results[0]);
  });
});



app.post('/postUpdateMaintanceDate', (req, res) => {


  let query = `
  UPDATE item
  SET maintanceDate = DATE_ADD(maintanceDate, INTERVAL maintaneceCycle MONTH)
  WHERE idItem = ?;


  `;


  connection.query(query, [req.query.idItem], (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    res.json(results[0]);
  });
});


app.get('/getAllStaffAcc', (req, res) => {


  let query = `
  SELECT * FROM Staff


  `;


  connection.query(query, (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    res.json(results);
  });
});



app.delete('/deleteStaffAcc', (req, res) => {


  let query = `
  DELETE FROM
     Staff
  WHERE 
     idStaff = ?;


  `;


  connection.query(query, req.query.id, (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    res.json(results);
  });
});


app.post('/updateStaffAcc', (req, res) => {

  let data = req.body;
  let query = `
  UPDATE Staff
  SET name = ?, username = ?, password = ?, email = ?
  WHERE idStaff = ?;



  `;


  connection.query(query, [data.name, data.username, data.password, data.email, data.id], (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    res.json(results);
  });
});





app.get('/checkStaffAccExist', (req, res) => {


  let query = `
  select count(*) as count from Staff where username = ?;



  `;


  connection.query(query, [req.query.username], (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    res.json(results);
  });
});



app.get('/checkPICAccExist', (req, res) => {


  let query = `
  select count(*) as count from PIC where username = ?;



  `;


  connection.query(query, [req.query.username], (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    res.json(results);
  });
});


app.get('/checkManagerAccExist', (req, res) => {


  let query = `
  select count(*) as count from Manager where username = ?;



  `;


  connection.query(query, [req.query.username], (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    res.json(results);
  });
});




app.post('/createNewStaffAcc', (req, res) => {

  let data = req.body;
  let query = `
   insert into Staff(name, username, password)
    values(?, ?, ?)

  `;


  connection.query(query, [data.name, data.username, data.password], (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    res.json(results);
  });
});




app.get('/getAllPICAcc', (req, res) => {


  let query = `
  select * from PIC;



  `;


  connection.query(query, (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    res.json(results);
  });
});



app.post('/updateAccountantPIC', (req, res) => {


  let query = `
UPDATE pic
SET accountantPIC = CASE 
                        WHEN idPIC = ? THEN 1
                        ELSE 0
                    END
WHERE idPIC > 0;


  `;


  connection.query(query, [req.query.id], (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    res.json(results);
  });
});




app.post('/createNewPICAcc', (req, res) => {

  let data = req.body;
  let query = `
   insert into PIC(name, username, password, email, accountantPIC)
    values(?, ?, ?, ?, 0)

  `;


  connection.query(query, [data.name, data.username, data.password, data.email], (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    res.json(results);
  });
});



app.delete('/deletePICAcc', (req, res) => {


  let query = `
  DELETE FROM
     PIC
  WHERE 
     idPIC = ?;


  `;


  connection.query(query, req.query.id, (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    res.json(results);
  });
});


app.post('/updatePICAcc', (req, res) => {

  let data = req.body;
  let query = `
  UPDATE PIC
  SET name = ?, username = ?, password = ?, email = ?
  WHERE idPIC = ?;



  `;


  connection.query(query, [data.name, data.username, data.password, data.email, data.id], (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    res.json(results);
  });
});



app.get('/getAllManagerAcc', (req, res) => {


  let query = `
  select * from Manager
where admin = 0


  `;


  connection.query(query, (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    res.json(results);
  });
});



app.post('/createNewManagerAcc', (req, res) => {

  let data = req.body;
  let query = `
   insert into Manager(name, username, password, email, active, admin)
    values(?, ?, ?, ?, 0, 0)

  `;


  connection.query(query, [data.name, data.username, data.password, data.email], (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    res.json(results);
  });
});




app.delete('/deleteManagerAcc', (req, res) => {


  let query = `
    DELETE FROM
      Manager
  WHERE 
     idManager = ?;

  `;


  connection.query(query, req.query.id, (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    res.json(results);
  });
});


app.post('/updateManagerAcc', (req, res) => {

  let data = req.body;
  let query = `
  UPDATE Manager
  SET name = ?, username = ?, password = ?, email = ?
  WHERE idManager = ?;



  `;


  connection.query(query, [data.name, data.username, data.password, data.email, data.id], (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    res.json(results);
  });
});


app.post('/updateActiveManager', (req, res) => {


  let query = `
UPDATE Manager
SET active = CASE 
                        WHEN idManager = ? THEN 1
                        ELSE 0
                    END
WHERE idManager > 0;


  `;


  connection.query(query, [req.query.id], (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    res.json(results);
  });
});


app.post('/getStaff', (req, res) => {


  let query = `
select * from Staff where idStaff = ?;


  `;


  connection.query(query, [req.query.id], (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    res.json(results);
  });
});


app.post('/getPIC', (req, res) => {


  let query = `
select * from PIC where idPIC = ?;


  `;


  connection.query(query, [req.query.id], (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    res.json(results);
  });
});

app.post('/getManager', (req, res) => {


  let query = `
select * from Manager where idManager = ?;


  `;


  connection.query(query, [req.query.id], (err, results) => {
    if (err) {
      console.error('Lỗi truy vấn cơ sở dữ liệu:', err);
      res.status(500).json({ error: 'Lỗi truy vấn cơ sở dữ liệu' });
      return;
    }

    res.json(results);
  });
});




app.listen(3000, () => {
  console.log('Server is running at http://localhost:3000');
});



