const axios = require('axios');
const { JSDOM } = require('jsdom');
const jquery = require('jquery');
const { window } = new JSDOM();
const $ = jquery(window);
const { authenSendMail, sendEmailMaintanceItems, sendEmailRequestMaintaceItem } = require('./SendMail.js');


// Hàm gửi email tự động cho pic những thiết bị cần bảo trì
function autoSendMaintanceItemToPIC() {
    $.ajax({
        url: `http://localhost:3000/sendMaintanceitem`,
        type: 'GET',
        async: false,
    })
        .done(function (results) {
            let processedData = [];

            // Duyệt qua từng mục trong kết quả truy vấn
            results.forEach(result => {
                // Tìm kiếm xem idPIC đã tồn tại trong processedData chưa
                let existingItem = processedData.find(item => item.idPIC === result.idPIC);

                if (!existingItem) {
                    // Nếu idPIC chưa tồn tại, tạo một đối tượng mới
                    let newItem = {
                        idPIC: result.idPIC,
                        email: result.email,
                        data: [{
                            idItem: result.idItem,
                            category: result.category,
                            area: result.area,
                            warehouse: result.warehouse,
                            maintanceDate: result.maintanceDate,
                            renewDate: result.renewDate
                        }]
                    };
                    // Thêm đối tượng mới vào processedData
                    processedData.push(newItem);
                } else {
                    // Nếu idPIC đã tồn tại, thêm thông tin mới vào mảng data của đối tượng đã tồn tại
                    existingItem.data.push({
                        idItem: result.idItem,
                        category: result.category,
                        area: result.area,
                        warehouse: result.warehouse,
                        maintanceDate: result.maintanceDate,
                        renewDate: result.renewDate
                    });
                }
            });


            sendEmailMaintanceItems(processedData)
                .then(() => {
                    console.log("Tất cả email đã được gửi thành công.");
                })
                .catch(error => {
                    console.error("Đã xảy ra lỗi khi gửi email:", error);
                });
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error('Error fetching items: ' + textStatus);
        });
}

// hàm gửi những thiết bị được request cho manager
function autoSendRequestMaintanceItemToManager() {
    $.ajax({
        url: `http://localhost:3000/getAllMaintanceRequest?filter=Đang chờ`,
        type: 'GET',
        async: false,
    })
        .done(function (results) {
            // lấy email
            let rs = [getManagerEmailActive()]
            results.forEach(result => {
                rs.push({
                    category: result.categoryName,
                    area: result.areaName,
                    warehouse: result.warehouseName,
                    idItem: result.idItem,
                    date: result.date,
                    type: result.type,
                    reason: result.reason,
                })
            });
            sendEmailRequestMaintaceItem(rs);
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error('Error fetching items: ' + textStatus);
        });
}




// hàm lấy ra email của manager đang active
function getManagerEmailActive() {
    let rs;
    $.ajax({
        url: `http://localhost:3000/getManagerEmailActive`,
        type: 'GET',
        async: false,
    })
        .done(function (email) {
            rs = email;
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
    return rs;
  }


// autoSendRequestMaintanceItemToManager()


// setInterval(autoSendMaintanceItemToPIC, 1000 * 1 * 60);
console.log("autorun đang chạy");
// getInfor();
// setInterval(getInfor, 1000 * 5 * 60);





