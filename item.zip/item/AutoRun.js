const axios = require('axios');
const { JSDOM } = require('jsdom');
const jquery = require('jquery');
const { window } = new JSDOM();
const $ = jquery(window);
const { authenSendMail, sendEmailDangKiemItems, sendEmailMaintanceItems, sendEmailRequestMaintaceItem, sendEmailAnswerAddNewItem } = require('./SendMail.js');
const { set } = require('date-fns');


// Hàm gửi email tự động cho pic những thiết bị cần bảo trì
function autoSendMaintanceItemToPIC() {
    $.ajax({
        url: `http://localhost:3000/sendMaintanceitem`,
        type: 'GET',
        async: false,
    })
        .done(function (results) {
            if (results.length == 0) return;
            let processedData = [];

            // Duyệt qua từng mục trong kết quả truy vấn
            results.forEach(result => {
                // Tìm kiếm xem idPIC đã tồn tại trong processedData chưa
                let existingItem = processedData.find(item => item.idPIC === result.idPIC);

                if (!existingItem) {
                    // Nếu idPIC chưa tồn tại, tạo một đối tượng mới
                    let newItem = {
                        idPIC: result.idPIC,
                        email: result.email,
                        data: [{
                            idItem: result.idItem,
                            category: result.category,
                            area: result.area,
                            warehouse: result.warehouse,
                            maintanceDate: result.maintanceDate,
                            renewDate: result.renewDate
                        }]
                    };
                    // Thêm đối tượng mới vào processedData
                    processedData.push(newItem);
                } else {
                    // Nếu idPIC đã tồn tại, thêm thông tin mới vào mảng data của đối tượng đã tồn tại
                    existingItem.data.push({
                        idItem: result.idItem,
                        category: result.category,
                        area: result.area,
                        warehouse: result.warehouse,
                        maintanceDate: result.maintanceDate,
                        renewDate: result.renewDate
                    });
                }
            });


            sendEmailMaintanceItems(processedData)
                .then(() => {
                    console.log("Tất cả email đã được gửi thành công.");
                })
                .catch(error => {
                    console.error("Đã xảy ra lỗi khi gửi email:", error);
                });
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error('Error fetching items: ' + textStatus);
        });
}


// hàm gửi những thiết bị đến hạn đăng kiểm cho PIC
function autoSendDangKiemItemToPIC() {
    $.ajax({
        url: `http://localhost:3000/sendDangKiemitem`,
        type: 'GET',
        async: false,
    })
        .done(function (results) {
            if (results.length == 0) return;
            let processedData = [];

            // Duyệt qua từng mục trong kết quả truy vấn
            results.forEach(result => {
                // Tìm kiếm xem idPIC đã tồn tại trong processedData chưa
                let existingItem = processedData.find(item => item.idPIC === result.idPIC);

                if (!existingItem) {
                    // Nếu idPIC chưa tồn tại, tạo một đối tượng mới
                    let newItem = {
                        idPIC: result.idPIC,
                        email: result.email,
                        data: [{
                            idItem: result.idItem,
                            category: result.category,
                            area: result.area,
                            warehouse: result.warehouse,
                            dangKiem: result.dangKiem,
                        }]
                    };
                    // Thêm đối tượng mới vào processedData
                    processedData.push(newItem);
                } else {
                    // Nếu idPIC đã tồn tại, thêm thông tin mới vào mảng data của đối tượng đã tồn tại
                    existingItem.data.push({
                        idItem: result.idItem,
                        category: result.category,
                        area: result.area,
                        warehouse: result.warehouse,
                        dangKiem: result.dangKiem,
                    });
                }
            });


            sendEmailDangKiemItems(processedData)
                .then(() => {
                    console.log("Tất cả email đã được gửi thành công.");
                })
                .catch(error => {
                    console.error("Đã xảy ra lỗi khi gửi email:", error);
                });
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error('Error fetching items: ' + textStatus);
        });
}



// hàm gửi những thiết bị đến hạn được request cho manager
function autoSendRequestMaintanceItemToManager() {
    $.ajax({
        url: `http://localhost:3000/getAllMaintanceRequest?filter=pending`,
        type: 'GET',
        async: false,
    })
        .done(function (results) {
            // lấy email
            if (results.length == 0) return;
            let rs = [getManagerEmailActive()]
            results.forEach(result => {
                rs.push({
                    category: result.categoryName,
                    area: result.areaName,
                    warehouse: result.warehouseName,
                    idItem: result.idItem,
                    date: result.date,
                    type: result.type,
                    reason: result.reason,
                })
            });
            sendEmailRequestMaintaceItem(rs);
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error('Error fetching items: ' + textStatus);
        });
}


//hàm tự động gửi mail cho manager khi chưa trả lời đơn thêm mới thiết bị
function autoSendRequestAddNewItemToManager() {

    $.ajax({
        url: `http://localhost:3000/getALlRegisterRequests?filter=pending`,
        type: 'GET',
        async: false,
    })
        .done(function (results) {
            // lấy email
            if (results.length == 0) return;

            sendEmailAnswerAddNewItem(getManagerEmailActive());
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error('Error fetching items: ' + textStatus);
        });
}


// hàm lấy ra email của manager đang active
function getManagerEmailActive() {
    let rs;
    $.ajax({
        url: `http://localhost:3000/getManagerEmailActive`,
        type: 'GET',
        async: false,
    })
        .done(function (email) {
            rs = email;
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
    return rs;
}


// autoSendRequestMaintanceItemToManager()


console.log("autorun đang chạy");






function runAllFunction() {
    autoSendMaintanceItemToPIC();
    setTimeout(autoSendDangKiemItemToPIC, 5000);
    setTimeout(autoSendRequestMaintanceItemToManager, 10000);
    setTimeout(autoSendRequestAddNewItemToManager, 15000);
}



// Tính toán thời gian đến thời điểm cụ thể
function getTimeUntil(targetHour, targetMinute) {
    const now = new Date();
    const target = new Date(now.getFullYear(), now.getMonth(), now.getDate(), targetHour, targetMinute, 0, 0);

    if (target < now) {
        // Nếu thời điểm mục tiêu đã qua trong ngày hiện tại, đặt lại cho ngày hôm sau
        target.setDate(target.getDate() + 1);
    }

    return target - now;
}

const targetHour = 8;
const targetMinute = 15;

// Tính toán khoảng thời gian đến thời điểm mục tiêu
const delay = getTimeUntil(targetHour, targetMinute);

// Đặt lịch thực thi hàm tại thời điểm mục tiêu
setTimeout(() => {
    setInterval(runAllFunction, 24 * 60 * 60 * 1000); 
}, delay);