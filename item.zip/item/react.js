//Refresh button
document.getElementById('refreshButton').addEventListener('click', function() {
    var alertBox = document.getElementById('alertBox');
    document.getElementById('text').innerHTML = '<strong>Info!</strong> Refresh button clicked!';
    chartAreaWrapper.scrollLeft = chartAreaWrapper.scrollWidth; 
    averageChart.scrollLeft = averageChart.scrollWidth;
    alertBox.style.display = 'block';
    var timeoutId = setTimeout(function() {
        alertBox.style.display = 'none';
        cancelButton.removeEventListener('click', cancelAlert);
    }, 1250);

    var cancelButton = document.getElementById('cancelButton');
    function cancelAlert() {
        clearTimeout(timeoutId);
        alertBox.style.display = 'none';
        cancelButton.removeEventListener('click', cancelAlert);
    }
    cancelButton.addEventListener('click', cancelAlert);
    //return old value
    maxPoints = 10;
    maxPoints2 = 29;
    maxPoints3 = 12;
    adjustCanvasWidth();
    scrollToEnd();
    scrollToEnd2();
    if(switchButton.checked){
        updateAverageChart(monthlyAverageChart, averageMonthlyHum, averageMonthlyTemp, averageMonths,maxPoints3,averageChartlogic);
    }else{
        updateAverageChart(monthlyAverageChart, dailyAverageHum, dailyAverageTemp, averageDate,maxPoints2,averageChartlogic);
    };
    getVar();
    getAverageVar();
    document.getElementById('start-date').value = '';
    document.getElementById('end-date').value = '';

});
//Limitation table for humidity and temperature
//show menu button to setting the limit value   
document.getElementById('showMenuButton').addEventListener('click', function() {
    document.getElementById('colorRangeMenu').style.display = 'block';
});
//
//Declare setting popup
var modal = document.getElementById('colorRangeMenu');
var btn = document.getElementById("showMenuButton");
var span = document.getElementsByClassName("close")[2];
// var tempBlueMax = 20;
// var tempGreenMax = 25;
// var humBlueMax = 60;
// var humGreenMax = 80;
var scrollCheck = false;
//React on pop up
btn.onclick = function() {
    modal.style.display = "block";
}

span.onclick = function() {
    modal.style.display = "none";
}

window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
//Check logic for setting the limit value, if the blue value is less than green value, return true
function checkSetting(blueVar, greenVar){
    if(blueVar < greenVar){
        return true;
    }
    return false;
}
//Update color range button from setting menu
async function  updateColorRange(limVar) {
    // Update color range here
    let tempBlueMax = parseInt(document.getElementById('tempBlueMax').value);
    let tempGreenMax = parseInt(document.getElementById('tempGreenMax').value);
    let humBlueMax = parseInt(document.getElementById('humBlueMax').value);
    let humGreenMax = parseInt(document.getElementById('humGreenMax').value);
    if(checkSetting(tempBlueMax, tempGreenMax)){
        limVar.tempBlueMax = tempBlueMax;
        limVar.tempGreenMax = tempGreenMax;
    }else{
        let alertBox = document.getElementById('settingAlert');
        document.getElementById('warningText').innerHTML = '<strong>Warning!</strong> Incorrect setting for temperature or humidity color range!';
        alertBox.style.display = 'block';
        let timeoutId = setTimeout(function() {
            alertBox.style.display = 'none';
            cancelButton.removeEventListener('click', cancelAlert);
        }, 1250);
    
        let cancelButton = document.getElementById('settingCancelButton');
        function cancelAlert() {
            clearTimeout(timeoutId);
            alertBox.style.display = 'none';
            cancelButton.removeEventListener('click', cancelAlert);
        }
        cancelButton.addEventListener('click', cancelAlert);
    }
    if(checkSetting(humBlueMax, humGreenMax)){  
        limVar.humBlueMax = humBlueMax;
        limVar.humGreenMax = humGreenMax;
    }else{
        let alertBox = document.getElementById('settingAlert');
        document.getElementById('warningText').innerHTML = '<strong>Warning!</strong> Incorrect setting for humidity color range!';
        alertBox.style.display = 'block';
        let timeoutId = setTimeout(function() {
            alertBox.style.display = 'none';
            cancelButton.removeEventListener('click', cancelAlert);
        }, 1250);
    
        let cancelButton = document.getElementById('settingCancelButton');
        function cancelAlert() {
            clearTimeout(timeoutId);
            alertBox.style.display = 'none';
            cancelButton.removeEventListener('click', cancelAlert);
        }
        cancelButton.addEventListener('click', cancelAlert);
    }
    //updateCircleColor('tempCircle', currentTemp, tempBlueMax, tempGreenMax);
    //updateCircleColor('tempCircle2', currentHum, humBlueMax, humGreenMax);
    if(!checkSetting(tempBlueMax, tempGreenMax) || !checkSetting(humBlueMax, humGreenMax)){return}
    updateColorTable(limVar);
    modal.style.display = "none";
    var alertBox = document.getElementById('alertBox');
    document.getElementById('text').innerHTML = '<strong>Info!</strong> Updated!';
    alertBox.style.display = 'block';
    var timeoutId = setTimeout(function() {
        alertBox.style.display = 'none';
        cancelButton.removeEventListener('click', cancelAlert);
    }, 1250);

    var cancelButton = document.getElementById('cancelButton');
    function cancelAlert() {
        clearTimeout(timeoutId);
        alertBox.style.display = 'none';
        cancelButton.removeEventListener('click', cancelAlert);
    }
    cancelButton.addEventListener('click', cancelAlert);
    let a = await updateLimVarToJSON(limVar);
    console.log(a);
}
function updateCircleColor(elementId, value, blueMax, greenMax) {
    var element = document.getElementById(elementId);
    if (value <= blueMax) {
        element.style.backgroundColor = 'blue';
    } else if (value <= greenMax) {
        element.style.backgroundColor = 'green';
    } else {
        element.style.backgroundColor = 'red';
    }
}
//Function to insert condition data to color table
var colorTable = document.getElementById('colorTable').getElementsByTagName('tbody')[0];
function updateColorTable(limVar){
    colorTable.rows[1].cells[1].innerHTML = '<span>&#8804; </span>' + limVar.tempBlueMax;
    colorTable.rows[1].cells[2].innerHTML = limVar.tempBlueMax + ' - ' + limVar.tempGreenMax;
    colorTable.rows[1].cells[3].innerHTML = '> ' + limVar.tempGreenMax;
    colorTable.rows[1].cells[4].innerHTML = '<span>&#8804; </span>' + limVar.humBlueMax;    
    colorTable.rows[1].cells[5].innerHTML = limVar.humBlueMax + ' - ' + limVar.humGreenMax; 
    colorTable.rows[1].cells[6].innerHTML = '> ' + limVar.humGreenMax;
    var colors = ['blue', 'green', 'red'];
    for (var i = 1; i < 4; i++) {
        var cell = colorTable.rows[2].cells[i];
        cell.innerHTML = '<div class="color-circle" style="background-color: ' + colors[i-1 ] + ';"></div>';
        cell = colorTable.rows[2].cells[i+3];
        cell.innerHTML = '<div class="color-circle" style="background-color: ' + colors[i-1 ] + ';"></div>';
    }
}

//Filter data
document.getElementById('filter-button').addEventListener('click',  function() {
    ajax_getAverageDate();
    ajax_getAverageMonth();
    let sDate = new Date(document.getElementById('start-date').value);
    let eDate = new Date(document.getElementById('end-date').value);
    let startDate = sDate.toISOString().split('T')[0];
    let endDate = eDate.toISOString().split('T')[0];
    //console.log(startDate, endDate);
    //Assuming chartData is an array of objects with a date property
    var startIndex2 = averageDate.findIndex(date =>  date >= startDate);
    var endIndex2 = averageDate.findLastIndex(date => date <= endDate );
    //averageChart.scrollLeft = startIndex2/averageDate.length*a;
   
    averageChartlogic = false;
    let startMonth = sDate.toISOString().slice(0,7);
    let endMonth = eDate.toISOString().slice(0,7);
    console.log(startMonth);
    let startIndex = averageMonths.findIndex((month) => startMonth.includes(month));
    let endIndex = averageMonths.findIndex((month)=> endMonth.includes(month));
    //averageChart.scrollLeft = startIndex/averageMonths.length*averageChart.scrollWidth;
    maxPoints3 = endIndex - startIndex +1;
    //averageChart.scrollLeft = startIndex2 / averageDate.length * averageChart.scrollWidth;
    maxPoints2 = endIndex2 - startIndex2 + 1;
    if(switchButton.checked){
        averageChart.scrollLeft = startIndex/(averageMonths.length - maxPoints3)*averageChart.scrollWidth;
        scrollToEnd2();
        updateAverageChart(monthlyAverageChart, averageMonthlyHum, averageMonthlyTemp, averageMonths,maxPoints3,averageChartlogic);
        console.log('2nd update prevented')
        
    }else{
        averageChart.scrollLeft = startIndex2 / (averageDate.length-maxPoints2) * averageChart.scrollWidth;
        scrollToEnd2();
        updateAverageChart(monthlyAverageChart, dailyAverageHum, dailyAverageTemp, averageDate,maxPoints2,averageChartlogic);
        console.log('2nd update prevented');
        
    }
    startIndex = i.findIndex((date)=> date.split(' ')[0] >= startDate);
    endIndex = i.findLastIndex((date)=> date.split(' ')[0] <= endDate);
    maxPoints = endIndex - startIndex + 1;
    chartAreaWrapper.scrollLeft = startIndex / (i.length-maxPoints)* chartAreaWrapper.scrollWidth;
    adjustCanvasWidth();
    scrollToEnd();
    scrollCheck = false;
    //Update your chart with the filtered data
    // monthlyAverageChart.data.labels = averageDate.slice(startIndex2, endIndex2 + 1);
    // monthlyAverageChart.data.datasets[0].data = Object.values(dailyAverageTemp.slice(startIndex2, endIndex2 + 1));
    // monthlyAverageChart.data.datasets[1].data = Object.values(dailyAverageHum.slice(startIndex2, endIndex2 + 1));
    // monthlyAverageChart.update()month;
    return;
});

// Function to update display of current data
function updateDisplay(currentTemp, currentHum, limVar) {
    document.getElementById('currentTemp').innerHTML = currentTemp + " °C";
    document.getElementById('currenthum').innerHTML = currentHum + " %";
    // updateCircleColor('tempCircle', currentTemp);
    // updateCircleColor('tempCircle2', currentHum);
    updateCircleColor('tempCircle', currentTemp, limVar.tempBlueMax, limVar.tempGreenMax);
    updateCircleColor('tempCircle2', currentHum, limVar.humBlueMax, limVar.humGreenMax);
}
document.getElementById('formUpdate').addEventListener('submit', function(event) {
    event.preventDefault();
    updateColorRange(limVar);
});
