const axios = require('axios');
const { JSDOM } = require('jsdom');
const jquery = require('jquery');
const { window } = new JSDOM();
const $ = jquery(window);

console.log("send mail đang chạy");

var data = {
    UserName: "dx-dmvn01",
    Password: "dx-dmvn01sec-@2024"
};

// var data2 = {
//     SystemName: "he thong 1",
//     Subject: "Test",
//     EmailContent: "System verify",
//     SendTo: ["nguyen.van.minh.a3n@ap.denso.com"],
//     Cc: ["nguyen.van.minh.a3n@ap.denso.com"]
// };


//3.
async function authenSendMail(data2) {
    axios.post('http://10.73.131.20/emailapi/api/EmailHelper/authenticate', JSON.stringify(data), {
        headers: {
            'Content-Type': 'application/json'
        }
    })
        .then(async function (response) {
            if (response.status === 200) {

                console.log("Success1:", response.data);
                await sendMail(data2, response.data.token);
                return response;
            } else {
                throw new Error('Error:', response.statusText);
            }
        })
        .catch(function (error) {
            console.log(error);
        });
}

async function sendMail(data, accessToken) {
    axios.post('http://10.73.131.20/emailapi/api/EmailHelper/SendEmail', JSON.stringify(data), {
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + accessToken
        }
    })
        .then(function (response) {
            if (response.status === 200) {

                return response.config.data;
            } else {
                throw new Error('Error:', response.statusText);
            }
        })
        .then(function (responseData) {
            console.log("Success:", JSON.parse(responseData).EmailContent);
        })
        .catch(function (error) {
            console.log("Error:", error);
        });
}


async function sendEmailRequestMaintaceItem(processedData) {
    let dataTable = "<table style='border-collapse: collapse; width: 100%;'>";
    dataTable +=
        `<thead>
            <tr>
                <th style='border: 1px solid #ddd; padding: 8px;'>Thiết bị</th>
                <th style='border: 1px solid #ddd; padding: 8px;'>Vị trí</th>
                <th style='border: 1px solid #ddd; padding: 8px;'>Loại yêu cầu</th>
                <th style='border: 1px solid #ddd; padding: 8px;'>Lý do</th>
                <th style='border: 1px solid #ddd; padding: 8px;'>Ngày yêu cầu</th>
            </tr>
          </thead>
          <tbody>`;
    processedData.forEach(data => {
        dataTable += `<tr>
        <td style='border: 1px solid #ddd; padding: 8px;'>${data.category} (mã: ${data.idItem})</td>
        <td style='border: 1px solid #ddd; padding: 8px;'>${data.warehouse} - ${data.area}</td>
        <td style='border: 1px solid #ddd; padding: 8px;'>${data.type}</td>
        <td style='border: 1px solid #ddd; padding: 8px;'>${data.reason}</td>
        <td style='border: 1px solid #ddd; padding: 8px;'>${formatDate(data.date)}</td>
    </tr>
    `;
    });

    dataTable += "</tbody></table>";
    let linkUrl = "http://127.0.0.1:5501/view/register/login.html?location=listMaintanceRequest";
    let linkText = "Ấn vào link để xem chi tiết";
    dataTable += `<p><a href="${linkUrl}" style="color: blue;">${linkText}</a></p>`;

    let dataSend = {
        SystemName: "Hệ thống MIS",
        Subject: "Thông báo xử lí yêu cầu bảo trì thiết bị",
        EmailContent: dataTable,
        SendTo: [processedData[0]],
        Cc: [processedData[0]]
    };

    // Gọi hàm authenSendMail với await để chờ đợi hoàn thành
    await authenSendMail(dataSend);
}

async function sendEmailMaintanceItems(processedData) {
    // Vòng lặp forEach để duyệt qua từng item trong processedData
    for (let item of processedData) {
        let dataTable = "<table style='border-collapse: collapse; width: 100%;'>";
        dataTable +=
            `<thead>
            <tr>
                <th style='border: 1px solid #ddd; padding: 8px;'>Thiết bị</th>
                <th style='border: 1px solid #ddd; padding: 8px;'>Vị trí</th>
                <th style='border: 1px solid #ddd; padding: 8px;'>Hạn bảo dưỡng</th>
                <th style='border: 1px solid #ddd; padding: 8px;'>Hạn thay mới</th>
            </tr>
          </thead>
          <tbody>`;
        item.data.forEach(data => {
            dataTable += `
            <tr>
                <td style='border: 1px solid #ddd; padding: 8px;'>${data.category} (mã: ${data.idItem})</td>
                <td style='border: 1px solid #ddd; padding: 8px;'>${data.warehouse} - ${data.area}</td>
                <td style='border: 1px solid #ddd; padding: 8px;'>${formatDate(data.maintanceDate)}</td>
                <td style='border: 1px solid #ddd; padding: 8px;'>${formatDate(data.renewDate)}</td>
            </tr>
            `;
        });
        dataTable += "</tbody></table>";
        let linkUrl = "http://127.0.0.1:5501/view/register/login.html?location=needMaintanceItem";
        let linkText = "Ấn vào link để xem chi tiết";
        dataTable += `<p><a href="${linkUrl}" style="color: blue;">${linkText}</a></p>`;

        let dataSend = {
            SystemName: "Hệ thống MIS",
            Subject: "Thông báo bảo trì thiết bị",
            EmailContent: dataTable,
            SendTo: [item.email],
            Cc: [item.email]
        };

        // Gọi hàm authenSendMail với await để chờ đợi hoàn thành
        await authenSendMail(dataSend);
    }
}




async function sendEmailDangKiemItems(processedData) {
    // Vòng lặp forEach để duyệt qua từng item trong processedData
    for (let item of processedData) {
        let dataTable = "<table style='border-collapse: collapse; width: 100%;'>";
        dataTable +=
            `<thead>
            <tr>
                <th style='border: 1px solid #ddd; padding: 8px;'>Thiết bị</th>
                <th style='border: 1px solid #ddd; padding: 8px;'>Vị trí</th>
                <th style='border: 1px solid #ddd; padding: 8px;'>Hạn đăng kiểm</th>
            </tr>
          </thead>
          <tbody>`;
        item.data.forEach(data => {
            dataTable += `
            <tr>
                <td style='border: 1px solid #ddd; padding: 8px;'>${data.category} (mã: ${data.idItem})</td>
                <td style='border: 1px solid #ddd; padding: 8px;'>${data.warehouse} - ${data.area}</td>
                <td style='border: 1px solid #ddd; padding: 8px;'>${formatDate(data.dangKiem)}</td>
            </tr>
            `;
        });
        dataTable += "</tbody></table>";

        let dataSend = {
            SystemName: "Hệ thống MIS",
            Subject: "Thông báo đăng kiểm thiết bị",
            EmailContent: dataTable,
            SendTo: [item.email],
            Cc: [item.email]
        };

        // Gọi hàm authenSendMail với await để chờ đợi hoàn thành
        await authenSendMail(dataSend);
    }
}



//gửi mail yêu cầu manager trả lời yêu cầu thêm thiết bị mới
async function sendEmailAnswerAddNewItem(managerEmail) {

    let data = "<h3>Còn đơn yêu cầu nhập thiết bị mới chưa trả lời</h3>";
    let linkUrl = "http://127.0.0.1:5501/view/register/login.html?location=addNewItemRequest";
    let linkText = "Ấn vào link để xem chi tiết";
    data += `<p><a href="${linkUrl}" style="color: blue;">${linkText}</a></p>`;
    let dataSend = {
        SystemName: "Hệ thống MIS",
        Subject: "Thông báo trả lời yêu cầu nhập thiết bị mới",
        EmailContent: dataTable,
        SendTo: [managerEmail],
        Cc: [managerEmail]
    };

    // Gọi hàm authenSendMail với await để chờ đợi hoàn thành
    await authenSendMail(dataSend);

}

//gửi email thông báo cho PIC khi có yêu cầu tranfer được trả lời
async function sendMailResultTranferRequestForPIC(infor, data) {
    let dataTable = `${infor.status} chuyển thiết bị từ ${infor.fromArea_warehouse_name} (${infor.fromArea_name}) sang ${infor.toArea_warehouse_name} (${infor.toArea_name})`;
    dataTable = "<table style='border-collapse: collapse; width: 100%;'>";
    dataTable +=
        `<thead>
            <tr>
                <th style='border: 1px solid #ddd; padding: 8px;'>Thiết bị</th>
              
            </tr>
          </thead>
          <tbody>`;
    data.forEach(data => {
        dataTable += `<tr>
            <td style='border: 1px solid #ddd; padding: 8px;'>${data.category_name} (id: ${data.idItem})</td>
                           </tr> `
    });

    dataTable += "</tbody></table>";

    let dataSend1 = {
        SystemName: "Hệ thống MIS",
        Subject: `${infor.status} chuyển thiết bị từ ${infor.fromArea_warehouse_name} (${infor.fromArea_name}) sang ${infor.toArea_warehouse_name} (${infor.toArea_name})`,
        EmailContent: dataTable,
        SendTo: [infor.PIC_fromArea_email],
        Cc: [infor.PIC_fromArea_email]
    };

    let dataSend2 = {
        SystemName: "Hệ thống MIS",
        Subject: `${infor.status} chuyển thiết bị từ ${infor.fromArea_warehouse_name} (${infor.fromArea_name}) sang ${infor.toArea_warehouse_name} (${infor.toArea_name})`,
        EmailContent: dataTable,
        SendTo: [infor.PIC_toArea_email],
        Cc: [infor.PIC_toArea_email]
    };

    await authenSendMail(dataSend1);
    await authenSendMail(dataSend2);
    console.log("send mail success");

}

// gửi mail thông báo trả lời yêu cầu nhập thiết bị mới
async function sendRegisterNewDeviceForManager(data, managerEmail) {
    dataTable = "<table style='border-collapse: collapse; width: 100%;'>";
    dataTable +=
        `<thead>
            <tr>
                <th style='border: 1px solid #ddd; padding: 8px;'>Thiết bị</th>
                <th style='border: 1px solid #ddd; padding: 8px;'>Số lượng</th>
                <th style='border: 1px solid #ddd; padding: 8px;'>Chu kì bảo dưỡng</th>
                <th style='border: 1px solid #ddd; padding: 8px;'>Chu kì thay mới</th>

            </tr>
          </thead>
          <tbody>`;
    data.forEach(data => {

        dataTable += `<tr>
                              <td style='border: 1px solid #ddd; padding: 8px;'>${data.category_name == null ? data.name : data.category_name}</td>
                              <td style='border: 1px solid #ddd; padding: 8px;'>${data.num}</td>
                              <td style='border: 1px solid #ddd; padding: 8px;'>${data.maintanceCycle}</td> 
                              <td style='border: 1px solid #ddd; padding: 8px;'>${data.renewCycle}</td>
                           </tr> `
    });

    dataTable += "</tbody></table>";
    let linkUrl = "http://127.0.0.1:5501/view/register/login.html?location=answerNewDeviceRequest";
    let linkText = "Ấn vào link để xem chi tiết";
    dataTable += `<p><a href="${linkUrl}" style="color: blue;">${linkText}</a></p>`;

    let dataSend1 = {
        SystemName: "Hệ thống MIS",
        Subject: "Thông báo kết quả yêu cầu thêm thiết bị",
        EmailContent: dataTable,
        SendTo: [managerEmail],
        Cc: [managerEmail]
    };



    await authenSendMail(dataSend1);

}




async function sendEmailForPICAboutNewItem(data) {
    let inforPIC = data.inforPIC;
    let dataItem = data.data;
    dataTable = `<h2>Thông báo bàn giao thiết bị mới đến ${inforPIC.warehouseName} (${inforPIC.areaName})</h2>`
    dataTable += "<table style='border-collapse: collapse; width: 100%;'>";
    dataTable +=
        `<thead>
            <tr>
                <th style='border: 1px solid #ddd; padding: 8px;'>Thiết bị</th>
                <th style='border: 1px solid #ddd; padding: 8px;'>Số lượng</th>
            </tr>
          </thead>
          <tbody>`;
    dataItem.forEach(data => {

        dataTable += `<tr>
                              <td style='border: 1px solid #ddd; padding: 8px;'>${data.categoryName}</td>
                              <td style='border: 1px solid #ddd; padding: 8px;'>${data.quantity}</td>
                           </tr> `
    });

    dataTable += "</tbody></table>";


    let dataSend = {
        SystemName: "Hệ thống MIS",
        Subject: "Thông báo kết quả bàn giao thiết bị mới",
        EmailContent: dataTable,
        SendTo: [inforPIC.email],
        Cc: [inforPIC.email]
    };
    await authenSendMail(dataSend);
}



function formatDate(dateString) {
    const date = new Date(dateString);
    let day = date.getDate().toString().padStart(2, '0');
    let month = (date.getMonth() + 1).toString().padStart(2, '0'); // January is 0!
    let year = date.getFullYear();
    return `${day}/${month}/${year}`;
}

// setInterval(getInfor, 1000 * 5 * 60);

module.exports = {sendEmailDangKiemItems, sendEmailAnswerAddNewItem, sendEmailForPICAboutNewItem, sendRegisterNewDeviceForManager, authenSendMail, sendEmailMaintanceItems, sendEmailRequestMaintaceItem, sendMailResultTranferRequestForPIC };
