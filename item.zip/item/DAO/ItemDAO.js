
//lấy ra các item + filter
function getAllItem(page, pageSize, filter, advanFilter) {
    if (filter !== "filter") {
        advanFilter = "";
    }
    console.log("querry: " + advanFilter)
    $.ajax({
        url: `http://localhost:3000/getAllItem?page=${page}&pageSize=${pageSize}&filter=${filter}&advanFilter=${advanFilter}`,
        type: 'GET',
        async: false,
    })
        .done(function (items) {
            console.log(items)
            $('#table-body').empty(); // Xóa hết nội dung của tbody trước khi thêm dữ liệu mới
            items.forEach(function (item) {
                let imageURL = "";
                let statusColor = ''; // Màu sắc mặc định
                if (item.status === 'Hoạt động') {
                    statusColor = 'green'; // Màu xanh
                } else if (item.status === 'Đang bảo dưỡng') {
                    statusColor = 'rgb(1,115,208)'; // Màu vàng
                } else if (item.status === 'Đang sửa') {
                    statusColor = 'red'; // Màu đỏ
                } else if (item.status === "Dự phòng") {
                    statusColor = "rgb(124,124,124)";
                }
                if (item.image !== null) {
                    let input = item.image.replace(/[^A-Fa-f0-9]/g, "");
                    let binary = new Array();
                    for (let i = 0; i < input.length / 2; i++) {
                        let h = input.substr(i * 2, 2);
                        binary[i] = parseInt(h, 16);
                    }
                    let byteArray = new Uint8Array(binary);
                    imageURL = window.URL.createObjectURL(new Blob([byteArray], { type: 'application/octet-stream' }));
                }
                let dataTable = `<tr>
                    <td style="max-width: 250px; word-wrap: break-word;">${item.category} (id: ${item.idItem})</td>
                    <td>${item.warehouse}, ${item.area}</td>
                    <td><img src="${imageURL}" alt="Ảnh thiết bị" style="width: 100px;"></td>
                    <td style="color: ${statusColor};">${item.status}</td>
                    <td>${item.activedDate == null ? "" : formatDate(item.activedDate)}</td>
                    <td>${(item.maintanceDate == null ? "" : (item.maintanceDate < '2100-04-06T00:00:00.000Z' ? formatDate(item.maintanceDate) : "Không có hạn"))} ${item.dangKiem != null ? `,<br> ${formatDate(item.dangKiem)}` : ""}</td>
                    <td>${item.renewDate == null ? "" : item.renewDate < "2100-04-06T00:00:00.000Z" ? formatDate(item.renewDate) : "Không có hạn"}</td>
                    <td><button class="more-info" data-id="${item.idItem}">Chi tiết</button></td>`;

                if (((acc.PICorStaff == 1 && acc.id == item.idPICWarehouse) || acc.PICorStaff == 2)) {
                    if (item.status == "Dự phòng") {
                        dataTable += `<td><button class="activeI" data-id="${item.activedDate == null ? item.idItem + " 0" : item.idItem + " 1"}">Kích hoạt</button></td>`;
                    } else {
                        dataTable += `<td><button class="deactive" data-id="${item.idItem}">Chuyển sang dự phòng</button></td>`;
                    }
                }
                dataTable += `</tr>`;
                $('#table-body').append(dataTable);
            });
            renderPagination(Math.ceil(getNumItem(filter, advanFilter) / pageSize));
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
}






//lấy ra số lượng item

function getNumItem(filter, advanFilter) {
    let x;
    $.ajax({
        url: `http://localhost:3000/getNumItem?filter=${filter}&advanFilter=${advanFilter}`,
        type: 'GET',
        async: false
    }).done(function (num) {
        x = num.count;

    })
        .fail(function (jqXHR, textStatus, errorThrown) {
            reject("Error fetching items: " + textStatus);
        });
    return x;
}

// lấy ra tất cả các category rồi đổ vào combobox filter
function getAllCategory() {
    $.ajax({
        url: `http://localhost:3000/getAllCategory`,
        type: 'GET',
        async: false
    }).done(function (categories) {
        const selectElement = document.getElementById('category');
        categories.forEach(category => {
            const option = document.createElement('option');
            option.value = category.idCategory;
            option.textContent = category.name;
            selectElement.appendChild(option);
        });
    })
        .fail(function (jqXHR, textStatus, errorThrown) {
            reject("Error fetching items: " + textStatus);
        });
}

//lấy ra tất cả các status rồi đổ vào combobox filter
function getAllStatus() {
    $.ajax({
        url: `http://localhost:3000/getAllStatus `,
        type: 'GET',
        async: false
    }).done(function (status) {
        const selectElement = document.getElementById('status');
        status.forEach(sta => {
            const option = document.createElement('option');
            option.value = sta.status;
            option.textContent = sta.status;
            selectElement.appendChild(option);
        });
    })
        .fail(function (jqXHR, textStatus, errorThrown) {
            reject("Error fetching items: " + textStatus);
        });
}

//lấy ra tất cả các kho rồi đổ vào combobox filter
function getAllWarehouse() {
    $.ajax({
        url: `http://localhost:3000/getAllWarehouse`,
        type: 'GET',
        async: false
    }).done(function (warehouses) {
        const selectElement = document.getElementById('Warehouse');


        warehouses.forEach(warehouse => {
            const option = document.createElement('option');
            option.value = warehouse.idWarehouse;
            option.textContent = warehouse.name;
            selectElement.appendChild(option);
        });
    })
        .fail(function (jqXHR, textStatus, errorThrown) {
            reject("Error fetching items: " + textStatus);
        });
}

function getAllPIC() {
    let rs;
    $.ajax({
        url: `http://localhost:3000/getAllPICAcc`,
        type: 'GET',
        async: false,
    })
        .done(function (accs) {
            rs = accs;
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
    return rs;
}

function getWarehouseAndPICName() {
    $.ajax({
        url: `http://localhost:3000/getWarehouseAndPICName`,
        type: 'GET',
        async: false
    }).done(function (warehouses) {
        let PICAccs = getAllPIC();
        warehouses.forEach(warehouse => {
            let combobox = "<select>";
            PICAccs.forEach(PICAcc => {
                let selected = (PICAcc.idPIC == warehouse.idPIC) ? "selected" : "";
                combobox += `<option value="${PICAcc.idPIC}" ${selected}>${PICAcc.name}</option>`;
            });
            combobox += "</select>";

            let areas = getAreaByIdWarehouse(warehouse.idWarehouse);
            let areasHtml = areas.map(area => `<input class="area-input" value='${area.name}' id='${area.idArea}'>`).join(', ');

            let dataTable = `
                <tr style="background-color: rgb(182,202,131);">
                    <td style="max-width: 250px; word-wrap: break-word;">${warehouse.idWarehouse}</td>
                    <td><input type='text' value='${warehouse.name}' style="background-color: rgb(183,212,212); width: 50%;"></td>
                    <td>${combobox}</td>
                    <td><button 
                         style='background-color: rgb(81, 117, 124);
                         color: white;
                         border: none;
                         padding: 4px 8px;
                         text-align: center;
                         text-decoration: none;
                         display: inline-block;
                         font-size: 12px;
                         margin: 4px 2px;
                         cursor: pointer;
                         border-radius: 5px;
                         transition: background-color 0.3s ease;' 
                    data-id='${warehouse.idWarehouse}' class='update'>Cập nhật</button></td>
                </tr>
                <tr>
                    <td colspan="4">
                        ${areasHtml}
                    </td>
                </tr>`;

            $('#table-body').append(dataTable);
        });

        let combobox = "<select>";
        PICAccs.forEach(PICAcc => {
            combobox += `<option value="${PICAcc.idPIC}">${PICAcc.name}</option>`;
        });
        combobox += "</select>";

        let comboboxWarehouse = "<select>";
        warehouses.forEach(warehouse => {
            comboboxWarehouse += `<option value="${warehouse.idWarehouse}">${warehouse.name}</option>`;
        });
        comboboxWarehouse += "</select>";

        let newRow = `
                <tr style="background-color: rgb(196,199,198);">
                    <td>Tạo kho mới</td>
                    <td><input type="text" value=''></td>
                    <td>${combobox}</td>
                    <td>
                        <button class="add" id="add">Tạo kho mới</button>
                    </td>
                </tr>
                  <tr style="background-color: rgb(170,160,195);">
                    <td>Tạo khu mới</td>
                    <td><input type="text" value=''></td>
                    <td>${comboboxWarehouse}</td>
                    <td>
                        <button class="add-area" id="add-area" style="background-color: rgb(232,168,76);">Tạo khu mới</button>
                    </td>
                </tr>
                `;
        $('#table-body').append(newRow);

    }).fail(function (jqXHR, textStatus, errorThrown) {
        console.error("Error fetching items: " + textStatus);
    });
}

function getAreaByIdWarehouse(idWarehouse) {
    let rs = [];
    $.ajax({
        url: `http://localhost:3000/getAllAreaByIdWarehouse?idWarehouse=${idWarehouse}`,
        type: 'GET',
        async: false // Ensuring synchronous request to get data before proceeding
    }).done(function (areas) {
        rs = areas;
    }).fail(function (jqXHR, textStatus, errorThrown) {
        console.error('Error fetching items: ' + textStatus);
    });
    return rs;
}


//lây ra tất cả các khu theo kho rồi đổ vào combobox filter
function getAllRegionByWarehouse(idWarehouse) {
    const selectElement = document.getElementById('region');
    // Xóa tất cả các option trừ option có giá trị là "all"
    while (selectElement.firstChild) {
        if (selectElement.firstChild.value !== 'all') {
            selectElement.removeChild(selectElement.firstChild);
        } else {
            break; // Dừng nếu gặp option có value là 'all'
        }
    }
    // Gọi API để lấy danh sách các region
    $.ajax({
        url: `http://localhost:3000/getAllRegionByWarehouse?idWarehouse=${idWarehouse}`,
        type: 'GET',
        async: false
    }).done(function (regions) {
        regions.forEach(region => {
            const option = document.createElement('option');
            option.value = region.idArea;
            option.textContent = region.name;
            selectElement.appendChild(option);
        });
    }).fail(function (jqXHR, textStatus, errorThrown) {
        console.error("Error fetching regions:", textStatus);
    });
}

// lấy loại của item theo id
function getCategoryByItemId(idItem) {
    let category;
    $.ajax({
        url: `http://localhost:3000/getCategoryByItemId?idItem=${idItem}`,
        type: 'GET',
        async: false
    }).done(function (categories) {
        category = categories[0].categoryName;
    }).fail(function (jqXHR, textStatus, errorThrown) {
        console.error("Error fetching regions:", textStatus);
    });
    console.log(category)
    return category;
}


function getAllWarehouseforRequest() {
    $.ajax({
        url: 'http://localhost:3000/getAllWarehouse',
        type: 'GET',
    })
        .done(function (warehouses) {
            warehouses.forEach(function (warehouse) {

                const newButton = document.createElement('button');
                newButton.className = 'warehouse-btn';
                newButton.textContent = warehouse.name;
                newButton.value = warehouse.idPIC;
                newButton.onclick = function () {
                    warehouseClick(newButton);
                };
                const warehouseGroup = document.querySelector('.warehouse-group');
                warehouseGroup.appendChild(newButton);
            });
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error('Error fetching items: ' + textStatus);
        });
}

function getAllAreaByIdWarehouse(idWarehouse) {
    $.ajax({
        url: `http://localhost:3000/getAllAreaByIdWarehouse?idWarehouse=${idWarehouse}`,
        type: 'GET',
    })
        .done(function (areas) {
            areas.forEach(function (area) {
                const newButton = document.createElement('button');
                newButton.className = 'area-btn';
                newButton.textContent = area.name;
                newButton.value = area.idArea;
                newButton.onclick = function () {
                    areaClick(newButton);
                };
                const warehouseGroup = document.querySelector('.area-group');
                warehouseGroup.appendChild(newButton);
            });
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error('Error fetching items: ' + textStatus);
        });
}






function getItemByAreaId(idArea) {
    $.ajax({
        url: `http://localhost:3000/getItemByAreaId?idArea=${idArea}`,
        type: 'GET',
    })
        .done(function (items) {
            $('#table-body').empty(); // Xóa hết nội dung của tbody trước khi thêm dữ liệu mới
            items.forEach(function (item) {
                let imageURL = "";
                let statusColor = ''; // Màu sắc mặc định
                if (item.status === 'Hoạt động') {
                    statusColor = 'green'; // Màu xanh
                } else if (item.status === 'Đang bảo dưỡng') {
                    statusColor = 'rgb(1,115,208)'; // Màu vàng
                } else if (item.status === 'Đang sửa') {
                    statusColor = 'red'; // Màu đỏ
                }
                if (item.image !== null) {
                    let input = item.image.replace(/[^A-Fa-f0-9]/g, "");
                    let binary = new Array();
                    for (let i = 0; i < input.length / 2; i++) {
                        let h = input.substr(i * 2, 2);
                        binary[i] = parseInt(h, 16);
                    }
                    let byteArray = new Uint8Array(binary);
                    imageURL = window.URL.createObjectURL(new Blob([byteArray], { type: 'application/octet-stream' }));
                }
                $('#table-body').append(`
                <tr>
                    <td>${item.idItem}</td>
                    <td>${item.category}</td>
                    <td><img src="${imageURL}" alt="Ảnh thiết bị" style="width: 100px;"></td>
                    <td style="color: ${statusColor};">${item.status}</td>
                    <td>${formatDate(item.activedDate)}</td>
            
                    <td><input type="checkbox" class="item-checkbox" data-id="${item.idItem}"></td>
                </tr>
        `);
            });

        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error('Error fetching items: ' + textStatus);
        });
}


function getNeedToMaintanceItem(idPIC) {
    $.ajax({
        url: `http://localhost:3000/getMaintanceitemByPIC?idPIC=${idPIC}`,
        type: 'GET',
    })
        .done(function (items) {
            $('#table-body').empty(); // Xóa hết nội dung của tbody trước khi thêm dữ liệu mới
            items.forEach(function (item) {
                let imageURL = "";
                let statusColor = ''; // Màu sắc mặc định

                if (item.status === 'Hoạt động') {
                    statusColor = 'green'; // Màu xanh
                } else if (item.status === 'Đang bảo dưỡng') {
                    statusColor = 'rgb(1,115,208)'; // Màu vàng
                } else if (item.status === 'Đang sửa') {
                    statusColor = 'red'; // Màu đỏ
                }
                if (item.image !== null) {
                    let input = item.image.replace(/[^A-Fa-f0-9]/g, "");
                    let binary = new Array();
                    for (let i = 0; i < input.length / 2; i++) {
                        let h = input.substr(i * 2, 2);
                        binary[i] = parseInt(h, 16);
                    }
                    let byteArray = new Uint8Array(binary);
                    imageURL = window.URL.createObjectURL(new Blob([byteArray], { type: 'application/octet-stream' }));
                }
                $('#table-body').append(`
            <tr>
                <td>${item.category} (id: ${item.idItem})</td>
                <td>${item.warehouse} (${item.area})</td>
                <td><img src="${imageURL}" alt="Ảnh thiết bị" style="width: 100px;"></td>
                <td style="color: ${statusColor};">${item.status}</td>
                    <td>${(item.maintanceDate == null ? "" : (item.maintanceDate < '2100-04-06T00:00:00.000Z' ? formatDate(item.maintanceDate) : "Không có hạn"))} ${item.dangKiem != null ? `,<br> ${item.dangKiem}` : ""}</td>
                <td>${formatDate(item.renewDate)}</td>
                <td><button class="more-info" data-id="${item.idItem}">Tạo đơn</button></td>
            </tr>
        `);
            });

        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error('Error fetching items: ' + textStatus);
        });
}

// lấy ra các register item request
function getAllRegisterRequests(page, pageSize, filter) {
    $.ajax({
        url: `http://localhost:3000/getALlRegisterRequests?page=${page}&pageSize=${pageSize}&filter=${filter}`,
        type: 'GET',
    })
        .done(function (items) {
            console.log(getNumAllRegisterRequests(filter))
            renderPagination(Math.ceil(getNumAllRegisterRequests(filter) / pageSize));
            $('#table-body').empty(); // Xóa hết nội dung của tbody trước khi thêm dữ liệu mới
            items.forEach(function (item) {
                $('#table-body').append(`
            <tr>
                <td>${item.idRegisterDeviceRequest}</td>
                <td>${formatDate(item.date)}</td>
                <td>${item.status}</td>
                <td><button class="more-info" data-id="${item.idRegisterDeviceRequest}">Chi tiết</button></td>
            </tr>
        `);
            });

        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error('Error fetching items: ' + textStatus);
        });
}

// lấy ra các số register item request
function getNumAllRegisterRequests(filter) {
    let rs;
    $.ajax({
        url: `http://localhost:3000/getNumAllRegisterRequests?filter=${filter}`,
        type: 'GET',
        async: false,
    })
        .done(function (num) {
            rs = num

        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error('Error fetching items: ' + textStatus);
        });
    return rs;
}


function getNewItem() {
    $.ajax({
        url: `http://localhost:3000/getNewItem`,
        type: 'GET',
        async: false,
    })
        .done(function (items) {
            $('#table-body').empty(); // Xóa hết nội dung của tbody trước khi thêm dữ liệu mới
            items.forEach(function (item) {
                let imageURL = "";
                if (item.image !== null) {
                    let input = item.image.replace(/[^A-Fa-f0-9]/g, "");
                    let binary = new Array();
                    for (let i = 0; i < input.length / 2; i++) {
                        let h = input.substr(i * 2, 2);
                        binary[i] = parseInt(h, 16);
                    }
                    let byteArray = new Uint8Array(binary);
                    imageURL = window.URL.createObjectURL(new Blob([byteArray], { type: 'application/octet-stream' }));
                }
                $('#table-body').append(`
                    <tr>
                        <td>${item.categoryName} (sl: ${item.itemCount})</td>
                        <td><img src="${imageURL}" alt="Ảnh thiết bị" style="width: 150px;"></td>
                        <td>
                            <input type="number" value="1" class="quantity-input" name="quantity" min="1" max="${item.itemCount}">
                            <p class="error-msg" style="color: red;"></p>
                        </td>
                        <td><input type="checkbox" class="choose" data-id="${item.idCategory}"></td>
                    </tr>
                `);
            });
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
}


//post cập nhật chuyển giao thiết bị vô chủ cho PIC
function postUpdateItemPosition(data, dataSentMail) {
    let data1 = getItemNeedToUpdatePosition(data.da);
    $.ajax({
        url: `http://localhost:3000/postUpdateItemPosition`,
        type: 'POST',
        async: false,
        contentType: 'application/json',
        data: JSON.stringify({
            idArea: data.idArea,
            idItems: data1
        })
    }).done(function (result) {
        alert("Chuyển giao thành công");
        sendEmailForPICAboutNewItem(dataSentMail);
    })
        .fail(function (jqXHR, textStatus, errorThrown) {
            alert("Có lỗi xảy ra ở postUpdateItemPosition");
            console.error("Error fetching items: " + textStatus);
        });;
}


function postUpdateMaintanceItemDate(itemId, status) {
    $.ajax({
        url: `http://localhost:3000/postUpdateItemMaintanceDate`,
        type: 'POST',
        async: false,
        contentType: 'application/json',
        data: JSON.stringify({
            itemId: itemId,
            status: status
        })
    }).done(function (result) {
        alert("Cập nhật thành công");
    })
        .fail(function (jqXHR, textStatus, errorThrown) {
            alert("Có lỗi xảy ra ở postUpdateItemPosition");
            console.error("Error fetching items: " + textStatus);
        });;
}



// cập nhật trạng thái thiết bị
function postUpdateItemStatus(idItem, status, activedOrNot) {
    $.ajax({
        url: `http://localhost:3000/postUpdateItemStatus`,
        type: 'POST',
        async: false,
        contentType: 'application/json',
        data: JSON.stringify({
            idItem: idItem,
            status: status,
            activedOrNot: activedOrNot
        })
    }).done(function (result) {
        alert("Xác nhận thành công");
    })
        .fail(function (jqXHR, textStatus, errorThrown) {
            alert("Có lỗi xảy ra");
            console.error("Error fetching items: " + textStatus);
        });;
}



// hàm lấy ra  category name theo idCategory

function getCategoryByIdCategory(idCategory) {
    let rs
    $.ajax({
        url: `http://localhost:3000/getCategoryByIdCategory?idCategory=${idCategory}`,
        type: 'GET',
        async: false,
    })
        .done(function (result) {
            rs = result;
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error('Error fetching items: ' + textStatus);
        });
    return rs;
}

// lấy ra email, warehouse name của PIC theo idArea
function getPICEmailbyIdArea(idArea) {
    let rs
    $.ajax({
        url: `http://localhost:3000/getPICEmailbyIdArea?idArea=${idArea}`,
        type: 'get',
        async: false
    })
        .done(function (result) {
            rs = result;
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error('Error fetching items: ' + textStatus);
        });
    return rs;
}

// send email thông báo cho pic đã được nhận về thiết bị
function sendEmailForPICAboutNewItem(data) {
    $.ajax({
        url: `http://localhost:3000/sendEmailForPICAboutNewItem`,
        type: 'POST',
        async: false,
        contentType: 'application/json',
        data: JSON.stringify(data)
    })
        .done(function (result) {

        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error('Error fetching items: ' + textStatus);
        });
}



// lấy raz các item cần cập nhật vị trí
function getItemNeedToUpdatePosition(data) {
    let rs
    $.ajax({
        url: `http://localhost:3000/getItemNeedToUpdatePosition`,
        type: 'POST',
        async: false,
        contentType: 'application/json',
        data: JSON.stringify(data)
    })
        .done(function (result) {
            rs = result;
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error('Error fetching items: ' + textStatus);
        });
    return rs;
}


function postUpdateMaintanceDate(idItem) {

    $.ajax({
        url: `http://localhost:3000/postUpdateMaintanceDate?idItem=${idItem}`,
        type: 'POST',
        async: false
    })
        .done(function (result) {

        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error('Error fetching items: ' + textStatus);
        });

}


function getInforAllInforCategory(idCategory) {
    let rs
    $.ajax({
        url: `http://localhost:3000/getInforAllInforCategory?idCategory=${idCategory}`,
        type: 'get',
        async: false
    })
        .done(function (result) {
            rs = result[0];
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error('Error fetching items: ' + textStatus);
        });
    return rs;
}



function getDangKiemByIdItem(idItem) {
    let rs
    $.ajax({
        url: `http://localhost:3000/getDangKiemByIdItem?idItem=${idItem}`,
        type: 'get',
        async: false
    })
        .done(function (result) {
            rs = result[0].dangKiem;
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error('Error fetching items: ' + textStatus);
        });
    return rs;
}


function getAllCategoryToManage() {

    $.ajax({
        url: `http://localhost:3000/getAllCategoryToManage`,
        type: 'GET',
        async: false,
    })
        .done(function (items) {
            console.log(items)
            $('#table-body').empty(); // Xóa hết nội dung của tbody trước khi thêm dữ liệu mới
            items.forEach(function (item) {
                let imageURL = "";

                if (item.image !== null) {
                    let input = item.image.replace(/[^A-Fa-f0-9]/g, "");
                    let binary = new Array();
                    for (let i = 0; i < input.length / 2; i++) {
                        let h = input.substr(i * 2, 2);
                        binary[i] = parseInt(h, 16);
                    }
                    let byteArray = new Uint8Array(binary);
                    imageURL = window.URL.createObjectURL(new Blob([byteArray], { type: 'application/octet-stream' }));
                }
                let dataTable = `<tr>
                    <td style="max-width: 250px; word-wrap: break-word;">${item.name}</td>
                    <td><img src="${imageURL}" alt="Ảnh thiết bị" style="width: 100px;"></td>
                    <td><input value='${item.maintaneceCycle}' type="text"></td>
                    <td><input value='${item.duration}' type="text"</td>
                    <td><input value="${item.alertMaintance}" type='text'</td>
                    <td><input value="${item.alertRenew}" type='text'</td>
                    <td><button class="more-info" data-id="${item.idCategory}">Cập nhật</button></td>`;

                dataTable += `</tr>`;
                $('#table-body').append(dataTable);
            });
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
}


function updateItemInfor(idCategory, maintaneceCycle, duration, alertMaintance, alertRenew) {
    let data = {
        idCategory: idCategory,
        maintaneceCycle: maintaneceCycle,
        duration: duration,
        alertMaintance: alertMaintance,
        alertRenew: alertRenew
    }
    $.ajax({
        url: `http://localhost:3000/updateItemInfor`,
        type: 'POST',
        async: false,
        contentType: 'application/json',
        data: JSON.stringify(data)
    })
        .done(function (result) {
            alert("Cập nhật thành công");
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error('Error fetching items: ' + textStatus);
        });

}



function postUpdateDangKiem(itemId, dangKiem) {
    $.ajax({
        url: `http://localhost:3000/postUpdateDangKiem?idItem=${itemId}&dangKiem=${dangKiem}`,
        type: 'POST',
        async: false,

    })
        .done(function (result) {
            alert("Cập nhật thành công");
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error('Error fetching items: ' + textStatus);
        });

}




function assignPICtoWarehouse(warehouseId, selectedPIC, warehouseName) {
    $.ajax({
        url: `http://localhost:3000/assignPICtoWarehouse?idWarehouse=${warehouseId}&idPIC=${selectedPIC}&warehouseName=${warehouseName}`,
        type: 'POST',
        async: false,

    }).done(function (result) {
        alert("Cập nhật thành công");
    })
        .fail(function (jqXHR, textStatus, errorThrown) {
            alert("Có lỗi xảy ra ở postUpdateItemPosition");
            console.error("Error fetching items: " + textStatus);
        });;
}



function createNewWarehouse(nameWarehouse, idPIC){
    $.ajax({
        url: `http://localhost:3000/createNewWarehouse?nameWarehouse=${nameWarehouse}&idPIC=${idPIC}`,
        type: 'POST',
        async: false,

    })
        .done(function (result) {
            alert("Thêm kho mới thành công");
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error('Error fetching items: ' + textStatus);
        });

}



function createNewArea(nameArea, idWarehouse){
    $.ajax({
        url: `http://localhost:3000/createNewArea?nameArea=${nameArea}&idWarehouse=${idWarehouse}`,
        type: 'POST',
        async: false,

    })
        .done(function (result) {
            alert("Thêm Khu mới thành công");
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error('Error fetching items: ' + textStatus);
        });

}



function updateArea(dataArea) {
    $.ajax({
        url: `http://localhost:3000/updateArea`,
        type: 'POST',
        async: false,
        contentType: 'application/json',
        data: JSON.stringify(dataArea)
    }).done(function (result) {
    })
        .fail(function (jqXHR, textStatus, errorThrown) {
        
            console.error("Error fetching items: " + textStatus);
        });;
}



//định dạng ngày tháng
function formatDate(isoDateString) {
    const date = new Date(isoDateString);
    const day = date.getDate();
    const month = date.getMonth() + 1;
    const year = date.getFullYear();
    // Định dạng lại thành "dd/mm/yyyy"
    const formattedDate = `${day}/${month}/${year}`;

    return formattedDate;
}

