// check account của staff
function checkStaffAccount(username, password) {
    return new Promise(function (resolve, reject) {
        $.ajax({
            url: `http://localhost:3000/checkStaffAccount`,
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ username: username, password: password })
        }).done(function (datasql) {
            if (datasql.length < 1) {
                resolve(false); // Account not found
            } else {
                resolve({
                    id: datasql[0].idStaff,
                    code: datasql[0].username,
                    //PICorStaff:  lưu giá trị 0, 1, 2 để phần biệt staff, PIC, manager
                    PICorStaff: 0,
                    name: datasql[0].name,
                    email: datasql[0].email
                });
            }
        }).fail(function () {
            reject("Error checking staff account"); // Handle AJAX failure
        });
    });
}

function getStaff(id) {
    return new Promise(function (resolve, reject) {
        $.ajax({
            url: `http://localhost:3000/getStaff?id=${id}`,
            type: 'POST',
            contentType: 'application/json',
        }).done(function (datasql) {
            resolve({
                id: datasql[0].idStaff,
                code: datasql[0].username,
                //PICorStaff:  lưu giá trị 0, 1, 2 để phần biệt staff, PIC, manager
                PICorStaff: 0,
                name: datasql[0].name,
                email: datasql[0].email
            });
        }).fail(function () {
            reject("Error checking staff account"); // Handle AJAX failure
        });
    });

}



// Function to check PIC account asynchronously
function checkPICAccount(username, password) {
    return new Promise(function (resolve, reject) {
        $.ajax({
            url: `http://localhost:3000/checkPICAccount`,
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ username: username, password: password })
        }).done(function (datasql) {
            if (datasql.length < 1) {
                resolve(false); // Account not found
            } else {
                resolve({
                    id: datasql[0].idPIC,
                    code: datasql[0].username,
                    //PICorStaff:  lưu giá trị 0, 1, 2 để phần biệt staff, PIC, manager
                    PICorStaff: 1,
                    name: datasql[0].name,
                    accountantPIC: datasql[0].accountantPIC,
                    email: datasql[0].email
                });
            }
        }).fail(function () {
            reject("Error checking PIC account"); // Handle AJAX failure
        });
    });
}


function getPIC(id) {
    return new Promise(function (resolve, reject) {
        $.ajax({
            url: `http://localhost:3000/getPIC?id=${id}`,
            type: 'POST',
            contentType: 'application/json',
        }).done(function (datasql) {
            resolve({
                id: datasql[0].idPIC,
                code: datasql[0].username,
                //PICorStaff:  lưu giá trị 0, 1, 2 để phần biệt staff, PIC, manager
                PICorStaff: 1,
                name: datasql[0].name,
                accountantPIC: datasql[0].accountantPIC,
                email: datasql[0].email
            });
        }).fail(function () {
            reject("Error checking staff account"); // Handle AJAX failure
        });
    });

}

// check account của manager
function checkManagerAccount(username, password) {
    return new Promise(function (resolve, reject) {
        $.ajax({
            url: `http://localhost:3000/checkManagerAccount`,
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ username: username, password: password })
        }).done(function (datasql) {
            if (datasql.length < 1) {
                resolve(false); // Account not found
            } else {
                resolve({
                    id: datasql[0].idManager,
                    code: datasql[0].username,
                    //PICorStaff:  lưu giá trị 0, 1, 2 để phần biệt staff, PIC, manager
                    PICorStaff: 2,
                    name: datasql[0].name,
                    admin: datasql[0].admin,
                    email: datasql[0].email,
                });
            }
        }).fail(function () {
            reject("Error checking manager account"); // Handle AJAX failure
        });
    });
}


function getManager(id) {
    return new Promise(function (resolve, reject) {
        $.ajax({
            url: `http://localhost:3000/getManager?id=${id}`,
            type: 'POST',
            contentType: 'application/json',
        }).done(function (datasql) {
            resolve({
                id: datasql[0].idManager,
                code: datasql[0].username,
                //PICorStaff:  lưu giá trị 0, 1, 2 để phần biệt staff, PIC, manager
                PICorStaff: 2,
                name: datasql[0].name,
                admin: datasql[0].admin,
                email: datasql[0].email,
            });
        }).fail(function () {
            reject("Error checking staff account"); // Handle AJAX failure
        });
    });

}


function getAllStaffAcc() {
    $.ajax({
        url: `http://localhost:3000/getAllStaffAcc`,
        type: 'GET',
        async: false,
    })
        .done(function (accs) {

            $('#table-body').empty(); // Xóa hết nội dung của tbody trước khi thêm dữ liệu mới
            accs.forEach(function (acc) {

                let dataTable = `<tr>
                    <td>${acc.idStaff}</td>
                    <td><input type="text" value='${acc.name}'></td>
                    <td><input type="text" value='${acc.username}' readonly></td>
                    <td><input type="text" value='${acc.password}'></td>
                    <td><input type="email" value='${acc.email}'></td>
                    <td><button class="update" data-id="${acc.idStaff}">Cập nhật</button>
                    <button class="delete" data-id="${acc.idStaff}">Xóa tài khoản</button></td></tr>`;

                $('#table-body').append(dataTable);
            });
            let newRow = `<tr>
                        <td></td>
                        <td><input type="text" value=''></td>
                        <td><input type="text" value=''></td>
                        <td><input type="text" value=''></td>
                        <td><input type="text" value=''></td>
                        <td><button class="add" id="add">Tạo tài khoản mới</button></
                    </tr>`;
            $('#table-body').append(newRow);
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
}


function deleteStaffAcc(idAcc) {
    $.ajax({
        url: `http://localhost:3000/deleteStaffAcc?id=${idAcc}`,
        type: 'DELETE',
        async: false,
    })
        .done(function (accs) {

            alert("Xóa thành công");
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
}


function updateStaffAcc(idAcc, username, password, name, email) {
    $.ajax({
        url: `http://localhost:3000/updateStaffAcc`,
        type: 'POST',
        async: false,
        contentType: 'application/json',
        data: JSON.stringify({ id: idAcc, username: username, password: password, name: name, email: email })
    })
        .done(function (accs) {

            alert("Cập nhật thành công");
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
}


function checkStaffAccExist(username) {
    let rs = false;
    $.ajax({
        url: `http://localhost:3000/checkStaffAccExist?username=${username}`,
        type: 'GET',
        async: false,

    })
        .done(function (count) {
            if (count[0].count > 0) {
                rs = true;
            }
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
    return rs;
}


function checkPICAccExist(username) {
    let rs = false;
    $.ajax({
        url: `http://localhost:3000/checkPICAccExist?username=${username}`,
        type: 'GET',
        async: false,

    })
        .done(function (count) {
            if (count[0].count > 0) {
                rs = true;
            }
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
    return rs;
}


function checkManagerAccExist(username) {
    let rs = false;
    $.ajax({
        url: `http://localhost:3000/checkManagerAccExist?username=${username}`,
        type: 'GET',
        async: false,

    })
        .done(function (count) {
            if (count[0].count > 0) {
                rs = true;
            }
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
    return rs;
}


function createNewStaffAcc(username, password, name) {
    $.ajax({
        url: `http://localhost:3000/createNewStaffAcc`,
        type: 'POST',
        async: false,
        contentType: 'application/json',
        data: JSON.stringify({ username: username, password: password, name: name })
    })
        .done(function (accs) {

            alert("Tạo tài khoản mới thành công");
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
}


function getAllPICAcc() {
    $.ajax({
        url: `http://localhost:3000/getAllPICAcc`,
        type: 'GET',
        async: false,
    })
        .done(function (accs) {

            $('#table-body').empty(); // Xóa hết nội dung của tbody trước khi thêm dữ liệu mới
            accs.forEach(function (acc) {

                let dataTable = `
                <tr>
                    <td>${acc.idPIC}</td>
                    <td><input type="text" value='${acc.name}'></td>
                    <td><input type="text" value='${acc.username}' readonly></td>
                    <td><input type="text" value='${acc.password}'></td>
                    <td><input type="text" value='${acc.email}'></td>
                    <td><input type="radio" name="accountant" value='${acc.idPIC}' ${acc.accountantPIC == 1 ? "checked" : ""}></td>
                   
                    <td>
                        <button class="update" data-id="${acc.idPIC}">Cập nhật</button>
                        <button class="delete" data-id="${acc.idPIC}">Xóa tài khoản</button>
                    </td>
                </tr>`;

                $('#table-body').append(dataTable);
            });
            let newRow = `
                    <tr>
                        <td></td>
                        <td><input type="text" value=''></td>
                        <td><input type="text" value=''></td>
                        <td><input type="text" value=''></td>
                        <td><input type="text" value=''></td>
                        <td></td>
                        <td>
                            <button class="add" id="add">Tạo tài khoản mới</button>
                        </td>
                    </tr>`;
            $('#table-body').append(newRow);
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });


}


function updateAccountantPIC(id) {
    $.ajax({
        url: `http://localhost:3000/updateAccountantPIC?id=${id}`,
        type: 'POST',
        async: false,
    })
        .done(function (accs) {

            alert("Cập nhật thành công");
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
}



function createNewPICAcc(username, password, name, email) {
    $.ajax({
        url: `http://localhost:3000/createNewPICAcc`,
        type: 'POST',
        async: false,
        contentType: 'application/json',
        data: JSON.stringify({ username: username, password: password, name: name, email: email })
    })
        .done(function (accs) {

            alert("Tạo tài khoản mới thành công");
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
}


function deletePICAcc(idAcc) {
    $.ajax({
        url: `http://localhost:3000/deletePICAcc?id=${idAcc}`,
        type: 'DELETE',
        async: false,
    })
        .done(function (accs) {

            alert("Xóa thành công");
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
}


function updatePICAcc(idAcc, username, password, name, email) {
    $.ajax({
        url: `http://localhost:3000/updatePICAcc`,
        type: 'POST',
        async: false,
        contentType: 'application/json',
        data: JSON.stringify({ id: idAcc, username: username, password: password, name: name, email: email })
    })
        .done(function (accs) {

            alert("Cập nhật thành công");
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
}




function getAllManagerAcc() {
    $.ajax({
        url: `http://localhost:3000/getAllManagerAcc`,
        type: 'GET',
        async: false,
    })
        .done(function (accs) {

            $('#table-body').empty(); // Xóa hết nội dung của tbody trước khi thêm dữ liệu mới
            accs.forEach(function (acc) {

                let dataTable = `<tr>
                    <td>${acc.idManager}</td>
                    <td><input type="text" value='${acc.name}'></td>
                    <td><input type="text" value='${acc.username}' readonly></td>
                    <td><input type="text" value='${acc.password}'></td>
                    <td><input type="text" value='${acc.email}'></td>
                    <td><input type="radio" name="acti" value='${acc.idManager}' ${acc.active == 1 ? "checked" : ""}></td>
                    <td><button class="update" data-id="${acc.idManager}">Cập nhật</button>
                    <button class="delete" data-id="${acc.idManager}">Xóa tài khoản</button></td></tr>`;

                $('#table-body').append(dataTable);
            });
            let newRow = `<tr>
                        <td></td>
                        <td><input type="text" value=''></td>
                        <td><input type="text" value=''></td>
                        <td><input type="text" value=''></td>
                        <td><input type="text" value=''></td>
                        <td></td>
                        <td><button class="add" id="add">Tạo tài khoản mới</button></
                    </tr>`;
            $('#table-body').append(newRow);
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });


}


function createNewManagerAcc(username, password, name, email) {
    $.ajax({
        url: `http://localhost:3000/createNewManagerAcc`,
        type: 'POST',
        async: false,
        contentType: 'application/json',
        data: JSON.stringify({ username: username, password: password, name: name, email: email })
    })
        .done(function (accs) {

            alert("Tạo tài khoản mới thành công");
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
}


function deleteManagerAcc(idAcc) {
    $.ajax({
        url: `http://localhost:3000/deleteManagerAcc?id=${idAcc}`,
        type: 'DELETE',
        async: false,
    })
        .done(function (accs) {

            alert("Xóa thành công");
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
}


function updateManagerAcc(idAcc, username, password, name, email) {
    $.ajax({
        url: `http://localhost:3000/updateManagerAcc`,
        type: 'POST',
        async: false,
        contentType: 'application/json',
        data: JSON.stringify({ id: idAcc, username: username, password: password, name: name, email: email })
    })
        .done(function (accs) {

            alert("Cập nhật thành công");
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
}


function updateActiveManager(id) {
    $.ajax({
        url: `http://localhost:3000/updateActiveManager?id=${id}`,
        type: 'POST',
        async: false,
    })
        .done(function (accs) {

            alert("Cập nhật thành công");
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
}


function getStaffPassword(id) {
    let r;
    $.ajax({
        url: `http://localhost:3000/getStaffPassword?id=${id}`,
        type: 'POST',
        async: false,
    })
        .done(function (rs) {
            r = rs
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
    return r;
}


function getPICPassword(id) {
    let r;
    $.ajax({
        url: `http://localhost:3000/getPICPassword?id=${id}`,
        type: 'POST',
        async: false,
    })
        .done(function (rs) {
            r = rs
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
    return r;
}


function getManagerPassword(id) {
    let r;
    $.ajax({
        url: `http://localhost:3000/getManagerPassword?id=${id}`,
        type: 'POST',
        async: false,
    })
        .done(function (rs) {
            r = rs
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
    return r;
}


