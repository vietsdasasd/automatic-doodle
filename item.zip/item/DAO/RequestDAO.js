

//upload yêu cầu bàn giao
function postTranferRequest(PIC_request, status, reason, fromArea, toArea) {
    let id;
    $.ajax({
        url: `http://localhost:3000/postTranferRequest?PIC_request=${PIC_request}&status=${status}&reason=${reason}&fromArea=${fromArea}&toArea=${toArea}`,
        type: 'POST',
        async: false,
    }).done(function (rs) {
        id = rs.id;
        alert("gửi yêu cầu thành công")
    })
        .fail(function (jqXHR, textStatus, errorThrown) {
            alert("Có lỗi xảy ra");
            console.error("Error fetching items: " + textStatus);
        });;
        return id;
}


//upload yêu cầu bàn giao cho role manager
function postTranferRequestManager(status, reason, fromArea, toArea) {
    let id;
    $.ajax({
        url: `http://localhost:3000/postTranferRequestManager?status=${status}&reason=${reason}&fromArea=${fromArea}&toArea=${toArea}`,
        type: 'POST',
        async: false,
    }).done(function (rs) {
        id = rs.id;
        alert("gửi yêu cầu thành công")
    })
        .fail(function (jqXHR, textStatus, errorThrown) {
            alert("Có lỗi xảy ra");
            console.error("Error fetching items: " + textStatus);
        });;
        return id;
}

//upload chi tiết yêu cầu bàn giao
function postTranferRequestDetail(listItemid, tranferRequestId) {
    $.ajax({
        url: `http://localhost:3000/postTranferRequestDetail?tranferRequestId=${tranferRequestId}`,
        type: 'POST',
        async: false,
        contentType: 'application/json',
        data: JSON.stringify(listItemid)
    }).done(function () {


    })
        .fail(function (jqXHR, textStatus, errorThrown) {
            alert("Có lỗi xảy ra");
            console.error("Error fetching items: " + textStatus);
        });;
}

//chấp nhận yêu cầu bàn giao
function postAcceptTranferRequest(tranferRequestId) {
    $.ajax({
        url: `http://localhost:3000/postAcceptTranferRequest?tranferRequestId=${tranferRequestId}`,
        type: 'POST',
        async: false
    }).done(function () {

        alert("Yêu cầu được chấp nhận")
    })
        .fail(function (jqXHR, textStatus, errorThrown) {
            alert("Có lỗi xảy ra");
            console.error("Error fetching items: " + textStatus);
        });;
}

// từ chối yêu cầu bàn giao

function postRejectTranferRequest(tranferRequestId) {
    $.ajax({
        url: `http://localhost:3000/postRejectTranferRequest?tranferRequestId=${tranferRequestId}`,
        type: 'POST',
        async: false
    }).done(function () {

        alert("Yêu cầu được chấp nhận")
    })
        .fail(function (jqXHR, textStatus, errorThrown) {
            alert("Có lỗi xảy ra");
            console.error("Error fetching items: " + textStatus);
        });;
}

//cập nhật lịch sử bàn giao
function postHistoryTranfer(tranferRequestId) {
    $.ajax({
        url: `http://localhost:3000/postHistoryTranfer?tranferRequestId=${tranferRequestId}`,
        type: 'POST',
        async: false
    }).done(function () {
    })
        .fail(function (jqXHR, textStatus, errorThrown) {
            alert("Có lỗi xảy ra");
            console.error("Error fetching items: " + textStatus);
        });;
}


// lấy ra idTranferRequest lớn nhất
function getMaxIdTranferRequest() {
    let max;
    $.ajax({
        url: `http://localhost:3000/getMaxIdTranferRequest`,
        type: 'GET',
        async: false,
    }).done(function (max_id) {
        max = max_id[0].max_id

    })
        .fail(function (jqXHR, textStatus, errorThrown) {
            alert("Có lỗi xảy ra");
            console.error("Error fetching items: " + textStatus);
        });;
    return max;
}



// upload maintance request
function postMaintanceRequest(idItem, idStaff, typeRequest, imageDecode, budgetEstimate, reason, extend) {
    if (extend === '') {
        extend = null;
    } else if (budgetEstimate === '') {
        budgetEstimate = null;
    }
    let requestData = {
        idItem: idItem,
        idStaff: idStaff,
        typeRequest: typeRequest,
        imageDecode: imageDecode,
        budgetEstimate: budgetEstimate,
        reason: reason,
        extend: extend
    }
    $.ajax({
        url: `http://localhost:3000/postMaintanceRequest`,
        type: 'POST',
        async: false,
        contentType: 'application/json',
        data: JSON.stringify(requestData)
    }).done(function () {
        alert("Gửi yêu cầu thành công");
    })
        .fail(function (jqXHR, textStatus, errorThrown) {
            alert("Có lỗi xảy ra");
            console.error("Error fetching items: " + textStatus);
        });;
}

// lấy ra các yêu cầu bàn giao theo pic
function getAllTranferRequest(page, pageSize, filter, idPIC) {
    $.ajax({
        url: `http://localhost:3000/getAllTranferRequest?page=${page}&pageSize=${pageSize}&filter=${filter}&idPIC=${idPIC}`,
        type: 'GET',
        async: false,
    })
        .done(function (requests) {
            $('#table-body').empty(); // Xóa hết nội dung của tbody trước khi thêm dữ liệu mới
            requests.forEach(function (request) {
                let statusColor = ''; // Màu sắc mặc định

                // Xác định màu sắc dựa trên giá trị của request.status
                if (request.status === 'Chấp nhận') {
                    statusColor = 'green'; // Màu xanh
                } else if (request.status === 'Đang chờ') {
                    statusColor = 'rgb(244,208,49)'; // Màu vàng
                } else if (request.status === 'Từ chối') {
                    statusColor = 'red'; // Màu đỏ
                }

                $('#table-body').append(`
                <tr>
                <td>${request.PIC_request_name}</td>
                <td>${request.fromWarehouse_name}, ${request.from_area_name}</td>
                <td>${request.toWarehouse_name}, ${request.to_area_name}</td>
                <td style="max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: pre-wrap;">${request.reason}</td>
                <td>${formatFullDateTime(request.date)}</td>
                <td>${formatFullDateTime(request.date_answer)}</td>
                <td style="color: ${statusColor};">${request.status}</td>
                <td><button class="more-info" data-id=${request.idTranferRequest}>Chi tiết</button></td>
                </tr>
            `);
            });
            renderPagination(Math.ceil(getNumAllTranferRequest(getActiveFilterValue(), idPIC) / pageSize));
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
}
// lấy số lượng yêu cau bàn giao theo pic
function getNumAllTranferRequest(filter, idPIC) {
    let num;

    $.ajax({
        url: `http://localhost:3000/getNumAllTranferRequest?filter=${filter}&idPIC=${idPIC}`,
        type: 'GET',
        async: false,
    })
        .done(function (numItem) {
            num = numItem.count;
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
    return num;
}


//lấy ra số lượng yêu cầu bàn giao (cho manager)
function getAllTranferRequestManager(page, pageSize, filter) {
    $.ajax({
        url: `http://localhost:3000/getAllTranferRequestManager?page=${page}&pageSize=${pageSize}&filter=${filter}`,
        type: 'GET',
        async: false,
    })
        .done(function (requests) {
            $('#table-body').empty(); // Xóa hết nội dung của tbody trước khi thêm dữ liệu mới
            requests.forEach(function (request) {
                let statusColor = ''; // Màu sắc mặc định

                // Xác định màu sắc dựa trên giá trị của request.status
                if (request.status === 'Chấp nhận') {
                    statusColor = 'green'; // Màu xanh
                } else if (request.status === 'Đang chờ') {
                    statusColor = 'rgb(244,208,49)'; // Màu vàng
                } else if (request.status === 'Từ chối') {
                    statusColor = 'red'; // Màu đỏ
                }

                $('#table-body').append(`
                <tr>
                <td>${request.PIC_request_name}</td>
                <td>${request.fromWarehouse_name}, ${request.from_area_name}</td>
                <td>${request.toWarehouse_name}, ${request.to_area_name}</td>
                <td style="max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: pre-wrap;">${request.reason}</td>
                <td>${formatFullDateTime(request.date)}</td>
                <td>${formatFullDateTime(request.date_answer)}</td>
                <td style="color: ${statusColor};">${request.status}</td>
                <td><button class="more-info" data-id=${request.idTranferRequest}>Chi tiết</button></td>
                </tr>
            `);
            });
            renderPagination(Math.ceil(getNumAllTranferRequestManager(getActiveFilterValue()) / pageSize));
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
}

// lấy ra số lượng yêu cầu bàn giao (cho manager)
function getNumAllTranferRequestManager(filter) {
    let num;

    $.ajax({
        url: `http://localhost:3000/getNumAllTranferRequestManager?filter=${filter}`,
        type: 'GET',
        async: false,
    })
        .done(function (numItem) {
            num = numItem.count;
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
    return num;
}


function getInforByTranferId(idTranferRequest) {
    let rs;
    $.ajax({
        url: `http://localhost:3000/getInforByTranferId?idTranferRequest=${idTranferRequest}`,
        type: 'GET',
        async: false,
    })
        .done(function (result) {
            rs = result
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
    return rs;
}


// lấy ra tất cả các yêu cầu maintance
function getAllMaintanceRequest(page, pageSize, filter, advanFilter) {
    if (filter !== "filter") {
        advanFilter = "";
    }

    $.ajax({
        url: `http://localhost:3000/getAllMaintanceRequest?page=${page}&pageSize=${pageSize}&filter=${filter}&advanFilter=${advanFilter}`,
        type: 'GET',
        async: false,
    })
        .done(function (requests) {
            $('#table-body').empty(); // Xóa hết nội dung của tbody trước khi thêm dữ liệu mới
            requests.forEach(function (request) {
                let typeColor = ''; // Màu sắc mặc định
                let imageURL = ""
                if (request.type == "Bảo dưỡng") {
                    typeColor = 'rgb(19,50,139)';;
                } else if (request.type == "Sửa chữa") {
                    typeColor = "rgb(139,12,15)";
                } else if (request.type == "Thay mới") {
                    typeColor = "rgb(12,139,15)";
                } else if (request.type == "Gia hạn") {
                    typeColor = "green";
                }
                if (request.image !== null) {
                    let input = request.image.replace(/[^A-Fa-f0-9]/g, "");
                    let binary = new Array();
                    for (let i = 0; i < input.length / 2; i++) {
                        let h = input.substr(i * 2, 2);
                        binary[i] = parseInt(h, 16);
                    }
                    let byteArray = new Uint8Array(binary);
                    imageURL = window.URL.createObjectURL(new Blob([byteArray], { type: 'application/octet-stream' }));
                }

                // Xác định màu sắc dựa trên giá trị của request.status
                if (request.status === 'Chấp nhận') {
                    statusColor = 'green'; // Màu xanh
                } else if (request.status === 'Đang chờ') {
                    statusColor = 'rgb(244,208,49)'; // Màu vàng
                } else if (request.status === 'Từ chối') {
                    statusColor = 'red'; // Màu đỏ
                }

                let htmlCode = `
                <tr>
                   <td style="max-width: 200px; overflow: hidden; text-overflow: ellipsis;">${request.categoryName} (id:${request.idItem}) (${request.warehouseName}, ${request.areaName})</td>     
                   <td style="max-width: 100px; overflow: hidden; text-overflow: ellipsis;">${request.staffName != null ? request.staffName : "Hệ thống MIS"}</td>
                   <td style="color: ${typeColor};">${request.type}</td>
                   <td style="max-width: 250px; word-wrap: break-word;">${request.reason}</td>
                   <td><img src="${imageURL}" alt="Ảnh thiết bị" style="width: 100px;"></td>
                   <td>${request.budgetEstimate == null ? "" : formatCurrencyVND(request.budgetEstimate)}</td>
                   <td style="max-width: 30px;">${request.extend == null ? "" : request.extend}</td>
                   <td>${formatFullDateTime(request.date)}</td>
                   <td style="color: ${statusColor};">${request.status}</td>
              
            `

                if (acc.PICorStaff !== 0) {
                    htmlCode += `<td><button class="more-info" data-id=${request.idMaintanceRequest}>Chi tiết</button></td>`
                }
                htmlCode += `</tr>`
                $('#table-body').append(htmlCode);
            });
            renderPagination(Math.ceil(getNumAllMaintanceRequest(filter, advanFilter) / pageSize));
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
}


function getNumAllMaintanceRequest(filter, advanFilter) {
    let num;

    $.ajax({
        url: `http://localhost:3000/getNumAllMaintanceRequest?filter=${filter}&advanFilter=${advanFilter}`,
        type: 'GET',
        async: false,
    })
        .done(function (numItem) {
            num = numItem.total;
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
    return num;
}

// lấy idPIC theo idWarehouse
function getIdPICByIdWarehouse(idWarehouse) {
    let id;

    $.ajax({
        url: `http://localhost:3000/getIdPICByIdWarehouse?idWarehouse=${idWarehouse}`,
        type: 'GET',
        async: false,
    })
        .done(function (idPICs) {
            id = idPICs[0].idPIC;
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
    return id;
}

// lấy các item được yêu cầu chuyển giao theo idTranferRequest
function getItemByIdTranferRequest(idTranferRequest) {
    let rs = "";
    $.ajax({
        url: `http://localhost:3000/getItemByIdTranferRequest?idTranferRequest=${idTranferRequest}`,
        type: 'GET',
        async: false,
    })
        .done(function (requests) {
            rs = requests;
            $('#table-body').empty(); // Xóa hết nội dung của tbody trước khi thêm dữ liệu mới
            requests.forEach(function (request) {
                let imageURL = ""
                if (request.image !== null) {
                    let input = request.image.replace(/[^A-Fa-f0-9]/g, "");
                    let binary = new Array();
                    for (let i = 0; i < input.length / 2; i++) {
                        let h = input.substr(i * 2, 2);
                        binary[i] = parseInt(h, 16);
                    }
                    let byteArray = new Uint8Array(binary);
                    imageURL = window.URL.createObjectURL(new Blob([byteArray], { type: 'application/octet-stream' }));
                }



                $('#table-body').append(`
                <tr>
                <td>${request.category_name} (id:${request.idItem})</td>
                <td><img src="${imageURL}" alt="Ảnh thiết bị" style="width: 200px;"></td></tr>
            `);
            });
            return rs;
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
}

// hàm lấy ra infor maintance request theo id
function getMaintanceRequestById(idMaintanceRequest) {
    let rs;
    $.ajax({
        url: `http://localhost:3000/getMaintanceRequestById?idMaintanceRequest=${idMaintanceRequest}`,
        type: 'GET',
        async: false,
    })
        .done(function (request) {
            rs = request;

            let imageURL = ""
            if (request.image !== null) {
                let input = request.image.replace(/[^A-Fa-f0-9]/g, "");
                let binary = new Array();
                for (let i = 0; i < input.length / 2; i++) {
                    let h = input.substr(i * 2, 2);
                    binary[i] = parseInt(h, 16);
                }
                let byteArray = new Uint8Array(binary);
                imageURL = window.URL.createObjectURL(new Blob([byteArray], { type: 'application/octet-stream' }));
            }




            $('#data-table-request').append(`
                <tr>
                    <td>${request.type}</td>
                    <td>${request.reason}</td>
                    <td><img src="${imageURL}" alt="Ảnh thiết bị" style="width: 200px;"></td>
                    <td>${request.extend == null ? "" : request.extend}</td>
                    <td>${request.budgetEstimate == null ? "" : formatCurrencyVND(request.budgetEstimate)}</td>
                    <td>${formatFullDateTime(request.date)}</td>
                </tr>
            `);


        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
    return rs;
}



function postUpdateStatusMaintanceRequest(status, reasonManager, idMaintanceRequest) {
    $.ajax({
        url: `http://localhost:3000/postUpdateStatusMaintanceRequest?status=${status}&reasonManager=${reasonManager}&idMaintanceRequest=${idMaintanceRequest}`,
        type: 'POST',
        async: false
    }).done(function () {

        alert("Trả lời yêu cầu thành công")
    })
        .fail(function (jqXHR, textStatus, errorThrown) {
            alert("Có lỗi xảy ra");
            console.error("Error fetching items: " + textStatus);
        });;
}


function postUpdateRequestedItem(maintanceRequested, idItem) {
    $.ajax({
        url: `http://localhost:3000/postUpdateRequestedItem?maintanceRequested=${maintanceRequested}&idItem=${idItem}`,
        type: 'POST',
        async: false
    }).done(function () {
    })
        .fail(function (jqXHR, textStatus, errorThrown) {
            alert("Có lỗi xảy ra");
            console.error("Error fetching items: " + textStatus);
        });;
}

function postUpdateMaintanceItem(type, idItem) {
    $.ajax({
        url: `http://localhost:3000/postUpdateMaintanceItem?type=${type}&idItem=${idItem}`,
        type: 'POST',
        async: false
    }).done(function () {
    })
        .fail(function (jqXHR, textStatus, errorThrown) {
            alert("Có lỗi xảy ra");
            console.error("Error fetching items: " + textStatus);
        });;
}

function postUpdateBorItem(idItem) {
    $.ajax({
        url: `http://localhost:3000/postUpdateBorItem?idItem=${idItem}`,
        type: 'POST',
        async: false
    }).done(function () {
    })
        .fail(function (jqXHR, textStatus, errorThrown) {
            alert("Có lỗi xảy ra");
            console.error("Error fetching items: " + textStatus);
        });;
}


function postUpdateExtendItem(idItem, extend) {
    $.ajax({
        url: `http://localhost:3000/postUpdateExtendItem?idItem=${idItem}&extend=${extend}`,
        type: 'POST',
        async: false
    }).done(function () {
    })
        .fail(function (jqXHR, textStatus, errorThrown) {
            alert("Có lỗi xảy ra");
            console.error("Error fetching items: " + textStatus);
        });;
}


//gửi email thông báo cho PIC khi có yêu cầu tranfer được trả lời

function sendMailResultTranferRequestForPIC(idTranferRequest, data) {

    $.ajax({
        url: `http://localhost:3000/sendMailResultTranferRequestForPIC?idTranferRequest=${idTranferRequest}`,
        type: 'GET',
        async: false,
        contentType: 'application/json',
        data: JSON.stringify(data)
    })
        .done()
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });

}


// gửi mail sau khi yêu cầu thêm mới được tạo

function sendRegisterNewDeviceForManager(idRegisterDeviceRequest) {
    let managerEmail = getManagerEmail();
    $.ajax({
        url: `http://localhost:3000/sendRegisterNewDeviceForManager?idRegisterDeviceRequest=${idRegisterDeviceRequest}$managerEmail=${managerEmail}`,
        type: 'GET',
        async: false
    })
        .done()
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
}


// hàm gửi yêu cầu thêm mới thiết bị
function postRegisterDevice(listOrder) {
    let idRegisterDeviceRequest = postRegisterDeviceRequest();
    $.ajax({
        url: `http://localhost:3000/postRegisterDevice?idRegisterDeviceRequest=${idRegisterDeviceRequest}`,
        type: 'POST',
        async: false,
        contentType: 'application/json',
        data: JSON.stringify(listOrder)
    }).done(function () {
        alert("yêu cầu thành công");
        location.reload();
        sendRegisterNewDeviceForManager(idRegisterDeviceRequest);
    })
        .fail(function (jqXHR, textStatus, errorThrown) {
            alert("Có lỗi xảy ra");
            console.error("Error fetching items: " + textStatus);
        });;
}

// tạo yêu cầu thêm mới mới
function postRegisterDeviceRequest() {
    let re
    $.ajax({
        url: `http://localhost:3000/postRegisterDeviceRequest`,
        type: 'POST',
        async: false,
    }).done(function (rs) {
        re = rs.idRegisterDeviceRequest
    })
        .fail(function (jqXHR, textStatus, errorThrown) {
            alert("Có lỗi xảy ra");
            console.error("Error fetching items: " + textStatus);
        });;
    return re;

}




// cập nhật tình trạng yêu cầu thêm mới thiết bị
function postUpdateStatusRegisterDeviceRequest(status, id) {
    
    $.ajax({
        url: `http://localhost:3000/postUpdateStatusRegisterDeviceRequest?status=${status}&id=${id}`,
        type: 'POST',
        async: false,
    }).done(function (rs) {
   
    })
        .fail(function (jqXHR, textStatus, errorThrown) {
            alert("Có lỗi xảy ra");
            console.error("Error fetching items: " + textStatus);
        });;

}

// thêm thiết bị mới
function postNewItem(items) {
    for(let i = 0; i < items.length; i++){
        if(items[i].idCategory == null){
            items[i].idCategory = postAddNewCategory(items[i].name);      
        }
    }
    console.log(items)
    $.ajax({
        url: `http://localhost:3000/postNewItem`,
        type: 'POST',
        async: false,
        contentType: 'application/json',
        data: JSON.stringify(items)
    }).done(function (rs) {
   
    })
        .fail(function (jqXHR, textStatus, errorThrown) {
            alert("Có lỗi xảy ra");
            console.error("Error fetching items: " + textStatus);
        });;

}



function postAddNewCategory(categoryName) {
    let result;
    $.ajax({
        url: `http://localhost:3000/postAddNewCategory?categoryName=${categoryName}`,
        type: 'POST',
        async: false,
    }).done(function (rs) {
        result = rs;
    })
        .fail(function (jqXHR, textStatus, errorThrown) {
            alert("Có lỗi xảy ra");
            console.error("Error fetching items: " + textStatus);
        });;
        return result.idCategory;
}


//lấy ra email của manager đang active
function getManagerEmail() {
    let re
    $.ajax({
        url: `http://localhost:3000/getManagerEmail`,
        type: 'GET',
        async: false,
    }).done(function (rs) {
        re = rs[0].email
    })
        .fail(function (jqXHR, textStatus, errorThrown) {
            alert("Có lỗi xảy ra");
            console.error("Error fetching items: " + textStatus);
        });;
    return re;

}


function getRegisterDeviceRequestById(id) {
    let re
    $.ajax({
        url: `http://localhost:3000/getRegisterDeviceRequestById?id=${id}`,
        type: 'GET',
        async: false,
    }).done(function (rs) {
        re = rs
    })
        .fail(function (jqXHR, textStatus, errorThrown) {
            alert("Có lỗi xảy ra");
            console.error("Error fetching items: " + textStatus);
        });;
    return re;

}




function getAllRegisterDeviceByRegisterDeviceRequestId(id) {
    let rs;
    $.ajax({
        url: `http://localhost:3000/getAllRegisterDeviceByRegisterDeviceRequestId?id=${id}`,
        type: 'GET',
        async: false,
    }).done(function (items) {
        rs = items;
        $('#table-body').empty(); // Xóa hết nội dung của tbody trước khi thêm dữ liệu mới
            items.forEach(function (item) {
                
                let imageURL = "";
                if (item.image !== null) {
                    let input = item.image.replace(/[^A-Fa-f0-9]/g, "");
                    let binary = new Array();
                    for (let i = 0; i < input.length / 2; i++) {
                        let h = input.substr(i * 2, 2);
                        binary[i] = parseInt(h, 16);
                    }
                    let byteArray = new Uint8Array(binary);
                    imageURL = window.URL.createObjectURL(new Blob([byteArray], { type: 'application/octet-stream' }));
                }


                $('#table-body').append(`
                <tr>
                    <td style="max-width: 250px; word-wrap: break-word;">${item.name == "" ? item.category_name : item.name}</td>
                    <td><img src="${imageURL}" alt="Ảnh thiết bị" style="width: 100px;"></td>
                    <td>${item.num}</td>
                    <td>${item.maintanceCycle}</td>
                    <td>${item.renewCycle}</td>
                </tr>
            `);
            });
    })
        .fail(function (jqXHR, textStatus, errorThrown) {
            alert("Có lỗi xảy ra");
            console.error("Error fetching items: " + textStatus);
        });;
        return rs;
}

// Hàm định dạng số với thêm số 0 ở trước nếu cần
function pad(number) {
    return number < 10 ? '0' + number : number;
}

// Hàm format giờ và phút
function formatTime(date) {
    const hours = pad(date.getHours());
    const minutes = pad(date.getMinutes());
    return `${hours}:${minutes}`;
}

// // Hàm format ngày, tháng, năm
// function formatDate(date) {
//     // const day = pad(date.getDate());
//     const month = pad(date.getMonth() + 1); // Tháng trong JavaScript bắt đầu từ 0
//     const year = date.getFullYear();
//     return `${day}/${month}/${year}`;
// }

// Hàm format đầy đủ ngày giờ
function formatFullDateTime(dateString) {
    const date = new Date(dateString);
    return `${formatDate(date)} `
}

// Hàm định dạng tiền
function formatCurrencyVND(amount) {
    // Chuyển đổi số thành chuỗi và thêm dấu chấm phân cách hàng nghìn
    let formattedAmount = amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    // Thêm ký hiệu tiền tệ "₫" ở cuối chuỗi
    return `${formattedAmount} ₫`;
}
