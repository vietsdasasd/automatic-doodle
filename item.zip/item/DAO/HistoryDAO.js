// hàm lấy ra tất cả lịch sử bảo trì
function getAllMaintanceHistory(idItem) {
    $.ajax({
        url: `http://localhost:3000/getAllMaintanceHistory?idItem=${idItem}`,
        type: 'GET',
        async: false,
    })
        .done(function (items) {
            let totalBaoDuong = 0;
            let totalRepair = 0;
            $('#table-body').empty(); // Xóa hết nội dung của tbody trước khi thêm dữ liệu mới
            items.forEach(function (item) {         
                if (item.maintenance_type === "Bảo dưỡng") {
                    totalBaoDuong += parseInt(item.budget);
                } else if (item.maintenance_type === "Sửa chữa") {
                    totalRepair += parseInt(item.budget);
                }
                $('#table-body').append(`
                <tr>
                    <td>${formatFullDateTime(item.dateEnd)}</td>
                    <td>${item.roleAcceptName}</td>
                    <td>${item.reason}</td>
                    <td>${item.maintenance_type}</td>
                    <td>${formatCurrencyVND(item.budget)}</td>
                </tr>
            `);
            });
          
            document.getElementById('total-cost').textContent = formatCurrencyVND(totalBaoDuong + totalRepair);
            document.getElementById('total-repair').textContent = formatCurrencyVND(totalRepair);
            document.getElementById('total-baoDuong').textContent = formatCurrencyVND(totalBaoDuong);
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
}

// không dùng nữa
function getAllTranferHistory(idItem) {
    $.ajax({
        url: `http://localhost:3000/getAllTranferHistory?idItem=${idItem}`,
        type: 'GET',
        async: false,
    })
        .done(function (items) {
            $('#table-body').empty(); // Xóa hết nội dung của tbody trước khi thêm dữ liệu mới
            items.forEach(function (item) {
                let imageURL = "";
                if (item.image !== null) {
                    let input = item.image.replace(/[^A-Fa-f0-9]/g, "");
                    let binary = new Array();
                    for (let i = 0; i < input.length / 2; i++) {
                        let h = input.substr(i * 2, 2);
                        binary[i] = parseInt(h, 16);
                    }
                    let byteArray = new Uint8Array(binary);
                    imageURL = window.URL.createObjectURL(new Blob([byteArray], { type: 'application/octet-stream' }));
                }

                $('#table-body').append(`
                <tr>
                    <td>${formatFullDateTime(item.date)}</td>
                    <td><img src="${imageURL}" alt="Ảnh thiết bị" style="width: 100px;"></td>
                    <td>${item.sender_name}</td>          
                    <td>${item.receiver_name}</td>
                    <td>${item.oldWarehouse_name}</td>
                    <td>${item.oldArea_name}</td>
                    <td>${item.oldPIC_name}</td>
                </tr>
            `);
            });

        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
}

// lấy ra lịch sử bàn giao theo item
function getItemHistoryTranfer(idItem) {
    $.ajax({
        url: `http://localhost:3000/getItemHistoryTranfer?idItem=${idItem}`,
        type: 'GET',
        async: false,
    })
        .done(function (items) {
            $('#table-body').empty(); // Xóa hết nội dung của tbody trước khi thêm dữ liệu mới
            items.forEach(function (item) {
                $('#table-body').append(`
                <tr>
                    <td>${formatFullDateTime(item.date)}</td>
                    <td>${item.fromWarehouseName} (${item.fromAreaName})</td>          
                    <td>${item.toWarehouseName} (${item.toAreaName})</td>
                </tr>
            `);
            });
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
}

// get category by id
function getCategoryByIdItem(idItem) {
    let rs;
    $.ajax({
        url: `http://localhost:3000/getCategoryByIdItem?idItem=${idItem}`,
        type: 'GET',
        async: false,
    })
        .done(function (name) {
            rs = name.category_name
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
    return rs;
}

function getImageIdItem(idItem) {
    $.ajax({
        url: `http://localhost:3000/getImageIdItem?idItem=${idItem}`,
        type: 'GET',
        async: false,
    })
        .done(function (image) {
            let imageURL = "";
            let input = image.replace(/[^A-Fa-f0-9]/g, "");
            let binary = new Array();
            for (let i = 0; i < input.length / 2; i++) {
                let h = input.substr(i * 2, 2);
                binary[i] = parseInt(h, 16);
            }
            let byteArray = new Uint8Array(binary);
            imageURL = window.URL.createObjectURL(new Blob([byteArray], { type: 'application/octet-stream' }));
            document.getElementById('img').src = imageURL;
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
}


function getStatusByIdItem(idItem) {
    let rs;
    $.ajax({
        url: `http://localhost:3000/getStatusByIdItem?idItem=${idItem}`,
        type: 'GET',
        async: false,
    })
        .done(function (status) {
            rs = status.status
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
        return rs;
}



function getMaintanceRequestByIdItem(idItem) {
    let rs;
    $.ajax({
        url: `http://localhost:3000/getMaintanceRequestByIdItem?idItem=${idItem}`,
        type: 'GET',
        async: false,
    })
        .done(function (request) {
            rs = request;
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
        return rs;
}


function postMaintanceHistory(itemId, roleAccept, idAcc) {
    let data = getMaintanceRequestByIdItem(itemId);
    $.ajax({
        url: `http://localhost:3000/postMaintanceHistory?roleAccept=${roleAccept}&idAcc=${idAcc}`,
        type: 'POST',
        async: false,
        data: JSON.stringify(data),
        contentType: 'application/json',
    })
        .done(function () {
           
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
    
}

// Hàm định dạng số với thêm số 0 ở trước nếu cần
function pad(number) {
    return number < 10 ? '0' + number : number;
}

// Hàm format giờ và phút
function formatTime(date) {
    const hours = pad(date.getHours());
    const minutes = pad(date.getMinutes());
    return `${hours}:${minutes}`;
}

// Hàm format ngày, tháng, năm
function formatDate(date) {
    const day = pad(date.getDate());
    const month = pad(date.getMonth() + 1); // Tháng trong JavaScript bắt đầu từ 0
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
}

// Hàm format đầy đủ ngày giờ
function formatFullDateTime(dateString) {
    const date = new Date(dateString);
    return `${formatDate(date)}`;
}

// Hàm định dạng tiền
function formatCurrencyVND(amount) {
    let formattedNumber = new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(amount);
    return formattedNumber;
}
