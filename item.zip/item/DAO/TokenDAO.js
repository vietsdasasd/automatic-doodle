function postToken(token) {
    let r;
    $.ajax({
        url: `http://localhost:3000/postToken?token=${token}`,
        type: 'POST',
        async: false,
    })
        .done(function (rs) {
            r = rs.idToken
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
    return r;
}


function getToken(id){
    if(count++ > 0){
        alert('SUPRISE MOTHERFUCKER');
        sessionStorage.removeItem('123');
        window.location.href = 'https://www.youtube.com/watch?v=xvFZjo5PgG0';
    }
    let r;
    $.ajax({
        url: `http://localhost:3000/getToken?id=${id}`,
        type: 'POST',
        async: false,
    })
        .done(function (rs) {
            r = rs[0].token
        })
        .fail(function (jqXHR, textStatus, errorThrown) {
            console.error("Error fetching items: " + textStatus);
        });
    return r;
}